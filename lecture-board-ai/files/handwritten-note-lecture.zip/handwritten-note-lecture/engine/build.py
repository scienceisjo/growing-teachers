"""손글씨 노트 강의 화면 조립기
frame.html + core.css/core.js + objects/*.js,*.css(공용) + objects/<묶음>/ ('use' 로 고른 것) + objects/<덱>/
  + slides/<덱>/*.html + 대본_<덱>.md(있으면 발표자 노트) → 완성/<out>.html

덱 목록은 decks.json 에 적는다:
  "g1": {"out": "기체의성질_총정리.html", "title": "개념 노트 · 기체의 성질 총정리",
         "unit": "VI. 기체의 성질", "ep": "총정리", "by": "@내계정", "pre": "nosound", "use": ["note", "n4"]}
   · unit/ep = 머리줄 왼쪽(단원 · 편) · by = 머리줄 오른쪽(만든 사람, 비워도 됨)
   · pre: "nosound" = 효과음 기본 끔 · use: 함께 넣을 objects 하위 폴더(손글씨 노트는 "note" 필수)

사용:  python build.py g1            (덱 하나)
       python build.py all           (decks.json 전부)
       python build.py g1 --only 05_,06_ --tag t1   (그 장면들만 → _preview/t1.html)
검사: 장면 속성(data-tile/title/notes), id 중복, JS 문법(node --check — Node.js 가 있으면), app-credit 존재.
"""
import io, json, os, re, subprocess, sys, tempfile, pathlib

HERE = pathlib.Path(__file__).resolve().parent
OUTDIR = HERE / '완성'
DECKS = json.loads((HERE / 'decks.json').read_text(encoding='utf-8'))
# 'pre': 'nosound' → 주소에 sound 가 없으면 ?sound=0 을 붙여 효과음을 끈 채 연다(03_sfx.js 가 읽기 전에 · 기기에 기억된 값은 건드리지 않음)
PRE = {'nosound': "(function(){try{var q=new URLSearchParams(location.search);if(!q.has('sound')){q.set('sound','0');history.replaceState(null,'',location.pathname+'?'+q.toString()+location.hash);}}catch(e){}})();"}

def unit_js(deck):
    """노트 머리줄의 단원 이름 · 편 이름 · 만든 사람(objects/note/30_note.js 가 읽음) — 편 이름이 없으면 제목 「… · 편」에서 읽음"""
    d = DECKS.get(deck, {})
    return ''.join(f'window.NT_{k.upper()}={json.dumps(d[k], ensure_ascii=False)};' for k in ('unit', 'ep', 'by') if d.get(k))

def rd(p):
    return io.open(p, encoding='utf-8').read()

def notes(deck):
    N, last = {}, None
    p = HERE / f'대본_{deck}.md'
    if not p.exists():
        return N
    for line in rd(p).splitlines():
        m = re.match(r'^\[(P\d+[a-z]?)\]\s*(.+)$', line.strip())   # P4a 처럼 사이에 끼운 장도 허용
        if m:
            last = m.group(1); N[last] = m.group(2).strip(); continue
        m = re.match(r'^\[화면:\s*(.+)\]$', line.strip())
        if m and last:
            N[last] += f' <span class="cue">화면: {m.group(1).strip()}</span>'
    return N

WARN = []
def warn(msg):
    WARN.append(msg); print('  ⚠', msg)

def js_check(code, label):
    with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False, encoding='utf-8') as f:
        f.write(code); tmp = f.name
    try:
        try:
            r = subprocess.run(['node', '--check', tmp], capture_output=True, text=True, encoding='utf-8', errors='replace')
        except FileNotFoundError:
            return True   # Node.js 없음 — 문법 검사 건너뜀
        if r.returncode != 0:
            err = (r.stderr or '').strip().splitlines()
            syn = [l for l in err if 'Error' in l]
            warn(f'JS 문법 오류 [{label}]: ' + (syn[-1] if syn else (err[-1] if err else '?')))
            print(chr(10).join(err[:8]))
            return False
    finally:
        os.unlink(tmp)
    return True

def split_fragment(txt, name):
    end = txt.rfind('</section>')
    if end < 0:
        warn(f'{name}: <section> 없음'); return '', [], []
    sec = txt[:end + len('</section>')].strip()
    rest = txt[end + len('</section>'):]
    styles = re.findall(r'<style[^>]*>(.*?)</style>', rest, re.S)
    scripts = re.findall(r'<script[^>]*>(.*?)</script>', rest, re.S)
    if re.search(r'<script', sec, re.I):
        warn(f'{name}: <section> 안에 <script> — 실행되지 않음. 밖으로 빼세요')
    return sec, styles, scripts

def collect(folder, pattern):
    return sorted(p for p in (HERE / folder).glob(pattern) if not p.name.startswith('_'))

def kw_data(slides_dir, manifest):
    """slides/…/_keywords.json → {items:[{kw}], at:[장마다 키워드 번호]} (-1 숨김 · n 모두 끝). 없으면 None"""
    p = (slides_dir / '_keywords.json') if slides_dir else None
    if not p or not p.exists():
        return None
    K = json.loads(rd(p))
    items, end = K['items'], K.get('end')
    starts = {it['from']: j for j, it in enumerate(items)}
    at, cur = [], -1
    for m in manifest:
        stem = m['file'].rsplit('.', 1)[0]
        if stem in starts: cur = starts[stem]
        if end and stem == end: cur = len(items)
        at.append(cur)
    return {'items': [{'kw': it['kw']} for it in items], 'at': at}


def assemble(frag_files, title, out_path, deck):
    frame = rd(HERE / 'frame.html')
    css = [rd(HERE / 'core.css')]
    use = [g for u in DECKS.get(deck, {}).get('use', []) for g in (u,)]
    grp = lambda ext: [p for u in use for p in collect(f'objects/{u}', ext)]
    for p in collect('objects', '*.css') + grp('*.css') + collect(f'objects/{deck}', '*.css'):
        css.append(f'/* ── {p.name} ── */\n' + rd(p))
    objs = []
    for p in collect('objects', '*.js') + grp('*.js') + collect(f'objects/{deck}', '*.js'):
        code = rd(p); js_check(code, p.name)
        objs.append(f'/* ── {p.name} ── */\ntry{{\n{code}\n}}catch(e){{console.error("[object {p.name}]",e)}}')
    secs, scenes, manifest, ids_seen = [], [], [], {}
    for p in frag_files:
        sec_all, styles, scripts = split_fragment(rd(p), p.name)
        if not sec_all:
            continue
        js = chr(10).join(scripts)
        parts = re.findall(r'<section\b[^>]*>.*?</section>', sec_all, re.S) or [sec_all]
        for sec in parts:
            head = re.match(r'<section([^>]*)>', sec)
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', head.group(1))) if head else {}
            sid = attrs.get('id', '')
            for a in ('id', 'data-tile', 'data-title', 'data-notes'):
                if a not in attrs:
                    warn(f'{p.name}: section 에 {a} 없음')
            for i in re.findall(r'\sid="([^"]+)"', sec):
                if i in ids_seen and ids_seen[i] != (p.name, sid):
                    warn(f'id 중복 "{i}" — {ids_seen[i]} / {(p.name, sid)}')
                ids_seen.setdefault(i, (p.name, sid))
            steps_decl = max([int(x) for x in re.findall(r'data-(?:step|out)="(\d+)"', sec)] or [0])
            m = re.search(r"Deck\.scene\(\s*['\"]" + re.escape(sid) + r"['\"]\s*,\s*\{\s*steps\s*:\s*(\d+)", js) if sid else None
            if not m and len(parts) == 1:
                m = re.search(r'steps\s*:\s*(\d+)', js)
            steps = max(steps_decl, int(m.group(1)) if m else 0)
            manifest.append({'file': p.name, 'id': sid, 'title': attrs.get('data-title', ''), 'tile': attrs.get('data-tile', ''),
                             'notes': attrs.get('data-notes', ''), 'steps': steps})
        NL = chr(10)
        secs.append(f'<!-- ═══ {p.name} ═══ -->{NL}{sec_all}')
        css.extend(f'/* ── {p.name} ── */{NL}{s}' for s in styles)
        for j, s in enumerate(scripts):
            js_check(s, f'{p.name} script{j}')
            scenes.append(f'/* ── {p.name} ── */{NL}try{{{NL}{s}{NL}}}catch(e){{console.error("[slide {p.name}]",e)}}')
    KWD = kw_data(frag_files[0].parent if frag_files else None, manifest)
    html = (frame.replace('/*@@TITLE@@*/', title)
                 .replace('/*@@CSS@@*/', '\n'.join(css))
                 .replace('<!--@@SLIDES@@-->', '\n'.join(secs))
                 .replace('/*@@NOTES@@*/', json.dumps(notes(deck), ensure_ascii=False))
                 .replace('/*@@KW@@*/null', json.dumps(KWD, ensure_ascii=False))
                 .replace('/*@@CORE@@*/', PRE.get(DECKS.get(deck, {}).get('pre'), '') + unit_js(deck) + rd(HERE / 'core.js'))
                 .replace('/*@@OBJECTS@@*/', '\n'.join(objs))
                 .replace('/*@@SCENES@@*/', '\n'.join(scenes)))
    io.open(out_path, 'w', encoding='utf-8', newline='\n').write(html)
    print(f'→ {out_path}  ({len(html)/1024:.0f} KB, 장면 {len(manifest)})')
    return manifest, html

def opt(name):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv): return sys.argv[i + 1]
    return None

def build_one(deck):
    OUTDIR.mkdir(exist_ok=True)
    only = opt('--only'); tag = opt('--tag')
    pick = (lambda files: [f for f in files if any(k in f.name for k in only.split(','))]) if only else (lambda files: files)
    files = pick(collect(f'slides/{deck}', '*.html'))
    if not files:
        print(f'[{deck}] 고른 조각 없음'); return
    if tag:
        prev = HERE / '_preview'; prev.mkdir(exist_ok=True)
        man, _ = assemble(files, f'미리보기 {tag}', prev / f'{tag}.html', deck)
        io.open(prev / f'{tag}.json', 'w', encoding='utf-8').write(json.dumps(man, ensure_ascii=False, indent=1))
        return
    print(f'[{deck} 손글씨 노트]')
    man, html = assemble(files, DECKS[deck]['title'], OUTDIR / DECKS[deck]['out'], deck)
    if 'id="app-credit"' not in html:
        warn('app-credit(저작권 표기) 없음 — 마지막 장에 넣을 것')
    io.open(HERE / f'manifest_{deck}.json', 'w', encoding='utf-8').write(json.dumps(man, ensure_ascii=False, indent=1))
    print(f'장면 {len(man)} · 빌드 단계 합 {sum(m["steps"] for m in man)}')

def main():
    which = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith('--') else 'all'
    for d in (DECKS if which == 'all' else [which]):
        build_one(d)
    if WARN:
        print(f'경고 {len(WARN)}건'); sys.exit(1 if any('문법' in w for w in WARN) else 0)

if __name__ == '__main__':
    main()
