// 개념 노트 «한 번에 하나씩» 검사 — 장면·단계마다 실제로 재생하며, 동시에 움직이는 글줄(쓰는 중 + 떠오르는 중) 수의 최댓값을 잰다.
// 사용: node note_seq.mjs g1   (완성/<덱 파일> 을 연다 · decks.json 의 이름)
//  · 글줄 = [data-w] 쓰기 진행 0~100% · [data-s] 글(.ln .cell .chip .sub .star .sec .pause, svg text) 등장 0~70%
//  · data-with 로 묶은 글은 2 로 셀 수 있다(의도). 3 이상이면 실패로 본다. 콘솔 오류·경고도 센다.
import { spawn } from 'node:child_process';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const deck = process.argv[2] || 'n1';
const HERE = import.meta.dirname;
const DK = JSON.parse(readFileSync(join(HERE, 'decks.json'), 'utf8'));
if (!DK[deck]) { console.log('덱 없음', deck); process.exit(2); }
const FILE = resolve(HERE, '완성', DK[deck].out);
const man = JSON.parse(readFileSync(join(HERE, `manifest_${deck}.json`), 'utf8'));
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const port = 7160 + Math.floor(Math.random() * 30);
const ud = mkdtempSync(join(tmpdir(), 'seq_'));
const chrome = spawn(CHROME, ['--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${ud}`, '--no-first-run', 'about:blank']);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let tab;
for (let i = 0; i < 60 && !tab; i++) { await sleep(400); try { const r = await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' }); if (r.ok) tab = await r.json(); } catch (e) {} }
const ws = new WebSocket(tab.webSocketDebuggerUrl); await new Promise(r => ws.onopen = r);
let id = 0; const pend = new Map(); const bad = [];
ws.onmessage = ev => { const d = JSON.parse(ev.data); if (d.id && pend.has(d.id)) { pend.get(d.id)(d.result || d); pend.delete(d.id); }
  else if (d.method === 'Runtime.consoleAPICalled' && (d.params.type === 'error' || d.params.type === 'warning')) bad.push(d.params.args.map(a => a.value ?? a.description).join(' ').slice(0, 200));
  else if (d.method === 'Runtime.exceptionThrown') bad.push('EXC ' + (d.params.exceptionDetails.exception?.description || d.params.exceptionDetails.text).slice(0, 200)); };
const send = (method, params = {}) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const ev = async e => (await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true })).result?.value;
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride', { width: 1920, height: 1080, deviceScaleFactor: 1, mobile: false });
await send('Page.navigate', { url: pathToFileURL(FILE).href + '?sound=0#1' });
await sleep(1800);
await ev(`(function(){window.__seq={max:0,who:[]};const TXT='[data-s].ln,[data-s].cell,[data-s].chip,[data-s].sub,[data-s].star,[data-s].sec,[data-s].pause,svg text[data-s]';
(function loop(){const sec=document.querySelector('#stage > section.slide.is-on');if(sec){let n=0;const names=[];
sec.querySelectorAll('[data-w]').forEach(el=>{const mm=/inset\\([^ ]+ ([\\d.]+)%/.exec(el.style.clipPath||'');if(mm&&el.style.opacity==='1'){const r=+mm[1];if(r>0.5&&r<99.5){n++;names.push('w:'+el.textContent.trim().slice(0,14));}}});
sec.querySelectorAll('[data-ntp]').forEach(t=>{if(!t.matches(TXT))return;const p=+t.getAttribute('data-ntp');if(p>0&&p<0.7){n++;names.push('s:'+(t.textContent||'').trim().slice(0,14));}});
if(n>window.__seq.max){window.__seq.max=n;window.__seq.who=names;}}requestAnimationFrame(loop);})();})()`);
const waitIdle = async () => { for (let i = 0; i < 200; i++) { await sleep(150); const left = await ev('(Deck.ctx && Deck.ctx.data.ntEnd || 0) - performance.now()'); if (left < -250) return; } };
const rows = []; let worst = 0;
for (let i = 0; i < man.length; i++) {
  await ev(`window.__seq.max=0;window.__seq.who=[];Deck.go(${i},0)`); await sleep(120); await waitIdle();
  let r = await ev('window.__seq'); rows.push([man[i].id, 0, r.max, r.who]); worst = Math.max(worst, r.max);
  for (let k = 1; k <= man[i].steps; k++) {
    await ev(`window.__seq.max=0;window.__seq.who=[];Deck.next()`); await sleep(120); await waitIdle();
    r = await ev('window.__seq'); rows.push([man[i].id, k, r.max, r.who]); worst = Math.max(worst, r.max);
  }
}
for (const [sid, k, mx, who] of rows) if (mx >= 2) console.log(`  ${sid} k${k}: 동시 ${mx} — ${who.join(' | ')}`);
console.log(`${deck}: 장면·단계 ${rows.length}개 · 동시에 움직이는 글줄 최대 ${worst} · 콘솔 오류/경고 ${bad.length}`);
bad.slice(0, 20).forEach(b => console.log('  !!', b));
ws.close(); chrome.kill(); process.exit(worst >= 3 || bad.length ? 1 : 0);
