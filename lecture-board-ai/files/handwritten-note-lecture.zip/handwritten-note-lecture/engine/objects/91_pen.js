/* 강의 빨간 펜(판서) v2 — 2026-11-01 「개념 노트」 유튜브 강의 요청 · canonical: 전기강의_빌드/objects/91_pen.js(기체압력 · 소비전력 빌드에 같은 사본)
 * v2(2026-11-04 아이패드): 모든 강의 화면 공용(objects/ 루트로 옮김). 캔버스는 입력을 받지 않고, 창 전체 capture 로
 *   window.LectureInk(89_ink.js)가 받아들인 포인터(펜슬 · 마우스, 손가락은 설정에 따라)만 그린다 — 손가락 넘기기 · 도구 상자는 그대로.
 * P 키·하단 펜 단추로 켜고 끈다. 그린 선은 남는다(레이저와 다름) — 펜을 꺼도 보이고, 꺼진 동안에는 클릭이 강의로 간다. 같은 장면의 단계를 넘겨도 남고, 다른 장면으로 가면 지워진다.
 * C = 모두 지우기 · Z = 마지막 획 지우기 · Esc = 펜 끄기. 레이저(L)와 동시에 켜지지 않는다(한쪽을 켜면 다른 쪽이 꺼짐).
 * 선은 무대(1920×1080) 좌표로 기억해 전체 화면·창 크기가 바뀌어도 같은 자리에 다시 그린다. 펜 모드의 클릭은 장면을 넘기지 않는다.
 * 페이지 전체 도구라 장면 Ctx 와 수명을 나눈다. 그릴 것이 있을 때만 한 프레임 그린다(계속 도는 RAF 없음).
 */
(function () {
  'use strict';
  function mount() {
    if (window.LecturePen || !window.Deck || !document.getElementById('hud')) return;
    var hud = document.getElementById('hud'), stage = document.getElementById('stage');
    var canvas = document.createElement('canvas');
    canvas.id = 'lecture-pen'; canvas.setAttribute('aria-hidden', 'true');
    var style = document.createElement('style');
    style.textContent = '#lecture-pen{position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:48;pointer-events:none;user-select:none;-webkit-user-select:none}html.pen-on #viewport{cursor:none}#hud #lecture-pen-toggle[aria-pressed="true"]{background:#d6332a;color:#fff;outline:2px solid #fff;outline-offset:2px}#hud #lecture-pen-clear[hidden]{display:none}@media print{#lecture-pen,#lecture-pen-toggle,#lecture-pen-clear{display:none!important}}';
    document.head.appendChild(style);
    document.body.appendChild(canvas);
    var ctx = canvas.getContext('2d');
    if (!ctx) { canvas.remove(); style.remove(); return; }

    var button = document.createElement('button');
    button.id = 'lecture-pen-toggle'; button.type = 'button';
    button.setAttribute('aria-label', '빨간 펜 켜기/끄기 (P)'); button.setAttribute('aria-keyshortcuts', 'P'); button.setAttribute('aria-pressed', 'false');
    button.title = '빨간 펜 (P) · C 모두 지우기 · Z 한 획 지우기 · Esc 끄기';
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M4 20l1.2-4.6L16.6 4a2 2 0 0 1 2.8 0l.6.6a2 2 0 0 1 0 2.8L8.6 18.8z"/><path d="M14.5 6.1l3.4 3.4"/></svg>';
    var wipe = document.createElement('button');
    wipe.id = 'lecture-pen-clear'; wipe.type = 'button'; wipe.hidden = true;
    wipe.setAttribute('aria-label', '펜 자국 모두 지우기 (C)'); wipe.title = '펜 자국 모두 지우기 (C)';
    wipe.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M8 20h12M5.5 14.5l8-8a2 2 0 0 1 2.8 0l2.2 2.2a2 2 0 0 1 0 2.8L12 18H8.9z"/></svg>';
    var full = hud.querySelector('[data-a="full"]');
    hud.insertBefore(button, full); hud.insertBefore(wipe, full);
    var table = document.querySelector('#help table');
    if (table) {
      var row = table.insertRow();
      row.innerHTML = '<td><kbd>P</kbd> · <kbd>C</kbd> · <kbd>Z</kbd></td><td>빨간 펜 켜기·끄기 · 모두 지우기 · 한 획 지우기 (다른 장면으로 가면 지워짐)</td>';
    }

    var SW = 1920, SH = 1080, W = 7, COLOR = '#e0261b';
    var enabled = false, strokes = [], cur = null, activeId = null, hover = null, raf = 0, dpr = 1, lastScene = -1;
    function box() { return stage.getBoundingClientRect(); }
    function toStage(e) { var r = box(); return [(e.clientX - r.left) / r.width * SW, (e.clientY - r.top) / r.height * SH]; }
    function render() {
      raf = 0;
      ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
      var r = box(), sx = r.width / SW, sy = r.height / SH;
      ctx.lineCap = ctx.lineJoin = 'round'; ctx.strokeStyle = COLOR; ctx.fillStyle = COLOR; ctx.lineWidth = W * sx;
      strokes.forEach(function (s) {
        var p = s.map(function (q) { return [r.left + q[0] * sx, r.top + q[1] * sy]; });
        if (p.length === 1) { ctx.beginPath(); ctx.arc(p[0][0], p[0][1], W * sx / 2, 0, Math.PI * 2); ctx.fill(); return; }
        ctx.beginPath(); ctx.moveTo(p[0][0], p[0][1]);
        for (var i = 1; i < p.length - 1; i++) {
          var mx = (p[i][0] + p[i + 1][0]) / 2, my = (p[i][1] + p[i + 1][1]) / 2;
          ctx.quadraticCurveTo(p[i][0], p[i][1], mx, my);
        }
        ctx.lineTo(p[p.length - 1][0], p[p.length - 1][1]); ctx.stroke();
      });
      if (enabled && hover) {   // 펜촉 자리(녹화에 OS 커서가 안 잡혀도 보이게)
        ctx.beginPath(); ctx.arc(hover[0], hover[1], Math.max(4, W * sx * .8), 0, Math.PI * 2);
        ctx.fillStyle = COLOR; ctx.fill(); ctx.lineWidth = 1.6; ctx.strokeStyle = '#fff'; ctx.stroke();
      }
    }
    function paint() { if (!raf) raf = requestAnimationFrame(render); }
    function release() { activeId = null; cur = null; }
    function clear() { release(); strokes = []; paint(); }
    function undo() { release(); strokes.pop(); paint(); }
    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.style.width = window.innerWidth + 'px'; canvas.style.height = window.innerHeight + 'px';
      canvas.width = Math.round(window.innerWidth * dpr); canvas.height = Math.round(window.innerHeight * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); hover = null; paint();
    }
    function toggle(value) {
      enabled = typeof value === 'boolean' ? value : !enabled;
      release(); hover = null;
      canvas.classList.toggle('on', enabled); wipe.hidden = !enabled; button.setAttribute('aria-pressed', String(enabled));
      document.documentElement.classList.toggle('pen-on', enabled);
      if (window.LectureInk) LectureInk.setOn('pen', enabled);
      if (enabled && window.LectureLaser && LectureLaser.enabled) LectureLaser.setEnabled(false);
      paint();
    }
    button.addEventListener('click', function (e) { e.stopPropagation(); toggle(); button.blur(); });
    wipe.addEventListener('click', function (e) { e.stopPropagation(); clear(); wipe.blur(); });
    document.addEventListener('keydown', function (e) {
      if (e.ctrlKey || e.metaKey || e.altKey || e.isComposing || (e.target.closest && e.target.closest('input,textarea,select,[contenteditable]'))) return;
      var k = e.key.toLowerCase();
      if (k === 'p') { if (!e.repeat) toggle(); e.preventDefault(); e.stopImmediatePropagation(); }
      else if (enabled && k === 'c') { clear(); e.preventDefault(); e.stopImmediatePropagation(); }
      else if (enabled && k === 'z') { undo(); e.preventDefault(); e.stopImmediatePropagation(); }
      else if (enabled && e.key === 'Escape') { toggle(false); e.preventDefault(); e.stopImmediatePropagation(); }
    }, true);
    // 창 전체 capture — 받아들인 포인터(펜슬 · 마우스, 손가락은 설정에 따라)만 그리고 막는다. 손가락 넘기기 · 도구 상자는 그대로 지나간다
    var Ink = window.LectureInk || { accepts: function () { return true; }, skip: function () { return false; } };
    var swallowClick = false;
    window.addEventListener('pointerdown', function (e) {
      if (!enabled || Ink.skip(e.target) || !Ink.accepts(e)) return;
      e.preventDefault(); e.stopPropagation(); swallowClick = true;
      if (activeId !== null || e.button !== 0 || !e.isPrimary) return;
      activeId = e.pointerId; cur = [toStage(e)]; strokes.push(cur); hover = [e.clientX, e.clientY]; paint();
    }, true);
    window.addEventListener('pointermove', function (e) {
      if (!enabled) return;
      if (activeId !== null) {
        if (e.pointerId !== activeId) return;
        e.preventDefault(); e.stopPropagation();
        hover = [e.clientX, e.clientY];
        var q = toStage(e), l = cur[cur.length - 1];
        if (Math.hypot(q[0] - l[0], q[1] - l[1]) >= 1.5) cur.push(q);
        paint(); return;
      }
      if (e.pointerType === 'mouse' && !Ink.skip(e.target)) {
        hover = [e.clientX, e.clientY]; paint();
        // 녹화 중 도구막대가 계속 뜨지 않게 — 화면 아래쪽에서만 HUD 를 깨운다(레이저와 같음)
        if (e.clientY < window.innerHeight - 90) e.stopPropagation();
      }
    }, true);
    function end(e) {
      if (activeId === null || e.pointerId !== activeId) return;
      e.preventDefault(); e.stopPropagation();
      if (cur) { var q = toStage(e), l = cur[cur.length - 1]; if (q[0] !== l[0] || q[1] !== l[1]) cur.push(q); }
      release(); if (e.pointerType !== 'mouse') hover = null; paint();
    }
    window.addEventListener('pointerup', end, true);
    window.addEventListener('pointercancel', function (e) { if (e.pointerId === activeId) release(); }, true);
    window.addEventListener('click', function (e) { if (swallowClick) { swallowClick = false; e.preventDefault(); e.stopPropagation(); } }, true);
    window.addEventListener('contextmenu', function (e) { if (enabled && !Ink.skip(e.target)) { e.preventDefault(); e.stopPropagation(); } }, true);
    document.addEventListener('mouseleave', function () { if (enabled && activeId === null) { hover = null; paint(); } });
    // 다른 장면으로 가면 지운다(같은 장면의 단계 이동·다시 보기는 남김)
    new MutationObserver(function () {
      if (Deck.i !== lastScene) { lastScene = Deck.i; if (strokes.length) clear(); }
    }).observe(document.getElementById('count'), { childList: true, subtree: true, characterData: true });
    lastScene = Deck.i;
    // 레이저를 켜면 펜은 꺼진다
    var laserBtn = document.getElementById('lecture-laser-toggle');
    if (laserBtn) new MutationObserver(function () { if (enabled && laserBtn.getAttribute('aria-pressed') === 'true') toggle(false); }).observe(laserBtn, { attributes: true, attributeFilter: ['aria-pressed'] });
    window.addEventListener('resize', resize);
    document.addEventListener('fullscreenchange', resize);
    window.addEventListener('blur', release);
    document.addEventListener('visibilitychange', function () { if (document.hidden) release(); });
    window.addEventListener('pagehide', release);
    resize();
    window.LecturePen = Object.freeze({
      setEnabled: toggle, clear: clear, undo: undo,
      get enabled() { return enabled; }, get drawing() { return activeId !== null; }, get strokes() { return strokes.length; }
    });
  }
  // 엔진(DOMContentLoaded 타이머) → 레이저 → 펜 순서로 붙는다
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(function () { setTimeout(mount, 0); }, 0); });
  else setTimeout(function () { setTimeout(mount, 0); }, 0);
})();
