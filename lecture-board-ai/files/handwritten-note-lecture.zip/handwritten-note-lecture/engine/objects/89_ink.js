/* 판서 입력 규칙(window.LectureInk) v1 — 2026-11-04 아이패드 수업 요청
 * canonical: 전기강의_빌드/objects/89_ink.js (기체압력강의_빌드 · 소비전력강의_빌드 objects/ 에 같은 사본)
 * · 레이저(90_laser.js) · 펜(91_pen.js) · 도구 상자(93_toolbox.js)가 함께 쓰는 «누가 그릴 수 있나» 규칙.
 *   펜슬(pointerType 'pen') · 마우스는 늘 그린다. 손가락(touch)은 «손가락 그리기» 설정을 따른다:
 *     auto(기본) — 이 기기에서 펜슬을 한 번도 안 썼으면 손가락도 그림(전자칠판), 펜슬이 한 번 감지되면 그때부터 손가락은 화면 넘기기만(굿노트처럼).
 *     on — 손가락도 늘 그림 · off — 손가락은 늘 넘기기만.  (localStorage: lecture_ink_touch · lecture_ink_pen)
 * · 도구 상자 · HUD · 메모 · 전체 보기 위를 누르면 그리지 않는다(skip).
 * · 전체 화면이거나 판서 도구가 켜져 있으면 화면을 끄는 «아래로 쓸어내리기» 같은 기본 터치 동작을 막는다(touchstart · touchmove).
 *   그래도 사파리가 전체 화면을 끄면: 공유 → 「홈 화면에 추가」로 연다(frame.html 의 apple-mobile-web-app-capable — 주소창 없는 앱 화면, 끄는 동작 없음).
 */
(function () {
  'use strict';
  if (window.LectureInk) return;
  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };
  var mode = store.get('lecture_ink_touch') || 'auto';
  if (['auto', 'on', 'off'].indexOf(mode) < 0) mode = 'auto';
  var seenPen = store.get('lecture_ink_pen') === '1';
  var on = {};
  var subs = [];
  function emit() { subs.forEach(function (f) { try { f(); } catch (e) {} }); }
  function anyOn() { for (var k in on) if (on[k]) return true; return false; }
  function isFull() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }
  var style = document.createElement('style');
  style.textContent = 'html,body{overscroll-behavior:none}html.ink-on,html.ink-on body,html.ink-on #viewport{touch-action:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}';
  (document.head || document.documentElement).appendChild(style);
  var SKIP = '#hud,#lecture-tools,#notes,#ov,#help,#kw,#blank,button,a,input,select,textarea,label,[contenteditable],[data-interactive]';
  window.LectureInk = {
    get mode() { return mode; },
    get seenPen() { return seenPen; },
    setMode: function (m) { mode = m; store.set('lecture_ink_touch', m); emit(); },
    allowTouch: function () { return mode === 'on' || (mode === 'auto' && !seenPen); },
    /* 이 포인터로 그려도 되나 — 펜슬이 처음 보이면 기억해 둔다 */
    accepts: function (e) {
      if (e.pointerType === 'pen') { if (!seenPen) { seenPen = true; store.set('lecture_ink_pen', '1'); emit(); } return true; }
      if (e.pointerType === 'touch') return this.allowTouch();
      return true;
    },
    skip: function (t) { return !!(t && t.closest && t.closest(SKIP)); },
    setOn: function (name, v) { on[name] = !!v; document.documentElement.classList.toggle('ink-on', anyOn()); emit(); },
    isOn: function (name) { return !!on[name]; },
    onChange: function (f) { subs.push(f); }
  };
  // 아이패드 사파리는 전체 화면을 «아래로 쓸어내리기»로 끈다 — 끌기(touchmove)만 막아서는 부족해 손가락이 닿는 순간(touchstart)부터 막는다(v2 · 11-08).
  // 화면 넘기기는 포인터 이벤트로 받으므로 그대로 동작한다. 단추 · 링크 · 입력 · 도구 상자 · 메모 · 전체 보기 위는 막지 않는다(그곳은 click 이 필요).
  var FREE = SKIP + ',#notes,#ov,#help';
  document.addEventListener('touchstart', function (e) {
    if (!(anyOn() || isFull())) return;
    if (e.target && e.target.closest && e.target.closest(FREE)) return;
    if (e.cancelable) e.preventDefault();
  }, { passive: false });
  // 전체 화면 · 판서 중에는 화면이 밀리거나(아래로 쓸어 전체 화면 끄기 등) 확대되지 않게 — 메모 · 전체 보기처럼 스크롤이 필요한 곳은 둔다
  document.addEventListener('touchmove', function (e) {
    if (!(anyOn() || isFull())) return;
    if (e.target && e.target.closest && e.target.closest('#notes,#ov,#help,#lecture-tools')) return;
    if (e.cancelable) e.preventDefault();
  }, { passive: false });
  document.addEventListener('gesturestart', function (e) { if (anyOn() || isFull()) e.preventDefault(); });
})();
