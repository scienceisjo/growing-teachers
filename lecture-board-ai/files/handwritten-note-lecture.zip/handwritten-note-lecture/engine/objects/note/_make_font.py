"""손글씨 글꼴 잘라 넣기 — 나눔바른히피에서 slides/ 의 모든 덱에 쓰인 글자만 woff2 로 잘라 00_font.css(base64)로 만든다.
글자를 고치거나 장면을 더하면 build.py 전에 다시 돌린다:  python objects/note/_make_font.py
원본: _src/NanumBaReunHiPi.ttf (네이버 나눔 글꼴 라이선스 — 재배포·수정 허용, 출처 표기 권장. _src/NanumBaReunHiPi_README.md)
"""
import base64, io, pathlib, sys
from fontTools import subset
from fontTools.ttLib import TTFont

sys.stdout.reconfigure(encoding='utf-8')
HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent.parent
texts = []
for p in sorted(ROOT.glob('slides/*/*.html')) + sorted(ROOT.glob('slides/*/*.py')) + sorted(HERE.glob('*.js')) + sorted(ROOT.glob('objects/*/*.js')):
    texts.append(p.read_text(encoding='utf-8'))
chars = set(''.join(texts)) | set(chr(c) for c in range(0x20, 0x7f)) | set('·…→←↑↓−–—×÷=≠≈①②③④⑤ㄱㄴㄷㄹ‘’“”「」★⏸')
font = TTFont(HERE / '_src' / 'NanumBaReunHiPi.ttf')
cmap = font.getBestCmap()
have = sorted(c for c in chars if (ord(c) in cmap and not c.isspace()) or c == ' ')
miss = sorted(c for c in chars if ord(c) not in cmap and not c.isspace() and ord(c) > 0x7f)
opt = subset.Options(); opt.flavor = 'woff2'; opt.layout_features = ['*']; opt.name_IDs = ['*']; opt.notdef_outline = True
sub = subset.Subsetter(opt); sub.populate(unicodes=[ord(c) for c in have]); sub.subset(font)
buf = io.BytesIO(); font.flavor = 'woff2'; font.save(buf)
b64 = base64.b64encode(buf.getvalue()).decode()
css = ('/* 00_font.css — _make_font.py 가 만든 파일(손대지 말 것). 이 덱에는 네이버에서 제공한 나눔바른히피 글꼴이 적용되어 있습니다. */\n'
       f"@font-face{{font-family:'NoteHand';src:url(data:font/woff2;base64,{b64}) format('woff2');font-display:block}}\n")
(HERE / '00_font.css').write_text(css, encoding='utf-8')
print(f'글자 {len(have)}개 → woff2 {len(buf.getvalue())/1024:.0f} KB · 글꼴에 없는 글자(대체 글꼴로 보임): {"".join(miss)}')
