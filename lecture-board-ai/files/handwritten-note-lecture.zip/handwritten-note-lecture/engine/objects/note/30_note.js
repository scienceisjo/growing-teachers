/* ═══════════════════════════════════════════════════════════════
   objects/note/30_note.js — 「손글씨 노트」 강의 도우미 (window.NT)
   · 모든 .slide.note 에 머리줄(단원 이름 · 편 이름 · 만든 사람 계정)과 연필촉을 넣는다(엔진이 처음 상태를 저장하기 전).
     편 이름은 문서 제목(build.py DECKS title 「개념 노트 · 02 정전기 유도」)에서 읽는다. 단원 이름 · 편 이름 · 만든 사람은
     decks.json 의 'unit' · 'ep' · 'by'(window.NT_UNIT · NT_EP · NT_BY).
   · NT.run(c, k) — k 단계에 나올 것을 «한 번에 하나씩» 차례로(2026-11-02 선생님: 여러 줄이 동시에 써지면 어딜 볼지 모름).
       [data-w="k"]  손으로 쓰기(왼쪽부터 드러나고 연필촉이 끝을 따라감) — 실제로 써지는 것은 NT.hand(el): 장면 제목(.sec · .star)과
                     줄 대부분이 형광펜인 핵심 문장뿐. 나머지 data-w 줄은 한 줄 통째로 짧게 떠오른 뒤 형광펜만 칠해진다
       [data-s="k"]  짧게 떠오르기(data-fx: rise·fade·pop·draw·left·right·up·scale·wipe) — 이름표·예시·보기·그림
       mark[data-h="k"]  형광펜만 따로 칠하기 · 쓴 줄 안의 <mark> 는 다 쓴 뒤 저절로 칠해진다
       [data-cue="이름"] (data-s 와 함께) 장면 정의의 cue[이름](c, 시작ms) 을 부르고 돌려준 길이(ms)만큼 기다린다(그림 움직임)
       data-with   바로 앞 항목과 같이 시작(한 덩어리 — 원 두 개, 화살표 두 개처럼)
       data-pause="ms"  시작 전에 더 쉼 · data-dur="ms" 길이
     순서 = 문서 순서. HTML 과 SVG 를 섞어야 하면 <svg class="full-svg"> 를 여러 겹으로 끼워 순서를 맞춘다.
     c.tween / c.reveal 만 쓰므로 되돌리기·점프(순간 모드)에서도 같은 끝 상태. cue 의 tween 은 {noInit:true, delay} 로 미리 걸어 둔다.
   · NT.scene(id, { steps: N, build, enter(c,t), go(c,k,t), cue:{…} }) — build.py 가 manifest 단계 수를 «steps: N» 글자로 읽으므로 이 꼴을 지킨다.
   · 그리기(문자열 SVG): NT.pc 전하 · NT.ar 열린 화살표 · NT.cur 빨간 전류 화살표 · 회로 NT.wire/res/bulb/batt/sw/meter/dot
     자석·나침반 NT.magnet/compass · 코일 NT.coil(원통 코일) · NT.ring(원형 도선) · 자기력선 NT.field
     코일·원형 도선의 방향 약속은 _템플릿/코일그림_1005.py 와 같다: 앞쪽 도선 전류 위 → 코일 안 자기장 왼쪽 → N극 왼쪽.
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  const NT = window.NT = {};
  const t = (document.title || '').split('·').slice(1).join('·').trim();
  NT.EP = window.NT_EP || t || '';
  NT.UNIT = window.NT_UNIT || '';
  NT.BY = window.NT_BY || '';
  const NIB = '<svg viewBox="0 0 44 44" width="44" height="44" aria-hidden="true"><path d="M13 29 35 7l4 4-22 22z" fill="#f2c14e" stroke="#6b5420" stroke-width="1.6" stroke-linejoin="round"/><path d="M13 29l4 4-12 6z" fill="#f6e3c0" stroke="#6b5420" stroke-width="1.6" stroke-linejoin="round"/><path d="M5 39l3.2-6.4 3.2 3.2z" fill="#2a3540"/></svg>';

  const defs = document.querySelector('#gdefs defs');
  if (defs && !document.getElementById('note-rough')) {
    defs.insertAdjacentHTML('beforeend', '<filter id="note-rough" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="7" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="2.6" xChannelSelector="R" yChannelSelector="G"/></filter>');
  }
  document.querySelectorAll('#stage > section.slide.note').forEach(sec => {
    if (!sec.querySelector('.nt-top')) {
      const d = document.createElement('div'); d.className = 'nt-top';
      d.innerHTML = `<span>${NT.UNIT ? NT.UNIT + ' · ' : ''}${NT.EP}</span><span>${NT.BY}</span>`;
      sec.insertBefore(d, sec.firstChild);
    }
    if (!sec.querySelector('.nt-nib')) {
      const n = document.createElement('div'); n.className = 'nt-nib'; n.innerHTML = NIB; sec.appendChild(n);
    }
  });

  /* ───────── 차례대로 나오기 ───────── */
  const DUR = { rise: 800, fade: 650, blur: 1000, scale: 800, pop: 650, left: 800, right: 800, down: 800, up: 900, draw: 1100, wipe: 900, none: 1 };
  function rel(el, root) {
    const r = el.getBoundingClientRect(), R = root.getBoundingClientRect(), s = (window.Deck && Deck.scale) || 1;
    return { x: (r.left - R.left) / s, y: (r.top - R.top) / s, w: r.width / s, h: r.height / s };
  }
  function sweep(c, m, delay, speed) {
    const dur = Math.round(420 * Math.max(.5, speed));
    c.tween(dur, p => { m.style.setProperty('--hp', (p * 100).toFixed(1) + '%'); }, { delay, ease: 'inOut', noInit: true });
    return delay + dur;
  }
  function write(c, el, delay, speed) {
    const len = (el.textContent || '').replace(/\s+/g, '').length;
    const dur = el.dataset.dur ? +el.dataset.dur : Math.round(Math.max(320, Math.min(2000, 200 + len * 58)) * speed);
    const nib = c.root.querySelector('.nt-nib');
    let box = null;
    c.tween(dur, p => {
      el.style.opacity = '1';
      el.style.clipPath = p >= 1 ? 'none' : `inset(-30% ${((1 - p) * 100).toFixed(2)}% -30% -4%)`;
      if (!nib) return;
      if (p <= 0 || p >= 1 || c.instant || c.reduced) { if (p >= 1 || c.instant) nib.style.opacity = '0'; return; }
      if (!box) box = rel(el, c.root);
      nib.style.opacity = '1';
      nib.style.transform = `translate(${(box.x + box.w * p).toFixed(1)}px,${(box.y + box.h * .8).toFixed(1)}px)`;
    }, { delay, ease: 'linear' });
    let tt = delay + dur;
    el.querySelectorAll('mark:not([data-h])').forEach(m => { tt = sweep(c, m, tt + 60, speed); });
    return tt;
  }
  /* 떠오르기도 쓰기와 같은 시계(c.tween)로 — 브라우저 애니메이션 시계와 섞이면 순서가 어긋나 겹쳐 보였다(2026-11-02 검사) */
  const GEOM = 'path,line,polyline,polygon,circle,ellipse,rect';
  const isSvg = el => el instanceof SVGElement && !(el instanceof SVGSVGElement);
  function reveal(c, el, fx, delay, dur) {
    const JE = Deck.JE, svg = isSvg(el);
    if (svg && (fx === 'pop' || fx === 'scale')) { el.style.transformBox = 'fill-box'; el.style.transformOrigin = 'center'; }
    const geo = fx === 'draw' ? (el.matches(GEOM) ? [el] : Array.from(el.querySelectorAll(GEOM))) : null;
    if (geo) geo.forEach(g => { if (!g.hasAttribute('pathLength')) g.setAttribute('pathLength', '1'); g.style.strokeDasharray = '1 1'; g.style.strokeDashoffset = '1'; });
    if (!c.instant && (fx === 'pop' || fx === 'up')) c.sfx('pop', delay);
    c.tween(dur, (p, raw) => {
      const e = fx === 'pop' ? JE.spring(raw) : fx === 'draw' || fx === 'wipe' ? JE.inOut(raw) : JE.out(raw), o = Math.min(1, raw * (fx === 'pop' ? 2.2 : 1.6));
      if (fx === 'draw') { el.style.opacity = raw > 0 ? '1' : '0'; geo.forEach(g => { g.style.strokeDashoffset = String(1 - e); }); }
      else if (fx === 'wipe') { el.style.opacity = '1'; el.style.clipPath = raw >= 1 ? 'none' : `inset(0 ${((1 - e) * 100).toFixed(1)}% 0 0)`; }
      else {
        el.style.opacity = raw >= 1 ? '1' : o.toFixed(3);
        const d = 1 - e;
        el.style.transform = raw >= 1 ? '' :
          fx === 'rise' ? `translateY(${(d * 26).toFixed(1)}px)` : fx === 'up' ? `translateY(${(d * 60).toFixed(1)}px)` : fx === 'down' ? `translateY(${(-d * 26).toFixed(1)}px)` :
          fx === 'left' ? `translateX(${(-d * 60).toFixed(1)}px)` : fx === 'right' ? `translateX(${(d * 60).toFixed(1)}px)` :
          fx === 'pop' ? `scale(${(.55 + .45 * e).toFixed(3)})` : fx === 'scale' ? `scale(${(.92 + .08 * e).toFixed(3)})` : '';
      }
      if (raw > 0 && raw < 1) el.setAttribute('data-ntp', raw.toFixed(2)); else el.removeAttribute('data-ntp');
    }, { delay, ease: 'linear', noInit: true });
  }
  /* 손으로 써지는 효과를 줄 줄 — 장면 제목(.sec · .star)과 줄 전체(60% 이상)가 형광펜인 핵심 문장 · data-hand 로 강제(1 = 쓰기 · 0 = 띄우기) */
  NT.hand = el => {
    if (el.dataset.hand) return el.dataset.hand === '1';
    if (el.classList.contains('sec') || el.classList.contains('star')) return true;
    const all = (el.textContent || '').replace(/\s+/g, '').length;
    let hl = 0; el.querySelectorAll('mark').forEach(m => { hl += (m.textContent || '').replace(/\s+/g, '').length; });
    return all > 0 && hl / all >= .6;
  };
  NT.run = function (c, k, def = {}) {
    const speed = +(c.root.dataset.wspeed || 1);
    const K = String(k);
    let tcur = 0, prev = 0, end = 0;
    c.$$(`[data-w="${K}"], [data-s="${K}"], mark[data-h="${K}"]`).forEach(el => {
      const withPrev = el.hasAttribute('data-with');
      let start = withPrev ? prev : tcur;
      if (el.dataset.pause) start += +el.dataset.pause;
      // 손으로 쓰기는 앞에 나온 것이 완전히 끝난 뒤에만 시작(겹쳐 써지지 않게)
      if (!withPrev && el.dataset.w === K) start = Math.max(start, end + 60);
      let fin, adv;
      if (el.dataset.w === K && NT.hand(el)) { fin = write(c, el, start, speed); adv = fin; }
      else if (el.dataset.w === K) {
        // 제목 · 핵심 문장이 아닌 줄은 글자마다 쓰지 않고 한 줄을 통째로 짧게 띄운다(2026-11-04 「다 써지니 정신없다」) · 형광펜은 뒤이어 칠한다
        const dur = Math.round(520 * (speed < 1 ? Math.max(.6, speed) : 1));
        reveal(c, el, 'rise', start, dur);
        let tt = start + dur;
        el.querySelectorAll('mark:not([data-h])').forEach(m => { tt = sweep(c, m, tt + 40, speed); });
        fin = tt; adv = start + dur * .7;
      }
      else if (el.tagName === 'MARK' && el.dataset.h === K) { fin = sweep(c, el, start, speed); adv = fin; }
      else if (el.dataset.cue) {
        const fn = def.cue && def.cue[el.dataset.cue];
        let d = 0;
        try { d = fn ? (fn(c, start) || 0) : 0; } catch (e) { console.error('[cue ' + el.dataset.cue + ']', e); }
        fin = start + d; adv = fin;
      } else {
        const fx = el.dataset.fx || 'rise';
        const dur = el.dataset.dur ? +el.dataset.dur : Math.round((DUR[fx] || 800) * (speed < 1 ? Math.max(.55, speed) : 1));
        reveal(c, el, fx, start, dur);
        fin = start + dur; adv = start + dur * (fx === 'draw' ? .85 : .7);
      }
      prev = start;
      tcur = Math.max(tcur, adv + 90);
      end = Math.max(end, fin);
    });
    if (!c.instant) c.data.ntEnd = Math.max(c.data.ntEnd || 0, performance.now() + end);   // 검사 도구(note_seq.mjs)가 읽는 끝 시각
    return end;
  };
  NT.scene = function (id, def = {}) {
    Deck.scene(id, {
      steps: def.steps || 0,
      build: def.build,
      async enter(c) { const tt = NT.run(c, 0, def); if (def.enter) await def.enter(c, tt); },
      async go(c, k) { const tt = NT.run(c, k, def); if (def.go) await def.go(c, k, tt); },
    });
  };
  /* cue 안에서 쓰는 미리 걸어 두는 트윈: NT.tw(c, 시작, 길이, fn, ease) → 끝 시각 */
  NT.tw = (c, start, dur, fn, ease = 'inOut') => { c.tween(dur, fn, { delay: start, ease, noInit: true }); return start + dur; };

  /* ───────── 그리기 ───────── */
  const f = v => Math.round(v * 10) / 10;
  NT.f = f;
  NT.POS = '#c0392b'; NT.NEG = '#2a5a9c'; NT.INK = '#3a4856';
  NT.CUR = '#e0402a'; NT.WIRE = '#8a5a2b'; NT.WIRE_B = '#c9a27a'; NT.LEAD = '#4a3a26';
  NT.FIELD = '#2f7d4c'; NT.FIELD8 = '#2a67a8'; NT.FORCE = '#2f8a57';
  NT.NRED = '#c0453b'; NT.SBLUE = '#3a6ea8';
  NT.pc = (x, y, s, o = {}) => EL.charge(x, y, s, Object.assign({ r: 22, sw: 3, fill: .05, color: s === '+' ? NT.POS : NT.NEG }, o));
  NT.ar = (x1, y1, x2, y2, o = {}) => {
    const col = o.color || NT.INK, w = o.w || 4, h = o.head || 20, L = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / L, uy = (y2 - y1) / L;
    const bx = x2 - ux * h, by = y2 - uy * h, px = -uy * h * .6, py = ux * h * .6;
    return `<g${o.cls ? ` class="${o.cls}"` : ''}><line x1="${f(x1)}" y1="${f(y1)}" x2="${f(x2)}" y2="${f(y2)}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"${o.dash ? ` stroke-dasharray="${o.dash}"` : ''}/>` +
      `<path d="M${f(bx + px)} ${f(by + py)}L${f(x2)} ${f(y2)}L${f(bx - px)} ${f(by - py)}" fill="none" stroke="${col}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/></g>`;
  };
  /* 빨간 전류 화살표(굵게 · 채운 큰 화살촉 — 코일그림 약속) */
  NT.cur = (x1, y1, x2, y2, o = {}) => {
    const col = o.color || NT.CUR, w = o.w || 6, hl = o.hl || 26, hw = o.hw || 14, L = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / L, uy = (y2 - y1) / L;
    const bx = x2 - ux * hl, by = y2 - uy * hl, nx = -uy, ny = ux;
    return `<g${o.cls ? ` class="${o.cls}"` : ''}><line x1="${f(x1)}" y1="${f(y1)}" x2="${f(bx + ux * 2)}" y2="${f(by + uy * 2)}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"/>` +
      `<polygon points="${f(x2)},${f(y2)} ${f(bx + nx * hw)},${f(by + ny * hw)} ${f(bx - nx * hw)},${f(by - ny * hw)}" fill="${col}"/></g>`;
  };
  NT.head = (px, py, dx, dy, col, s = 1) => {
    const n = Math.hypot(dx, dy) || 1; dx /= n; dy /= n; const nx = -dy, ny = dx;
    const tip = 22 * s, back = 14 * s, half = 15 * s;
    return `<polygon points="${f(px + tip * dx)},${f(py + tip * dy)} ${f(px - back * dx + half * nx)},${f(py - back * dy + half * ny)} ${f(px - back * dx - half * nx)},${f(py - back * dy - half * ny)}" fill="${col}" stroke="#fff" stroke-width="2.6" stroke-linejoin="round" paint-order="stroke"/>`;
  };
  /* 회로 — 잉크 #4a3a26, 굵기 5 (1920 무대) · 전구 = 원 + 안쪽 반원 · 저항 = 지그재그 · 전지 = 긴 얇은 선(+)·짧은 굵은 선(−) */
  const SW = 5;
  NT.wire = (pts, o = {}) => `<polyline points="${pts.map(p => f(p[0]) + ',' + f(p[1])).join(' ')}" fill="none" stroke="${o.color || NT.LEAD}" stroke-width="${o.w || SW}" stroke-linejoin="round" stroke-linecap="round"/>`;
  NT.dot = (x, y, r = 8) => `<circle cx="${f(x)}" cy="${f(y)}" r="${r}" fill="${NT.LEAD}"/>`;
  NT.res = (x1, x2, y, o = {}) => {   // 가로 저항: 양 끝 도선 포함(x1~x2), 가운데 지그재그
    const L = x2 - x1, a = x1 + L * .18, b = x2 - L * .18, n = 6, amp = o.amp || 22, step = (b - a) / n;
    let d = `M${f(x1)} ${f(y)}L${f(a)} ${f(y)}`;
    for (let i = 0; i < n; i++) d += `L${f(a + step * (i + .5))} ${f(y + (i % 2 ? amp : -amp))}`;
    d += `L${f(b)} ${f(y)}L${f(x2)} ${f(y)}`;
    return `<path d="${d}" fill="none" stroke="${o.color || NT.LEAD}" stroke-width="${o.w || SW}" stroke-linejoin="round" stroke-linecap="round"/>`;
  };
  NT.resV = (x, y1, y2, o = {}) => {
    const L = y2 - y1, a = y1 + L * .18, b = y2 - L * .18, n = 6, amp = o.amp || 22, step = (b - a) / n;
    let d = `M${f(x)} ${f(y1)}L${f(x)} ${f(a)}`;
    for (let i = 0; i < n; i++) d += `L${f(x + (i % 2 ? amp : -amp))} ${f(a + step * (i + .5))}`;
    d += `L${f(x)} ${f(b)}L${f(x)} ${f(y2)}`;
    return `<path d="${d}" fill="none" stroke="${o.color || NT.LEAD}" stroke-width="${o.w || SW}" stroke-linejoin="round" stroke-linecap="round"/>`;
  };
  NT.bulb = (cx, cy, r = 34, o = {}) => {   // 원 + 안쪽 반원(필라멘트). o.glow: 0~1 밝기(빛 번짐 원), o.id
    const g = o.glow == null ? '' : `<circle${o.gid ? ` id="${o.gid}"` : ''} cx="${f(cx)}" cy="${f(cy)}" r="${f(r * 2.1)}" fill="#ffd34d" opacity="${o.glow}" filter="url(#bloom-m)"/>`;
    const fill = o.fill || '#fffdf6';
    const fil = o.vert
      ? `<path d="M${f(cx - r * .02)} ${f(cy - r * .5)}A${f(r * .5)} ${f(r * .5)} 0 0 0 ${f(cx - r * .02)} ${f(cy + r * .5)}" fill="none" stroke="${NT.LEAD}" stroke-width="${SW * .8}"/>`
      : `<path d="M${f(cx - r * .5)} ${f(cy + r * .02)}A${f(r * .5)} ${f(r * .5)} 0 0 1 ${f(cx + r * .5)} ${f(cy + r * .02)}" fill="none" stroke="${NT.LEAD}" stroke-width="${SW * .8}"/>`;
    return g + `<circle cx="${f(cx)}" cy="${f(cy)}" r="${r}" fill="${fill}" stroke="${NT.LEAD}" stroke-width="${SW}"/>` + fil;
  };
  NT.batt = (x, y, o = {}) => {   // 가로 도선 사이 전지: plus 'right'|'left'. 판 사이 20. o.vert 면 세로 도선 사이(plus 'up'|'down')
    const h = o.h || 74, lab = o.label !== false, ink = '#2e2315';
    if (o.vert) {
      const yt = y - 10, yb = y + 10, up = (o.plus || 'up') === 'up';
      const long = (yy) => `<line x1="${f(x - h / 2)}" y1="${f(yy)}" x2="${f(x + h / 2)}" y2="${f(yy)}" stroke="${ink}" stroke-width="5"/>`;
      const short = (yy) => `<line x1="${f(x - h * .28)}" y1="${f(yy)}" x2="${f(x + h * .28)}" y2="${f(yy)}" stroke="${ink}" stroke-width="13"/>`;
      let s = up ? long(yt) + short(yb) : short(yt) + long(yb);
      if (lab) s += `<text x="${f(x + h / 2 + 14)}" y="${f((up ? yt : yb) + 12)}" font-size="34" fill="#55626e">(+)</text><text x="${f(x + h / 2 + 14)}" y="${f((up ? yb : yt) + 14)}" font-size="34" fill="#55626e">(−)</text>`;
      return s;
    }
    const xl = x - 10, xr = x + 10, right = (o.plus || 'right') === 'right';
    const long = (xx) => `<line x1="${f(xx)}" y1="${f(y - h / 2)}" x2="${f(xx)}" y2="${f(y + h / 2)}" stroke="${ink}" stroke-width="5"/>`;
    const short = (xx) => `<line x1="${f(xx)}" y1="${f(y - h * .28)}" x2="${f(xx)}" y2="${f(y + h * .28)}" stroke="${ink}" stroke-width="13"/>`;
    let s = right ? short(xl) + long(xr) : long(xl) + short(xr);
    if (lab) s += `<text x="${f(xl - 8)}" y="${f(y + h / 2 + 38)}" text-anchor="end" font-size="34" fill="#55626e">${right ? '(−)' : '(+)'}</text><text x="${f(xr + 8)}" y="${f(y + h / 2 + 38)}" font-size="34" fill="#55626e">${right ? '(+)' : '(−)'}</text>`;
    return s;
  };
  NT.sw = (x1, x2, y, closed = true) => {
    const ink = '#2e2315', L = x2 - x1;
    return `<circle cx="${f(x1)}" cy="${f(y)}" r="9" fill="#fff" stroke="${ink}" stroke-width="4"/><circle cx="${f(x2)}" cy="${f(y)}" r="9" fill="#fff" stroke="${ink}" stroke-width="4"/>` +
      (closed ? `<line x1="${f(x1 + 6)}" y1="${f(y - 3)}" x2="${f(x2 - 6)}" y2="${f(y - 3)}" stroke="${ink}" stroke-width="6" stroke-linecap="round"/>`
        : `<line x1="${f(x1 + 6)}" y1="${f(y - 4)}" x2="${f(x1 + L * .86)}" y2="${f(y - L * .55)}" stroke="${ink}" stroke-width="6" stroke-linecap="round"/>`);
  };
  NT.meter = (cx, cy, letter = 'A', r = 34) => `<circle cx="${f(cx)}" cy="${f(cy)}" r="${r}" fill="#fffdf6" stroke="${NT.LEAD}" stroke-width="${SW}"/><text x="${f(cx)}" y="${f(cy + r * .38)}" text-anchor="middle" font-size="${f(r * 1.1)}" font-weight="700" fill="${letter === 'A' ? '#a05c2c' : '#7d5ba6'}">${letter}</text>`;
  /* 자석(가로): left = 왼쪽 극 이름 */
  NT.magnet = (x, y, w = 260, h = 84, left = 'S', o = {}) => {
    const right = left === 'S' ? 'N' : 'S', cl = left === 'S' ? NT.SBLUE : NT.NRED, cr = left === 'S' ? NT.NRED : NT.SBLUE;
    const fs = o.fs || h * .55;
    return `<g${o.cls ? ` class="${o.cls}"` : ''}><rect x="${f(x)}" y="${f(y - h / 2)}" width="${f(w / 2)}" height="${f(h)}" rx="8" fill="${cl}"/><rect x="${f(x + w / 2)}" y="${f(y - h / 2)}" width="${f(w / 2)}" height="${f(h)}" rx="8" fill="${cr}"/>` +
      `<text x="${f(x + w / 4)}" y="${f(y + fs * .36)}" text-anchor="middle" font-size="${f(fs)}" font-weight="700" fill="#fff">${left}</text><text x="${f(x + 3 * w / 4)}" y="${f(y + fs * .36)}" text-anchor="middle" font-size="${f(fs)}" font-weight="700" fill="#fff">${right}</text></g>`;
  };
  /* 나침반: 바늘은 <g class="ndl"> 로 따로(회전시키려고). ang = N극 방향(도, 화면 위 = 0, 시계 방향 +) */
  NT.compass = (cx, cy, r = 40, ang = 0, o = {}) => {
    const L = r * .78, w = r * .2;
    return `<g${o.cls ? ` class="${o.cls}"` : ''}><circle cx="${f(cx)}" cy="${f(cy)}" r="${r}" fill="#fdfbf6" stroke="#4a3a26" stroke-width="4"/>` +
      `<g transform="translate(${f(cx)} ${f(cy)})"><g class="ndl" transform="rotate(${f(ang)})"><polygon points="0,${f(-L)} ${f(w)},0 ${f(-w)},0" fill="${NT.NRED}"/><polygon points="0,${f(L)} ${f(w)},0 ${f(-w)},0" fill="#a9b2bb"/></g></g>` +
      `<circle cx="${f(cx)}" cy="${f(cy)}" r="4.5" fill="#2e2315"/></g>`;
  };
  /* 원통에 감은 코일(축 가로). current: null|'up'|'down' — 앞쪽 도선 전류. 'up' = 왼쪽 끝 도선으로 들어감 → N극 왼쪽 */
  NT.coil = (pid, x0, cy, L, r, turns, current = null, o = {}) => {
    const m = o.m || Math.max(22, L * .08), p = (L - 2 * m) / turns, xs = x0 + m, yT = cy - r, yB = cy + r, oo = 9;
    const back = [], front = [], hooks = [], arr = [];
    for (let i = 0; i < turns; i++) {
      const xb0 = xs + i * p, xt = xb0 + p / 2, xb1 = xs + (i + 1) * p;
      back.push(`<line x1="${f(xt + 3)}" y1="${f(yT + 2)}" x2="${f(xb1 - 3)}" y2="${f(yB - 2)}" stroke="${NT.WIRE_B}" stroke-width="4.5" stroke-linecap="round"/>`);
      front.push(`<line x1="${f(xb0)}" y1="${f(yB + 2)}" x2="${f(xt)}" y2="${f(yT - 2)}" stroke="${NT.WIRE}" stroke-width="7" stroke-linecap="round"/>`);
      hooks.push(`<path d="M${f(xt)} ${f(yT - 2)}Q${f(xt + p * .22)} ${f(yT - oo * 2.2)} ${f(xt + p * .38)} ${f(yT + 3)}" fill="none" stroke="${NT.WIRE}" stroke-width="6" stroke-linecap="round"/>`);
      if (i < turns - 1) hooks.push(`<path d="M${f(xb1 - p * .38)} ${f(yB - 3)}Q${f(xb1 - p * .2)} ${f(yB + oo * 2.2)} ${f(xb1)} ${f(yB + 2)}" fill="none" stroke="${NT.WIRE}" stroke-width="6" stroke-linecap="round"/>`);
    }
    const body = `<defs><linearGradient id="${pid}-g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fffaf0"/><stop offset=".5" stop-color="#efe0c4"/><stop offset="1" stop-color="#cdb38b"/></linearGradient></defs>` +
      `<rect x="${f(x0)}" y="${f(yT)}" width="${f(L)}" height="${f(2 * r)}" rx="${f(r * .32)}" fill="${o.core === 'iron' ? '#9aa3ab' : `url(#${pid}-g)`}" stroke="#8e8270" stroke-width="3"/>` +
      `<ellipse cx="${f(x0 + r * .32)}" cy="${f(cy)}" rx="${f(r * .32)}" ry="${f(r)}" fill="${o.core === 'iron' ? '#c5ccd2' : '#f7ecd7'}" stroke="#8e8270" stroke-width="3"/>`;
    if (current) {
      const up = current === 'up', dx = up ? p / 2 : -p / 2, dy = up ? -(2 * r) : 2 * r;
      for (let i = 0; i < turns; i++) {
        if (i % 2 === (turns % 2 ? 0 : 1)) continue;
        const mx = xs + i * p + p / 4, my = cy;
        arr.push(`<g class="ca">${NT.head(mx - dx * .1, my - dy * .1, dx, dy, NT.CUR, o.ah || 1)}</g>`);
      }
    }
    return { svg: back.join('') + body + front.join('') + hooks.join('') + arr.join(''), back: back.join(''), body, front: front.join('') + hooks.join(''), arrows: arr.join(''),
      left: [xs, yB + 2], right: [xs + turns * p, yB - 2], N: current ? (current === 'up' ? 'left' : 'right') : null, x1: x0 + L, yT, yB, p, xs };
  };
  /* 세워 놓은 원형 도선(축 가로): 앞쪽 반 = 왼쪽 반(진하게), 뒤쪽 반 = 오른쪽 반(옅은 점선). up: 앞쪽 도선 전류가 위 → 가운데 자기장 왼쪽 */
  NT.ring = (cx, cy, rx, ry, up = true, o = {}) => {
    let s = `<path d="M${f(cx)} ${f(cy - ry)}A${f(rx)} ${f(ry)} 0 0 1 ${f(cx)} ${f(cy + ry)}" fill="none" stroke="${NT.WIRE_B}" stroke-width="7" stroke-dasharray="12 10" opacity=".8"/>` +
      `<path d="M${f(cx)} ${f(cy + ry)}A${f(rx)} ${f(ry)} 0 0 1 ${f(cx)} ${f(cy - ry)}" fill="none" stroke="${NT.WIRE}" stroke-width="10"/>`;
    if (o.arrow !== false) {
      const R1 = rx + 26, R2 = ry + 26, a0 = up ? 150 : 210, a1 = up ? 210 : 150, pts = [];
      for (let k = 0; k <= 20; k++) { const tt = (a0 + (a1 - a0) * k / 20) * Math.PI / 180; pts.push([cx + R1 * Math.cos(tt), cy + R2 * Math.sin(tt)]); }
      s += `<g class="ra"><path d="M${pts.slice(0, -2).map(q => f(q[0]) + ' ' + f(q[1])).join(' L')}" fill="none" stroke="${NT.CUR}" stroke-width="6" stroke-linecap="round"/>` +
        NT.head(pts[pts.length - 2][0], pts[pts.length - 2][1], pts[pts.length - 1][0] - pts[pts.length - 3][0], pts[pts.length - 1][1] - pts[pts.length - 3][1], NT.CUR, 1) + '</g>';
    }
    return s;
  };
  /* 막대자석 바깥 자기력선(두 점극 모형 수치 추적). 자석 중심 (cx,cy), 극 사이 절반 d(N 이 왼쪽이면 nLeft). 돌려줌 path 문자열 묶음 + 화살촉
     선은 N 에서 나와 S 로 들어간다(바깥). o.n = 선 개수(한쪽 반), o.box = [x0,x1,y0,y1] 그릴 범위, o.color */
  NT.field = (cx, cy, d, o = {}) => {
    const nLeft = o.nLeft !== false, xn = cx + (nLeft ? -d : d), xs = cx + (nLeft ? d : -d);
    const box = o.box || [cx - 700, cx + 700, cy - 380, cy + 380], col = o.color || NT.FIELD, n = o.n || 5, out = [];
    const B = (x, y) => {
      const a = x - xn, b = y - cy, c2 = x - xs, e = y - cy;
      const r1 = Math.pow(a * a + b * b, 1.5) || 1e-9, r2 = Math.pow(c2 * c2 + e * e, 1.5) || 1e-9;
      return [a / r1 - c2 / r2, b / r1 - e / r2];
    };
    const angs = o.angs || Array.from({ length: n }, (_, i) => 18 + i * (150 / Math.max(1, n - 1)));
    [1, -1].forEach(sg => angs.forEach(deg => {
      const th = (nLeft ? 180 - deg : deg) * Math.PI / 180;
      let x = xn + Math.cos(th) * (o.r0 || 14), y = cy - sg * Math.sin(th) * (o.r0 || 14);
      const pts = [[x, y]];
      for (let i = 0; i < 4000; i++) {
        const [bx, by] = B(x, y), m = Math.hypot(bx, by) || 1e-9;
        x += bx / m * 4; y += by / m * 4;
        if (i % 3 === 0) pts.push([x, y]);
        if (Math.hypot(x - xs, y - cy) < (o.r0 || 14) || x < box[0] || x > box[1] || y < box[2] || y > box[3]) break;
      }
      pts.push([x, y]);
      if (pts.length < 4) return;
      const dd = 'M' + pts.map(q => f(q[0]) + ' ' + f(q[1])).join('L');
      const mid = pts[Math.floor(pts.length * (o.at || .5))], nx = pts[Math.min(pts.length - 1, Math.floor(pts.length * (o.at || .5)) + 2)];
      out.push(`<g class="fl"><path d="${dd}" fill="none" stroke="${col}" stroke-width="${o.w || 3.2}" opacity="${o.op || .85}"/>` +
        NT.head(mid[0], mid[1], nx[0] - mid[0], nx[1] - mid[1], col, .7) + '</g>');
    }));
    // 두 극을 잇는 가운데 선(바깥쪽): 왼쪽·오른쪽으로 곧게 나가는 선
    if (o.axis !== false) {
      const ex = nLeft ? box[0] : box[1], sx = nLeft ? box[1] : box[0];
      out.push(`<g class="fl"><path d="M${f(xn + (nLeft ? -18 : 18))} ${f(cy)}L${f(ex)} ${f(cy)}" fill="none" stroke="${col}" stroke-width="${o.w || 3.2}" opacity="${o.op || .85}"/>${NT.head((xn + ex) / 2, cy, nLeft ? -1 : 1, 0, col, .7)}</g>`);
      out.push(`<g class="fl"><path d="M${f(sx)} ${f(cy)}L${f(xs + (nLeft ? 18 : -18))} ${f(cy)}" fill="none" stroke="${col}" stroke-width="${o.w || 3.2}" opacity="${o.op || .85}"/>${NT.head((xs + sx) / 2, cy, nLeft ? -1 : 1, 0, col, .7)}</g>`);
    }
    return out.join('');
  };
  /* 자기장 방향(점 위치)의 단위 벡터 — 나침반 바늘 각도 계산용 */
  NT.fieldDir = (cx, cy, d, x, y, nLeft = true) => {
    const xn = cx + (nLeft ? -d : d), xs = cx + (nLeft ? d : -d);
    const a = x - xn, b = y - cy, c2 = x - xs, e = y - cy;
    const r1 = Math.pow(a * a + b * b, 1.5), r2 = Math.pow(c2 * c2 + e * e, 1.5);
    const bx = a / r1 - c2 / r2, by = b / r1 - e / r2, m = Math.hypot(bx, by) || 1;
    return [bx / m, by / m];
  };
  /* 화면 각(위 = 0°, 시계 +) */
  NT.angOf = (dx, dy) => Math.atan2(dx, -dy) * 180 / Math.PI;
  /* ⊙ / ⊗ (빨강) */
  NT.out = (x, y, r = 26, col = NT.CUR) => `<circle cx="${f(x)}" cy="${f(y)}" r="${r}" fill="#fff" stroke="${col}" stroke-width="5"/><circle cx="${f(x)}" cy="${f(y)}" r="${f(r * .25)}" fill="${col}"/>`;
  NT.into = (x, y, r = 26, col = NT.CUR) => { const k = r * .5; return `<circle cx="${f(x)}" cy="${f(y)}" r="${r}" fill="#fff" stroke="${col}" stroke-width="5"/><path d="M${f(x - k)} ${f(y - k)}L${f(x + k)} ${f(y + k)}M${f(x + k)} ${f(y - k)}L${f(x - k)} ${f(y + k)}" stroke="${col}" stroke-width="5" stroke-linecap="round"/>`; };
  /* O / X 판정 표시(그려지는 선) */
  NT.markO = (cx, cy, r = 52) => `<circle class="sk" cx="${f(cx)}" cy="${f(cy)}" r="${r}" fill="none" stroke="#2f7d4c" stroke-width="10"/>`;
  NT.markX = (cx, cy, s = 50) => `<path class="sk" d="M${f(cx - s)} ${f(cy - s * .92)}l${f(2 * s)} ${f(1.84 * s)}M${f(cx + s)} ${f(cy - s * .92)}l${f(-2 * s)} ${f(1.84 * s)}" fill="none" stroke="#d6332a" stroke-width="10" stroke-linecap="round"/>`;
})();
