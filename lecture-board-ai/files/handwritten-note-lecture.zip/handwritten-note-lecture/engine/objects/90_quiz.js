/* objects/90_quiz.js — 문제 장면 도우미: 글이 넘치면 배율(--qz)을 줄여 한 화면에 맞춘다 */
window.QZ = {
  // 등장 효과(translate)는 scrollHeight 를 부풀리므로, 자식들의 실제 높이(offsetHeight, 변형 무시) 합으로 잰다
  need(b) {
    const kids = [...b.children], gap = parseFloat(getComputedStyle(b).rowGap) || 0;
    return kids.reduce((a, e) => a + e.offsetHeight, 0) + gap * Math.max(0, kids.length - 1);
  },
  fit(c) {
    const b = c.$('.qz-body'); if (!b) return;
    let s = 1; b.style.setProperty('--qz', '1');
    for (let i = 0; i < 8 && QZ.need(b) > b.clientHeight; i++) { s -= 0.05; b.style.setProperty('--qz', s.toFixed(2)); }
  },
};
