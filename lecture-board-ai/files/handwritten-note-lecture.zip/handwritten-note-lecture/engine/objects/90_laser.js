/* Lecture laser pointer v3 — canonical: 전기강의_빌드/objects/90_laser.js
 * 소비전력강의_빌드 · 기체압력강의_빌드 objects/90_laser.js are identical build copies.
 * v3 (2026-11-04): the canvas never takes pointer events. Window capture listeners draw only for pointers
 *   that window.LectureInk (89_ink.js) accepts — Apple Pencil · mouse always, fingers by the ink setting —
 *   so finger taps and swipes still reach the deck (and the toolbox) while the laser is on.
 * Hold the full stroke until release; then fade it for 1100 ms.
 * Page-level UI: RAF sleeps while a held stroke is stationary, independently of scene Ctx.
 */
(function () {
  'use strict';
  function mount() {
    if (window.LectureLaser || !window.Deck || !document.getElementById('hud')) return;
    var hud = document.getElementById('hud');
    var canvas = document.createElement('canvas');
    canvas.id = 'lecture-laser';
    canvas.setAttribute('aria-hidden', 'true');
    canvas.hidden = true;
    var style = document.createElement('style');
    style.textContent = '#lecture-laser{position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:49;pointer-events:none;user-select:none;-webkit-user-select:none;}html.laser-on #viewport{cursor:none}#lecture-laser[hidden]{display:none!important}#hud #lecture-laser-toggle[aria-pressed="true"]{background:#c82044;color:#fff;outline:2px solid #fff;outline-offset:2px}@media print{#lecture-laser,#lecture-laser-toggle{display:none!important}}';
    document.head.appendChild(style);
    document.body.appendChild(canvas);
    var ctx = canvas.getContext('2d');
    if (!ctx) { canvas.remove(); style.remove(); return; }
    var button = document.createElement('button');
    button.id = 'lecture-laser-toggle';
    button.type = 'button';
    button.setAttribute('aria-label', '레이저 포인터 켜기/끄기 (L)');
    button.setAttribute('aria-keyshortcuts', 'L');
    button.setAttribute('aria-pressed', 'false');
    button.title = '레이저 포인터 (L) · 누르는 동안 유지 · 떼면 사라짐 · Esc로 끄기';
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m4 19 7-7 3 3-7 7zM14 10l2-2M17 12h4M12 7V3M17 7l3-3"/><circle cx="13" cy="11" r="1.5" fill="currentColor"/></svg>';
    hud.insertBefore(button, hud.querySelector('[data-a="full"]'));
    var table = document.querySelector('#help table');
    if (table) {
      var row = table.insertRow();
      row.innerHTML = '<td><kbd>L</kbd> / <kbd>Esc</kbd></td><td>레이저 켜기·끄기 / 끄기 · 누르는 동안 궤적 유지, 떼면 사라짐 · 방향키로 진행</td>';
    }

    var enabled = false, pointer = null, activeId = null;
    var points = [], strokeId = 0, raf = 0, dpr = 1;
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    var lifetime = 1100;
    function stopFrame() { if (raf) cancelAnimationFrame(raf); raf = 0; }
    function render(now) {
      raf = 0;
      ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
      if (!enabled) return;
      // A null timestamp belongs to the held stroke. Its lifetime starts at pointerup.
      points = points.filter(function (p) { return p.t === null || now - p.t < lifetime; });
      ctx.lineCap = ctx.lineJoin = 'round';
      for (var i = 0; i < points.length; i++) {
        var a = points[i], b = points[i + 1];
        var opacity = a.t === null || reduced.matches ? 1 : Math.max(0, 1 - (now - a.t) / lifetime);
        ctx.globalAlpha = opacity;
        if (!b || a.s !== b.s) {
          // Keep a short tap visible after release, too.
          if (i === 0 || points[i - 1].s !== a.s) {
            ctx.fillStyle = '#f52651'; ctx.beginPath(); ctx.arc(a.x,a.y,2.25,0,Math.PI*2); ctx.fill();
          }
          continue;
        }
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
        ctx.lineWidth = 9; ctx.strokeStyle = 'rgba(180,0,38,.20)'; ctx.stroke();
        ctx.lineWidth = 4.5; ctx.strokeStyle = '#f52651'; ctx.stroke();
        ctx.lineWidth = 1.2; ctx.strokeStyle = '#fff1f4'; ctx.stroke();
      }
      ctx.globalAlpha = 1;
      if (pointer) {
        var glow = ctx.createRadialGradient(pointer.x,pointer.y,2,pointer.x,pointer.y,18);
        glow.addColorStop(0,'rgba(255,35,77,.7)'); glow.addColorStop(1,'rgba(255,35,77,0)');
        ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(pointer.x,pointer.y,18,0,Math.PI*2); ctx.fill();
        ctx.fillStyle = '#eb1243'; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.arc(pointer.x,pointer.y,6,0,Math.PI*2); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(pointer.x,pointer.y,1.8,0,Math.PI*2); ctx.fill();
      }
      if (points.some(function (p) { return p.t !== null; })) raf = requestAnimationFrame(render);
    }
    function paint() { if (!raf) raf = requestAnimationFrame(render); }
    function release() { activeId = null; }
    function clear() {
      release(); pointer = null; points = []; stopFrame();
      ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
    }
    function resize() {
      clear();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.style.width = window.innerWidth + 'px'; canvas.style.height = window.innerHeight + 'px';
      canvas.width = Math.round(window.innerWidth * dpr); canvas.height = Math.round(window.innerHeight * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    function toggle(value) {
      enabled = typeof value === 'boolean' ? value : !enabled;
      clear(); canvas.hidden = !enabled; button.setAttribute('aria-pressed', String(enabled));
      document.documentElement.classList.toggle('laser-on', enabled);
      if (window.LectureInk) LectureInk.setOn('laser', enabled);
      if (enabled) resize();
    }
    function position(e) { return { x:e.clientX, y:e.clientY }; }
    function sample(e, finalPoint) {
      pointer = position(e);
      if (activeId !== null) {
        var last = points[points.length - 1];
        if (!last || last.s !== strokeId || Math.hypot(last.x-pointer.x,last.y-pointer.y) >= 2 || (finalPoint && (last.x !== pointer.x || last.y !== pointer.y))) {
          // Do not truncate the beginning of a long held stroke.
          points.push({x:pointer.x,y:pointer.y,t:null,s:strokeId});
        }
      }
      paint();
    }
    button.addEventListener('click', function (e) { e.stopPropagation(); toggle(); button.blur(); });
    document.addEventListener('keydown', function (e) {
      if (e.ctrlKey || e.metaKey || e.altKey || e.isComposing || (e.target.closest && e.target.closest('input,textarea,select,[contenteditable]'))) return;
      if (e.key.toLowerCase() === 'l') {
        if (!e.repeat) toggle();
        e.preventDefault(); e.stopImmediatePropagation();
      } else if (e.key === 'Escape' && enabled) {
        toggle(false); e.preventDefault(); e.stopImmediatePropagation();
      } else if (enabled) {
        // Arrows, replay, overview, blanking and jumps clear old marks but retain laser mode.
        clear();
      }
    }, true);
    // 그리는 입력은 창 전체에서 먼저 받는다(capture) — 받아들인 포인터만 막고, 나머지(손가락 넘기기 · 도구 상자)는 그대로 흘려보낸다
    var Ink = window.LectureInk || { accepts: function () { return true; }, skip: function () { return false; } };
    var swallowClick = false;
    window.addEventListener('pointerdown', function (e) {
      if (!enabled || Ink.skip(e.target) || !Ink.accepts(e)) return;
      e.preventDefault(); e.stopPropagation(); swallowClick = true;
      if (activeId !== null || e.button !== 0 || !e.isPrimary) return;
      activeId = e.pointerId; strokeId++; sample(e);
    }, true);
    window.addEventListener('pointermove', function (e) {
      if (!enabled) return;
      if (activeId !== null) {
        if (e.pointerId !== activeId) return;
        e.preventDefault(); e.stopPropagation(); sample(e); return;
      }
      if (e.pointerType === 'mouse' && !Ink.skip(e.target)) {
        pointer = position(e); paint();
        // 녹화 중 도구막대가 계속 뜨지 않게 — 화면 아래쪽에서만 HUD 를 깨운다
        if (e.clientY < window.innerHeight - 90) e.stopPropagation();
      }
    }, true);
    function end(e) {
      if (activeId === null || e.pointerId !== activeId) return;
      e.preventDefault(); e.stopPropagation();
      sample(e, true);
      var releasedAt = performance.now();
      points.forEach(function (p) { if (p.s === strokeId && p.t === null) p.t = releasedAt; });
      release();
      if (e.pointerType !== 'mouse') pointer = null;
      if (reduced.matches) points = [];
      paint();
    }
    window.addEventListener('pointerup', end, true);
    window.addEventListener('pointercancel', function (e) { if (e.pointerId === activeId) clear(); }, true);
    window.addEventListener('click', function (e) { if (swallowClick) { swallowClick = false; e.preventDefault(); e.stopPropagation(); } }, true);
    window.addEventListener('contextmenu', function (e) { if (enabled && !Ink.skip(e.target)) { e.preventDefault(); e.stopPropagation(); } }, true);
    document.addEventListener('mouseleave', function () { if (enabled && activeId === null) { pointer = null; paint(); } });
    hud.addEventListener('click', clear, true);
    new MutationObserver(function () { if (enabled) clear(); }).observe(document.getElementById('count'), {childList:true,subtree:true,characterData:true});
    new MutationObserver(function () { if (enabled) clear(); }).observe(document.getElementById('stepdots'), {childList:true});
    window.addEventListener('resize', resize);
    document.addEventListener('fullscreenchange', resize);
    window.addEventListener('blur', clear);
    document.addEventListener('visibilitychange', function () { if (document.hidden) clear(); });
    window.addEventListener('pagehide', clear);
    reduced.addEventListener('change', clear);
    resize();
    window.LectureLaser = Object.freeze({
      setEnabled: toggle, clear: clear,
      get enabled() { return enabled; },
      get drawing() { return activeId !== null; },
      get trailPoints() { return points.length; }
    });
  }
  // The engine boots in its DOMContentLoaded timer, so queue ours immediately after it.
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(mount,0); });
  else setTimeout(mount,0);
})();