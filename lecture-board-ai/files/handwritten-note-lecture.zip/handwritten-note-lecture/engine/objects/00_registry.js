/* ═══════════════════════════════════════════════════════════════
   objects/00_registry.js — 오브젝트(OBJ)·공용 효과(FX) 등록소
   규약(모든 objects/*.js 가 따름):
   · OBJ.def(name, {box:[w,h], svg(o), drive?(ctx, el, o), doc})
       svg(o)  → 문자열. 최상위는 <g class="o-name" id="o.id"> 하나. 좌표는 (0,0)~box 안.
                 그라데이션·필터 id 는 반드시 `${o.id}-무엇` 으로(같은 오브젝트가 여러 장에 나와도 안 겹치게).
                 움직이는 부품에는 class="p-부품" 을 붙인다(ctx.$('#id .p-blades')).
                 색은 에너지 변수(var(--heat) 등)를 style 로 — 면(밝음/어두움)에 따라 저절로 바뀜.
       drive() → 움직임 조종기. ctx.loop/ctx.a/ctx.tween 만 써서(장면을 떠나면 저절로 멈춤) 부품을 움직이고
                 {speed(v,ms), glow(v,ms), …} 같은 메서드를 가진 객체를 돌려준다.
   · OBJ.place(name, {x,y,s,rot, ...o}) → <g transform="translate scale">{svg}</g>
       바깥 g 에 자리(transform 속성), 안쪽 g 는 비워 두어 CSS 애니메이션(등장·확대)이 자리를 덮어쓰지 않게.
   · FX.이름(ctx, 부모g, opts) → 공용 모션 효과. 반환값은 조종기(set…/stop).
   ═══════════════════════════════════════════════════════════════ */
window.OBJ = (function () {
  const R = {};
  const api = {
    R,
    def(name, spec) { R[name] = spec; api[name] = spec; return spec; },
    svg(name, o = {}) { if (!R[name]) { console.error('OBJ 없음:', name); return ''; } o.id = o.id || U.uid(name); return R[name].svg(o); },
    place(name, o = {}) {
      const x = o.x || 0, y = o.y || 0, s = o.s == null ? 1 : o.s, rot = o.rot || 0;
      const tf = `translate(${x} ${y})${s !== 1 ? ` scale(${s})` : ''}${rot ? ` rotate(${rot})` : ''}`;
      return `<g transform="${tf}"${o.wrapId ? ` id="${o.wrapId}"` : ''}${o.wrapClass ? ` class="${o.wrapClass}"` : ''}>${api.svg(name, o)}</g>`;
    },
    drive(name, ctx, el, o = {}) {
      if (!R[name] || !R[name].drive) return null;
      el = typeof el === 'string' ? ctx.$(el) : el;
      if (!el) { console.error('OBJ.drive 대상 없음:', name); return null; }
      return R[name].drive(ctx, el, o);
    },
  };
  return api;
})();
window.FX = window.FX || {};
