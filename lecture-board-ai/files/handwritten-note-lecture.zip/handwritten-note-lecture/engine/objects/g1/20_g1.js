/* objects/g1/20_g1.js — 중1 VI. 기체의 성질 총정리 그림 도우미 (window.G1)
 * G1.syr(o)            가로 주사기(문자열 SVG): o.x·o.y(가운데)·o.w·o.h · o.px 피스톤 면 x · o.cap 마개(기본 있음) · o.id 피스톤 g 의 id
 *                      피스톤은 <g class="pis" transform="translate(px 0)"> — 움직일 때는 이 g 의 transform 만 바꾼다.
 * G1.inner(o, px)      주사기 속 기체가 차지하는 칸 {x0,y0,x1,y1}
 * G1.parts(n, L)       입자 n 개(<g class="pt"> · 원 + 운동 방향 화살표 길이 L)
 * G1.place(n, b, L)    입자 모형 고정 그림(같은 배치를 칸 크기에 맞춰 늘이고 줄임 — 입자 사이 «거리»만 달라진다)
 * G1.gas(c, el, o)     el 안의 .pt 를 칸 안에서 움직인다(c.loop · 장면을 떠나면 멈춤). o.region() 칸 · o.speed 빠르기(px/s)
 *                      · o.fl 충돌 반짝임을 그릴 g · o.flashR 반짝임 크기(충돌 세기) · 칸이 바뀌면 같은 배치를 그대로 늘이고 줄인다.
 * G1.rig(x, y, t, lv)  스포이트 실험(비커 + 자에 붙인 스포이트 + 색소 물방울) · t 0 차가운 물 ~ 1 따뜻한 물 · lv 물방울 높이(px)
 * G1.icon.*            생활 사례 그림(과자 봉지·운동화·공기 방울·헬륨 풍선·탁구공·생수병·달걀·국그릇·물 뿜는 인형)
 * 과학 약속(교과서 비상 중1 206~215쪽 · 학습지 3·4·5):
 *  · 입자 크기·수는 늘 같게, 골고루. 압력과 부피(온도 일정)는 빠르기(화살표 길이) 그대로 — 입자 사이 거리·벽 충돌 횟수만 달라진다.
 *  · 온도와 부피(압력 일정)는 운동성이 달라진다 — 까닭은 «세게 충돌»로만(횟수로 설명하지 않음). 반짝임 크기 = 충돌 세기.
 *  · 수식·비례·반비례 낱말 없음(교과서 지도상의 유의점).
 */
(function () {
  'use strict';
  const G1 = window.G1 = {};
  const f = v => Math.round(v * 10) / 10;
  G1.f = f;
  G1.PART = '#9bd68f'; G1.PART_S = '#2f7d4c'; G1.MOVE = '#2a67a8'; G1.PRESS = '#d0582a'; G1.GLASS = '#55626e'; G1.INK = '#3a4856';
  G1.HOT = '#e8792f'; G1.COLD = '#3f88c5';
  const R = 13;
  // 골고루 퍼진 고정 배치(0~1)와 처음 운동 방향(도) — 같은 배치를 칸 크기에 맞춰 늘이고 줄인다
  const SPOTS = [[.10, .22], [.28, .72], [.45, .28], [.60, .80], [.78, .24], [.92, .64], [.20, .48], [.53, .54], [.70, .50], [.37, .90], [.06, .82], [.88, .10], [.84, .92], [.40, .08]];
  const DIRS = [35, 200, 122, 300, 250, 160, 78, 332, 18, 222, 140, 282, 58, 192];

  /* ───────── 주사기 ───────── */
  G1.syr = o => {
    const h = o.h || 140, x = o.x, y = o.y, w = o.w, top = y - h / 2, rod = o.rod ?? 200;
    const tint = o.tint || 'rgba(214,232,244,.55)';
    let s = `<rect class="sk" x="${x}" y="${f(top)}" width="${w}" height="${h}" rx="12" fill="${tint}" stroke="${G1.GLASS}" stroke-width="4"/>`;
    // 끝(오른쪽): 가는 관 + 마개
    s += `<rect x="${x + w}" y="${f(y - 11)}" width="46" height="22" rx="4" fill="#e6edf2" stroke="${G1.GLASS}" stroke-width="3"/>`;
    if (o.cap !== false) s += `<rect x="${x + w + 44}" y="${f(y - 20)}" width="22" height="40" rx="5" fill="${G1.INK}"/>`;
    // 눈금(오른쪽 안벽에서 왼쪽으로)
    if (o.ticks !== false) {
      const step = o.tick || 55;
      for (let i = 1; x + w - 6 - i * step > x + 14; i++) {
        const tx = x + w - 6 - i * step;
        s += `<line x1="${f(tx)}" y1="${f(top)}" x2="${f(tx)}" y2="${f(top + (i % 2 ? 14 : 24))}" stroke="${G1.GLASS}" stroke-width="2.5" opacity=".7"/>`;
      }
    }
    s += `<g class="gas"${o.gid ? ` id="${o.gid}"` : ''}></g><g class="fl"${o.fid ? ` id="${o.fid}"` : ''}></g>`;
    // 피스톤(면 + 막대 + 손잡이) — 면의 오른쪽 끝이 px
    s += `<g class="pis"${o.id ? ` id="${o.id}"` : ''} transform="translate(${f(o.px)} 0)">` +
      `<rect x="-18" y="${f(top + 6)}" width="18" height="${h - 12}" rx="4" fill="#9aa7b3" stroke="${G1.INK}" stroke-width="3"/>` +
      `<rect x="${-18 - rod}" y="${f(y - 9)}" width="${rod}" height="18" fill="#cdd5dc" stroke="${G1.INK}" stroke-width="3"/>` +
      `<rect x="${-32 - rod}" y="${f(top - 6)}" width="14" height="${h + 12}" rx="4" fill="#9aa7b3" stroke="${G1.INK}" stroke-width="3"/>` +
      (o.push ? `<g class="push">${G1.arrow(-118 - rod, y, -42 - rod, y, G1.PRESS, 9)}</g>` : '') +
      `</g>`;
    return s;
  };
  G1.inner = (o, px) => { const h = o.h || 140; return { x0: px, y0: o.y - h / 2 + 6, x1: o.x + o.w - 6, y1: o.y + h / 2 - 6 }; };

  /* 굵은 화살표(압력·누르는 방향) */
  G1.arrow = (x1, y1, x2, y2, col = G1.PRESS, w = 8) => {
    const a = Math.atan2(y2 - y1, x2 - x1), L = 26, s1 = a + 2.6, s2 = a - 2.6;
    return `<line x1="${f(x1)}" y1="${f(y1)}" x2="${f(x2 - Math.cos(a) * 6)}" y2="${f(y2 - Math.sin(a) * 6)}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"/>` +
      `<path d="M${f(x2 + Math.cos(s1) * L)} ${f(y2 + Math.sin(s1) * L)}L${f(x2)} ${f(y2)}L${f(x2 + Math.cos(s2) * L)} ${f(y2 + Math.sin(s2) * L)}" fill="none" stroke="${col}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`;
  };

  /* ───────── 입자 ───────── */
  const tail = L => L > 0 ? `<line x1="${R + 3}" y1="0" x2="${R + 3 + L}" y2="0" stroke="${G1.MOVE}" stroke-width="4" stroke-linecap="round"/>` +
    `<path d="M${R + L - 6} -7L${R + 5 + L} 0L${R + L - 6} 7" fill="none" stroke="${G1.MOVE}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>` : '';
  const dot = `<circle r="${R}" fill="${G1.PART}" stroke="${G1.PART_S}" stroke-width="3"/>`;
  G1.parts = (n, L = 0) => Array.from({ length: n }, () => `<g class="pt">${tail(L)}${dot}</g>`).join('');
  const spot = (b, i, seed = 0) => {
    const s = SPOTS[(i + seed) % SPOTS.length], m = R + 6;
    return [b.x0 + m + s[0] * (b.x1 - b.x0 - 2 * m), b.y0 + m + s[1] * (b.y1 - b.y0 - 2 * m)];
  };
  G1.place = (n, b, L = 0, seed = 0) => Array.from({ length: n }, (_, i) => {
    const [x, y] = spot(b, i, seed);
    // 화살표 끝이 벽 밖으로 나가면 방향을 돌린다(그림이 주사기 밖으로 삐져나오지 않게)
    const out = a => { const r = a * Math.PI / 180, e = R + 8 + L; const ex = x + Math.cos(r) * e, ey = y + Math.sin(r) * e; return ex < b.x0 || ex > b.x1 || ey < b.y0 || ey > b.y1; };
    let a = DIRS[(i + seed) % DIRS.length];
    for (const d of [0, 180, 90, 270, 45, 135, 225, 315]) { if (!out(a + d)) { a += d; break; } }
    return `<g transform="translate(${f(x)} ${f(y)}) rotate(${a % 360})">${tail(L)}${dot}</g>`;
  }).join('');

  G1.gas = (c, el, o) => {
    const pts = Array.from(el.querySelectorAll('.pt')), seed = o.seed || 0;
    let last = o.region();
    const st = pts.map((e, i) => {
      const [x, y] = spot(last, i, seed), a = DIRS[(i + seed) % DIRS.length] * Math.PI / 180;
      return { e, x, y, vx: Math.cos(a), vy: Math.sin(a) };
    });
    const draw = () => st.forEach(p => p.e.setAttribute('transform', `translate(${f(p.x)} ${f(p.y)}) rotate(${f(Math.atan2(p.vy, p.vx) * 180 / Math.PI)})`));
    draw();
    // 충돌 반짝임(중립색 고리) — 고리 크기 = 충돌 세기
    const pool = [];
    if (o.fl) {
      for (let i = 0; i < 18; i++) pool.push({ e: null, life: 0, r: 0 });
      o.fl.innerHTML = pool.map(() => `<circle r="0" fill="none" stroke="#6a7885" stroke-width="4" opacity="0"/>`).join('');
      Array.from(o.fl.children).forEach((e, i) => { pool[i].e = e; });
    }
    let pi = 0;
    const hit = (x, y) => {
      if (!pool.length) return;
      const q = pool[pi++ % pool.length], r0 = typeof o.flashR === 'function' ? o.flashR() : (o.flashR || 14);
      q.life = 1; q.r = r0; q.e.setAttribute('cx', f(x)); q.e.setAttribute('cy', f(y));
    };
    if (c.reduced) return;
    c.loop((t, dt) => {
      const b = o.region(), sp = typeof o.speed === 'function' ? o.speed() : (o.speed || 260);
      // 칸이 바뀌면(피스톤 이동) 같은 배치를 그대로 늘이고 줄인다
      if (b.x0 !== last.x0 || b.x1 !== last.x1) {
        const k = (b.x1 - b.x0 - 2 * R) / Math.max(1, last.x1 - last.x0 - 2 * R);
        st.forEach(p => { p.x = b.x0 + R + (p.x - last.x0 - R) * k; });
        last = b;
      }
      st.forEach(p => {
        p.x += p.vx * sp * dt; p.y += p.vy * sp * dt;
        if (p.x - R < b.x0) { p.x = b.x0 + R; if (p.vx < 0) { p.vx = -p.vx; hit(b.x0, p.y); } }
        if (p.x + R > b.x1) { p.x = b.x1 - R; if (p.vx > 0) { p.vx = -p.vx; hit(b.x1, p.y); } }
        if (p.y - R < b.y0) { p.y = b.y0 + R; if (p.vy < 0) { p.vy = -p.vy; hit(p.x, b.y0); } }
        if (p.y + R > b.y1) { p.y = b.y1 - R; if (p.vy > 0) { p.vy = -p.vy; hit(p.x, b.y1); } }
      });
      pool.forEach(q => {
        if (q.life <= 0) return;
        q.life = Math.max(0, q.life - dt * 3);
        q.e.setAttribute('r', f(q.r * (1.25 - .45 * q.life)));
        q.e.setAttribute('opacity', (q.life * .85).toFixed(2));
      });
      draw();
    });
  };

  /* ───────── 스포이트 실험 ───────── */
  const mix = (a, b, t) => { const p = s => [1, 3, 5].map(i => parseInt(s.slice(i, i + 2), 16)); const A = p(a), B = p(b); return 'rgb(' + A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(',') + ')'; };
  G1.water = t => mix('#bfe0f5', '#f8cfa8', t);
  G1.rig = (x, y, t, lv) => {   // x: 비커 가운데 · y: 비커 바닥 · lv: 관 아래(구 위)에서 물방울까지 높이
    const bw = 170, bh = 190, wl = y - 132;
    let s = `<rect x="${x - bw / 2 + 4}" y="${wl}" width="${bw - 8}" height="${y - wl - 4}" fill="${G1.water(t)}" opacity=".85"/>`;
    s += `<path class="sk" d="M${x - bw / 2} ${y - bh}L${x - bw / 2} ${y - 8}Q${x - bw / 2} ${y} ${x - bw / 2 + 8} ${y}L${x + bw / 2 - 8} ${y}Q${x + bw / 2} ${y} ${x + bw / 2} ${y - 8}L${x + bw / 2} ${y - bh}" fill="none" stroke="${G1.GLASS}" stroke-width="4"/>`;
    // 자(왼쪽) + 스포이트(구는 물속, 관은 위로)
    const cx = x + 16, by = y - 62, top = y - 360;
    s += `<rect x="${cx - 62}" y="${top - 10}" width="30" height="${by - top + 40}" fill="#f6efd9" stroke="#8a7a52" stroke-width="2.5"/>`;
    for (let i = 0; i <= 12; i++) { const ty = by + 20 - i * 26; s += `<line x1="${cx - 62}" y1="${ty}" x2="${cx - 62 + (i % 2 ? 10 : 18)}" y2="${ty}" stroke="#8a7a52" stroke-width="2"/>`; }
    s += `<rect x="${cx - 9}" y="${top}" width="18" height="${by - top - 26}" fill="rgba(235,244,250,.9)" stroke="${G1.GLASS}" stroke-width="3"/>`;
    s += `<circle class="sk" cx="${cx}" cy="${by}" r="34" fill="rgba(235,244,250,.95)" stroke="${G1.GLASS}" stroke-width="3.5"/>`;
    s += `<rect x="${cx - 7}" y="${by - 34 - 6}" width="14" height="10" fill="rgba(235,244,250,1)"/>`;
    if (lv != null) s += G1.dropAt(x, y, lv);
    return s;
  };
  G1.dropAt = (x, y, lv) => `<rect class="drop" x="${x + 16 - 8}" y="${f(y - 62 - 60 - lv)}" width="16" height="16" rx="3" fill="#d6332a"/>`;

  /* ───────── 생활 사례 그림(가로세로 약 200 칸, (x, y) = 왼쪽 위) ───────── */
  const I = G1.icon = {};
  const ink = `stroke="${G1.INK}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"`;
  I.bag = (x, y, big) => {   // 과자 봉지: 산 아래(납작) / 산 위(빵빵)
    const k = big ? 1 : 0, w = 120, h = big ? 150 : 128, cx = x + 100, cy = y + 104;
    const bulge = 16 + 26 * k;
    return `<path d="M${cx - w / 2} ${cy - h / 2}Q${cx} ${cy - h / 2 - 10} ${cx + w / 2} ${cy - h / 2}Q${cx + w / 2 + bulge} ${cy} ${cx + w / 2} ${cy + h / 2}Q${cx} ${cy + h / 2 + 10} ${cx - w / 2} ${cy + h / 2}Q${cx - w / 2 - bulge} ${cy} ${cx - w / 2} ${cy - h / 2}Z" fill="#f4ead2" ${ink}/>` +
      `<path d="M${cx - w / 2 + 6} ${cy - h / 2 + 4}l8 -10l8 10l8 -10l8 10l8 -10l8 10l8 -10l8 10l8 -10l8 10l8 -10l8 10" fill="none" stroke="#b44d3a" stroke-width="3"/>` +
      `<line x1="${cx - w / 2 + 6}" y1="${cy}" x2="${cx + w / 2 - 6}" y2="${cy}" stroke="#b44d3a" stroke-width="5" opacity=".7"/>`;
  };
  I.shoe = (x, y) => `<path d="M${x + 20} ${y + 150}L${x + 30} ${y + 70}Q${x + 60} ${y + 60} ${x + 90} ${y + 90}L${x + 150} ${y + 110}Q${x + 190} ${y + 120} ${x + 190} ${y + 150}Z" fill="#e8eef4" ${ink}/>` +
    `<rect x="${x + 16}" y="${y + 150}" width="178" height="26" rx="10" fill="#cfd8df" ${ink}/>` +
    `<ellipse cx="${x + 70}" cy="${y + 163}" rx="34" ry="9" fill="#bfe3f7" stroke="${G1.MOVE}" stroke-width="3"/>` +
    G1.arrow(x + 70, y + 8, x + 70, y + 52, G1.PRESS, 7);
  I.bubbles = (x, y) => `<rect x="${x + 20}" y="${y + 10}" width="160" height="190" rx="8" fill="#d7ecf8" stroke="#7fb3d6" stroke-width="3"/>` +
    [[100, 175, 9], [92, 128, 14], [106, 82, 20], [96, 36, 26]].map(([a, b, r]) => `<circle cx="${x + a}" cy="${y + b}" r="${r}" fill="rgba(255,255,255,.85)" stroke="${G1.MOVE}" stroke-width="3"/>`).join('') +
    G1.arrow(x + 150, y + 180, x + 150, y + 40, G1.MOVE, 5);
  I.balloon = (x, y, big) => {
    const rx = big ? 62 : 48, ry = big ? 74 : 58, cx = x + 100, cy = y + 84;
    return `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="#f6b8c4" ${ink}${big ? '' : ` transform="rotate(-8 ${cx} ${cy})"`}/>` +
      (big ? '' : `<path d="M${cx - 30} ${cy - 20}q10 8 4 18" fill="none" stroke="${G1.INK}" stroke-width="3"/>`) +
      `<path d="M${cx} ${cy + ry}l-8 12h16z" fill="#f6b8c4" ${ink}/><path d="M${cx} ${cy + ry + 12}q-10 16 4 30q10 12 -3 22" fill="none" stroke="${G1.INK}" stroke-width="3"/>`;
  };
  I.pingpong = (x, y) => `<path d="M${x + 20} ${y + 90}h160v90q0 16 -16 16h-128q-16 0 -16 -16z" fill="${G1.water(1)}" ${ink}/>` +
    `<path d="M${x + 60} ${y + 76}q-4 -14 6 -22M${x + 100} ${y + 70}q-4 -14 6 -22M${x + 140} ${y + 76}q-4 -14 6 -22" fill="none" stroke="${G1.HOT}" stroke-width="3.5" stroke-linecap="round"/>` +
    `<path d="M${x + 64} ${y + 120}a38 38 0 1 0 72 0q-14 -16 -36 -6q-22 -10 -36 6z" fill="#fff" ${ink}/>`;
  I.bottle = (x, y) => `<rect x="${x + 10}" y="${y + 6}" width="180" height="196" rx="10" fill="#e3f0f7" stroke="#7fb3d6" stroke-width="4"/>` +
    `<text x="${x + 100}" y="${y + 40}" text-anchor="middle" font-size="26" fill="${G1.COLD}">❄</text>` +
    `<path d="M${x + 88} ${y + 50}h24v14l14 16l-10 18l10 18l-10 18l10 18l-10 18v18h-56v-18l10 -18l-10 -18l10 -18l-10 -18l10 -18l14 -16z" fill="rgba(255,255,255,.9)" ${ink}/>` +
    `<path d="M${x + 76} ${y + 168}h48v12h-48z" fill="#9fd0ef"/>`;
  I.egg = (x, y) => `<path d="M${x + 100} ${y + 24}C${x + 150} ${y + 24} ${x + 170} ${y + 110} ${x + 158} ${y + 140}C${x + 146} ${y + 180} ${x + 54} ${y + 180} ${x + 42} ${y + 140}C${x + 30} ${y + 110} ${x + 50} ${y + 24} ${x + 100} ${y + 24}Z" fill="#fbf3e2" ${ink}/>` +
    `<path d="M${x + 60} ${y + 54}Q${x + 100} ${y + 72} ${x + 140} ${y + 54}" fill="rgba(191,227,247,.9)" stroke="${G1.MOVE}" stroke-width="3"/>` +
    `<path d="M${x + 118} ${y + 32}l-8 16l12 6l-8 16" fill="none" stroke="#d6332a" stroke-width="4" stroke-linecap="round"/>`;
  I.bowl = (x, y) => `<path d="M${x + 30} ${y + 70}h140q0 70 -70 76q-70 -6 -70 -76z" fill="#f2e2c4" ${ink}/>` +
    `<path d="M${x + 70} ${y + 56}q-4 -14 6 -22M${x + 104} ${y + 50}q-4 -14 6 -22M${x + 136} ${y + 56}q-4 -14 6 -22" fill="none" stroke="${G1.HOT}" stroke-width="3.5" stroke-linecap="round"/>` +
    `<rect x="${x + 66}" y="${y + 146}" width="68" height="10" fill="#f2e2c4" ${ink}/>` +
    `<line x1="${x + 6}" y1="${y + 170}" x2="${x + 194}" y2="${y + 170}" stroke="#8a5a2b" stroke-width="7" stroke-linecap="round"/>` +
    G1.arrow(x + 150, y + 156, x + 190, y + 156, G1.PRESS, 5);
  I.doll = (x, y) => `<circle cx="${x + 100}" cy="${y + 56}" r="36" fill="#fde3c6" ${ink}/>` +
    `<path d="M${x + 58} ${y + 190}q-6 -84 42 -96q48 12 42 96z" fill="#cfe6c4" ${ink}/>` +
    `<circle cx="${x + 88}" cy="${y + 52}" r="4" fill="${G1.INK}"/><circle cx="${x + 112}" cy="${y + 52}" r="4" fill="${G1.INK}"/><circle cx="${x + 100}" cy="${y + 72}" r="5" fill="${G1.INK}"/>` +
    `<path d="M${x + 106} ${y + 72}q50 -40 84 10" fill="none" stroke="${G1.MOVE}" stroke-width="5" stroke-dasharray="2 10" stroke-linecap="round"/>`;
})();
