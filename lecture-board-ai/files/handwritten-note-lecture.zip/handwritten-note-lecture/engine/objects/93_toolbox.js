/* 판서 도구 상자 v1 — 2026-11-04 아이패드 수업 요청 · canonical: 전기강의_빌드/objects/93_toolbox.js(기체압력 · 소비전력 빌드에 같은 사본)
 * 오른쪽 아래 둥근 단추 하나 → 누르면 도구가 펼쳐진다: 레이저 · 빨간 펜 · 한 획 지우기 · 모두 지우기 · 손가락 그리기(자동/켬/끔) · 전체 화면.
 * 도구 상자 위는 레이저 · 펜이 켜져 있어도 그리지 않는다(89_ink.js skip) — 손가락으로 눌러 여닫는다.
 * 손가락 그리기 «자동»: 펜슬을 한 번이라도 쓰면 그때부터 펜슬만 그리고 손가락은 화면 넘기기(굿노트처럼). 전자칠판처럼 펜슬이 없으면 손가락으로 그림.
 * 확인용 정지 화면(?still=1 · ?clean=1)과 인쇄에서는 숨긴다.
 */
(function () {
  'use strict';
  function mount() {
    if (window.LectureTools || !window.Deck || !document.getElementById('hud')) return;
    var Q = new URLSearchParams(location.search);
    if (Q.get('still') === '1' || Q.get('clean') === '1') return;
    var css = document.createElement('style');
    css.textContent =
      '#lecture-tools{position:fixed;right:16px;bottom:88px;z-index:70;display:flex;flex-direction:column;align-items:flex-end;gap:8px;font:600 14px/1.2 "Pretendard Variable",Pretendard,system-ui,sans-serif;touch-action:manipulation;-webkit-user-select:none;user-select:none}' +
      '#lecture-tools .tb-main{width:54px;height:54px;border-radius:50%;border:0;background:rgba(28,36,46,.55);color:#fff;display:grid;place-items:center;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.18);opacity:.75;transition:opacity .2s,background .2s}' +
      '#lecture-tools .tb-main:hover,#lecture-tools.open .tb-main{opacity:1;background:rgba(28,36,46,.88)}' +
      '#lecture-tools .tb-main svg{width:26px;height:26px}' +
      '#lecture-tools .tb-panel{display:none;flex-direction:column;gap:6px;padding:10px;border-radius:16px;background:rgba(250,250,247,.97);box-shadow:0 8px 28px rgba(0,0,0,.22);min-width:210px}' +
      '#lecture-tools.open .tb-panel{display:flex}' +
      '#lecture-tools .tb-panel button{display:flex;align-items:center;gap:10px;min-height:46px;padding:0 14px;border:1px solid rgba(0,0,0,.08);border-radius:12px;background:#fff;color:#24303b;font:inherit;cursor:pointer;text-align:left}' +
      '#lecture-tools .tb-panel button .ic{width:22px;text-align:center;font-size:18px}' +
      '#lecture-tools .tb-panel button .k{margin-left:auto;font-weight:500;font-size:12px;color:#7d8892}' +
      '#lecture-tools .tb-panel button[aria-pressed="true"]{background:#d6332a;color:#fff;border-color:#d6332a}' +
      '#lecture-tools .tb-panel button[aria-pressed="true"] .k{color:#ffe2df}' +
      '#lecture-tools .tb-panel hr{border:0;border-top:1px solid rgba(0,0,0,.08);margin:2px 0}' +
      '#lecture-tools .tb-panel .tip{font-weight:500;font-size:12px;line-height:1.45;color:#55626e;padding:2px 4px;max-width:220px}' +
      '@media print{#lecture-tools{display:none!important}}';
    document.head.appendChild(css);
    var box = document.createElement('div');
    box.id = 'lecture-tools';
    var has = { laser: !!window.LectureLaser, pen: !!window.LecturePen };
    box.innerHTML =
      '<div class="tb-panel" role="menu">' +
        (has.laser ? '<button type="button" data-t="laser" aria-pressed="false"><span class="ic">🔴</span>레이저<span class="k">L</span></button>' : '') +
        (has.pen ? '<button type="button" data-t="pen" aria-pressed="false"><span class="ic">✏️</span>빨간 펜<span class="k">P</span></button>' +
                   '<button type="button" data-t="undo"><span class="ic">↶</span>한 획 지우기<span class="k">Z</span></button>' +
                   '<button type="button" data-t="clear"><span class="ic">🧽</span>모두 지우기<span class="k">C</span></button>' : '') +
        '<hr><button type="button" data-t="touch"><span class="ic">✋</span><span class="lb">손가락 그리기</span><span class="k" data-v></span></button>' +
        '<div class="tip" data-tip></div>' +
        '<button type="button" data-t="full"><span class="ic">⛶</span>전체 화면<span class="k">F</span></button>' +
        (/iPad|Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1 ? '<div class="tip">아이패드: 공유 → 「홈 화면에 추가」로 열면 주소창 없이 꽉 차고, 쓸어내려도 꺼지지 않아요.</div>' : '') +
      '</div>' +
      '<button type="button" class="tb-main" aria-label="판서 도구 열기/닫기" aria-expanded="false" title="판서 도구">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true"><path d="M4 20l1.2-4.6L16.6 4a2 2 0 0 1 2.8 0l.6.6a2 2 0 0 1 0 2.8L8.6 18.8z"/><path d="M14.5 6.1l3.4 3.4"/></svg>' +
      '</button>';
    document.body.appendChild(box);
    var main = box.querySelector('.tb-main'), Ink = window.LectureInk;
    var TOUCH = { auto: '자동', on: '켬', off: '끔' };
    function sync() {
      var b;
      if ((b = box.querySelector('[data-t="laser"]'))) b.setAttribute('aria-pressed', String(window.LectureLaser.enabled));
      if ((b = box.querySelector('[data-t="pen"]'))) b.setAttribute('aria-pressed', String(window.LecturePen.enabled));
      if (Ink) {
        box.querySelector('[data-v]').textContent = TOUCH[Ink.mode];
        box.querySelector('[data-tip]').textContent =
          Ink.mode === 'on' ? '손가락으로도 그립니다(전자칠판).' :
          Ink.mode === 'off' ? '펜슬 · 마우스만 그립니다. 손가락은 화면 넘기기.' :
          Ink.seenPen ? '자동: 펜슬이 감지되어 펜슬만 그립니다. 손가락은 화면 넘기기.' : '자동: 펜슬을 쓰면 그때부터 펜슬만 그립니다.';
      }
      var full = !!(document.fullscreenElement || document.webkitFullscreenElement);
      box.querySelector('[data-t="full"]').setAttribute('aria-pressed', String(full));
    }
    function setOpen(v) { box.classList.toggle('open', v); main.setAttribute('aria-expanded', String(v)); sync(); }
    function fullscreen() {
      var d = document, el = d.documentElement;
      if (!(d.fullscreenElement || d.webkitFullscreenElement)) (el.requestFullscreen || el.webkitRequestFullscreen || function () {}).call(el);
      else (d.exitFullscreen || d.webkitExitFullscreen || function () {}).call(d);
    }
    // 도구 상자 안의 누름은 강의(넘기기)로 가지 않게
    ['pointerdown', 'pointerup', 'click', 'touchstart', 'touchend', 'mousedown', 'mouseup'].forEach(function (t) {
      box.addEventListener(t, function (e) { e.stopPropagation(); }, false);
    });
    main.addEventListener('click', function () { setOpen(!box.classList.contains('open')); main.blur(); });
    box.querySelector('.tb-panel').addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var t = b.dataset.t;
      if (t === 'laser') { LectureLaser.setEnabled(); if (LectureLaser.enabled && window.LecturePen && LecturePen.enabled) LecturePen.setEnabled(false); }
      else if (t === 'pen') LecturePen.setEnabled();
      else if (t === 'undo') LecturePen.undo();
      else if (t === 'clear') LecturePen.clear();
      else if (t === 'touch' && Ink) Ink.setMode(Ink.mode === 'auto' ? 'off' : Ink.mode === 'off' ? 'on' : 'auto');
      else if (t === 'full') fullscreen();
      b.blur(); setTimeout(sync, 0);
    });
    if (Ink) Ink.onChange(sync);
    ['fullscreenchange', 'webkitfullscreenchange'].forEach(function (t) { document.addEventListener(t, sync); });
    ['lecture-laser-toggle', 'lecture-pen-toggle'].forEach(function (id) {
      var b = document.getElementById(id);
      if (b) new MutationObserver(sync).observe(b, { attributes: true, attributeFilter: ['aria-pressed'] });
    });
    var table = document.querySelector('#help table');
    if (table) { var row = table.insertRow(); row.innerHTML = '<td>오른쪽 아래 ✏️</td><td>판서 도구 상자 — 레이저 · 펜 · 지우기 · 손가락 그리기(자동이면 펜슬을 쓰는 순간부터 펜슬만 그림) · 전체 화면</td>'; }
    sync();
    window.LectureTools = Object.freeze({ open: function () { setOpen(true); }, close: function () { setOpen(false); }, get el() { return box; } });
  }
  // 엔진 → 레이저 → 펜 → 도구 상자 순서로 붙는다(레이저 · 펜이 있어야 단추를 만든다)
  function later(n) { return function () { if (n <= 0) mount(); else setTimeout(later(n - 1), 0); }; }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(later(3), 0); });
  else setTimeout(later(3), 0);
})();
