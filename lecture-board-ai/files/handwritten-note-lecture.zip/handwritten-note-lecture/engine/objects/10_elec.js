/* ═══════════════════════════════════════════════════════════════
   objects/10_elec.js — 전기와 자기 강의 덱 공용 그림 조각(문자열 SVG)
   · EL.arrow(x1,y1,x2,y2,{color,w,head,id,cls,dash})   화살표
   · EL.charge(x,y,sign,{r,id,cls,color,stroke})         전하 기호 원(+ / −). sign: '+' | '-'
   · EL.sign(x,y,sign,{s,color,w})                        원 없이 + / − 기호만(선으로 그려 글꼴과 무관하게 또렷)
   · EL.electron(x,y,{r,id,cls})                          전자(하늘색 작은 원 + −)
   과학 규약: 전하 기호는 «원자핵(+)은 제자리, 움직이는 것은 전자(−)뿐». 대전되지 않은 물체는 (+)와 (−)의 수가 같다.
   마찰·유도 전후 전체 전하량(기호 수의 합)이 맞는지 그림마다 셀 것.
   덱마다 더 필요한 그림은 objects/<덱>/ 안에 따로(이름표 E1·E2·E3·E4 처럼 덱 이름으로 — 서로 덮어쓰지 않게).
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  const E = window.EL = {};
  const f = v => (Math.round(v * 10) / 10);
  E.arrow = function (x1, y1, x2, y2, o = {}) {
    const col = o.color || 'currentColor', w = o.w == null ? 6 : o.w, hd = o.head == null ? Math.max(18, w * 3.2) : o.head;
    const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L;
    const bx = x2 - ux * hd * 0.85, by = y2 - uy * hd * 0.85, px = -uy, py = ux;
    return `<g${o.cls ? ` class="${o.cls}"` : ''}${o.id ? ` id="${o.id}"` : ''}><line x1="${f(x1)}" y1="${f(y1)}" x2="${f(bx)}" y2="${f(by)}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"${o.dash ? ` stroke-dasharray="${o.dash}"` : ''}/>` +
      `<polygon points="${f(x2)},${f(y2)} ${f(bx + px * hd * .5)},${f(by + py * hd * .5)} ${f(bx - px * hd * .5)},${f(by - py * hd * .5)}" fill="${col}"/></g>`;
  };
  E.sign = function (x, y, sign, o = {}) {
    const s = o.s == null ? 10 : o.s, col = o.color || (sign === '+' ? 'var(--heat)' : 'var(--elec)'), w = o.w == null ? Math.max(2.5, s * .32) : o.w;
    let d = `M${f(x - s)} ${f(y)}H${f(x + s)}`;
    if (sign === '+') d += `M${f(x)} ${f(y - s)}V${f(y + s)}`;
    return `<path d="${d}" stroke="${col}" stroke-width="${f(w)}" stroke-linecap="round" fill="none"/>`;
  };
  E.charge = function (x, y, sign, o = {}) {
    const r = o.r == null ? 22 : o.r, col = o.color || (sign === '+' ? 'var(--heat)' : 'var(--elec)');
    return `<g${o.cls ? ` class="${o.cls}"` : ''}${o.id ? ` id="${o.id}"` : ''}><circle cx="${f(x)}" cy="${f(y)}" r="${r}" fill="${col}" fill-opacity="${o.fill == null ? .16 : o.fill}" stroke="${o.stroke || col}" stroke-width="${o.sw == null ? 3 : o.sw}"/>` +
      E.sign(x, y, sign, { s: r * .5, color: col }) + `</g>`;
  };
  E.electron = function (x, y, o = {}) {
    const r = o.r == null ? 14 : o.r;
    return `<g${o.cls ? ` class="${o.cls}"` : ''}${o.id ? ` id="${o.id}"` : ''}><circle cx="${f(x)}" cy="${f(y)}" r="${r}" fill="var(--elec)"/>` +
      E.sign(x, y, '-', { s: r * .5, color: '#fff', w: Math.max(2, r * .22) }) + `</g>`;
  };
})();
