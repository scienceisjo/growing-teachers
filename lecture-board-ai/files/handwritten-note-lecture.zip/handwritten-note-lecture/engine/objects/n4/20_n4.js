/* objects/n4/20_n4.js — 04 옴의 법칙 그래프 도우미 (window.N4)
 * const G = N4.graph({ox, oy, w, h, xmax, ymax, xl, yl, xt:[눈금], yt:[눈금]})
 *   G.axes()            축 + 눈금 + 이름(문자열 SVG)
 *   G.p(x, y)           값 → 화면 좌표 [px, py]
 *   G.dot(x, y, col)    점 · G.line(x0,y0,x1,y1,col) 직선 · G.curve(fn, x0, x1, col) 곡선(path)
 * 눈금 숫자는 값과 정확히 맞춘다(그래프 점 좌표 = 표의 값).
 */
(function () {
  'use strict';
  const N4 = window.N4 = {};
  const f = v => Math.round(v * 10) / 10;
  N4.graph = g => {
    const p = (x, y) => [g.ox + x / g.xmax * g.w, g.oy - y / g.ymax * g.h];
    const G = { p };
    G.axes = () => {
      let s = `<line x1="${g.ox}" y1="${g.oy}" x2="${g.ox + g.w + 30}" y2="${g.oy}" stroke="#3a4856" stroke-width="4"/>` +
        `<path d="M${g.ox + g.w + 14} ${g.oy - 10}L${g.ox + g.w + 32} ${g.oy}L${g.ox + g.w + 14} ${g.oy + 10}" fill="none" stroke="#3a4856" stroke-width="4" stroke-linejoin="round"/>` +
        `<line x1="${g.ox}" y1="${g.oy}" x2="${g.ox}" y2="${g.oy - g.h - 30}" stroke="#3a4856" stroke-width="4"/>` +
        `<path d="M${g.ox - 10} ${g.oy - g.h - 14}L${g.ox} ${g.oy - g.h - 32}L${g.ox + 10} ${g.oy - g.h - 14}" fill="none" stroke="#3a4856" stroke-width="4" stroke-linejoin="round"/>` +
        `<text x="${g.ox - 16}" y="${g.oy + 40}" text-anchor="end" font-size="34" fill="#55626e">0</text>` +
        `<text x="${g.ox + g.w + 40}" y="${g.oy + 12}" font-size="38" fill="#3a4856">${g.xl}</text>` +
        `<text x="${g.ox}" y="${g.oy - g.h - 44}" text-anchor="middle" font-size="38" fill="#3a4856">${g.yl}</text>`;
      (g.xt || []).forEach(v => { const [x] = p(v, 0); s += `<line x1="${f(x)}" y1="${g.oy - 8}" x2="${f(x)}" y2="${g.oy + 8}" stroke="#3a4856" stroke-width="3"/><text x="${f(x)}" y="${g.oy + 44}" text-anchor="middle" font-size="32" fill="#55626e">${v}</text>`; });
      (g.yt || []).forEach(v => { const [, y] = p(0, v); s += `<line x1="${g.ox - 8}" y1="${f(y)}" x2="${g.ox + 8}" y2="${f(y)}" stroke="#3a4856" stroke-width="3"/><text x="${g.ox - 18}" y="${f(y + 11)}" text-anchor="end" font-size="32" fill="#55626e">${v}</text>`; });
      if (g.grid) (g.xt || []).forEach(v => { const [x] = p(v, 0); s += `<line x1="${f(x)}" y1="${g.oy}" x2="${f(x)}" y2="${g.oy - g.h}" stroke="#9fb3c4" stroke-width="1.5" stroke-dasharray="4 8"/>`; });
      return s;
    };
    G.dot = (x, y, col = '#c0392b', r = 11) => { const [px, py] = p(x, y); return `<circle cx="${f(px)}" cy="${f(py)}" r="${r}" fill="${col}" stroke="#fff" stroke-width="3"/>`; };
    G.line = (x0, y0, x1, y1, col = '#c0392b', w = 6, dash = '') => { const [a, b] = p(x0, y0), [c, d] = p(x1, y1); return `<line x1="${f(a)}" y1="${f(b)}" x2="${f(c)}" y2="${f(d)}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"${dash ? ` stroke-dasharray="${dash}"` : ''}/>`; };
    G.curve = (fn, x0, x1, col = '#2a67a8', w = 6) => {
      const pts = []; for (let i = 0; i <= 60; i++) { const x = x0 + (x1 - x0) * i / 60; pts.push(p(x, fn(x))); }
      return `<path d="M${pts.map(q => f(q[0]) + ' ' + f(q[1])).join('L')}" fill="none" stroke="${col}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`;
    };
    return G;
  };
})();
