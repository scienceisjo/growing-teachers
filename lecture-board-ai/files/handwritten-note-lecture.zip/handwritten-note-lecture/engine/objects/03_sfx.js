/* ═══════════════════════════════════════════════════════════════
   03_sfx.js — 효과음(WebAudio 합성). 소리 파일 0개 · 오프라인 OK
   · 장면에서는 c.sfx('blank', 지연ms) · c.sfxLoop('fan') 로 부른다(core.js 가 순간 모드·건너뛰기·장면 나감을 알아서 처리)
   · 브라우저 정책상 첫 클릭·키 입력 뒤부터 소리가 난다. M 키·HUD 단추로 켜고 끔(기기에 기억). 학생 모드(?s=1)는 기본 꺼짐
   · 점검: ?sfx=demo → 모든 소리를 눌러 들어 보는 패널 / SFX.analyze('blank') → 오프라인 렌더로 세기·길이 점검
   · 주소 도우미: ?sound=1|0 강제 켜기·끄기 · ?nosfx=1 완전 끔 · ?sfxtest=1 클릭 없이 잠금 해제(자동 점검용)
   ═══════════════════════════════════════════════════════════════ */
window.SFX = (function () {
  'use strict';
  const Q = new URLSearchParams(location.search);
  const D = window.Deck || {};
  const OFF = !!D.STILL || Q.get('nosfx') === '1';
  const KEY = 'sc_sfx';
  const VOLUME_KEY = 'sc_sfx_volume';
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  let volume = 1;
  try { const saved = localStorage.getItem(VOLUME_KEY); if (saved !== null && saved.trim() !== '' && Number.isFinite(Number(saved))) volume = clamp(Number(saved)); } catch (e) {}
  let on = !D.STUDENT;
  try { const s = localStorage.getItem(KEY); if (s === '1' || s === '0') on = s === '1'; } catch (e) {}
  if (Q.get('sound') === '1') on = true; else if (Q.get('sound') === '0') on = false;
  let ac = null, out = null, master = null, X = null, unlocked = Q.get('sfxtest') === '1', broken = false;
  const pending = new Set();

  /* ── 잡음(결정적) ── */
  function noiseBuf(actx) {
    const n = Math.floor(actx.sampleRate * 2), b = actx.createBuffer(1, n, actx.sampleRate), d = b.getChannelData(0);
    let s = 12345;
    for (let i = 0; i < n; i++) { s = (s * 1664525 + 1013904223) >>> 0; d[i] = s / 2147483648 - 1; }
    return b;
  }
  function ensure() {
    if (OFF || broken || !unlocked) return null;
    if (!ac) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { broken = true; return null; }
      try { ac = new AC(); } catch (e) { broken = true; return null; }
      const comp = ac.createDynamicsCompressor();
      comp.threshold.value = -14; comp.knee.value = 18; comp.ratio.value = 4; comp.attack.value = .004; comp.release.value = .18;
      out = ac.createGain(); out.gain.value = .9;
      // Apply volume after compression, so every one-shot and loop shares the same level.
      master = ac.createGain(); master.gain.value = on ? volume : 0;
      out.connect(comp); comp.connect(master); master.connect(ac.destination);
      X = { ac, dest: out, nz: noiseBuf(ac) };
    }
    if (ac.state === 'suspended' && on && !document.hidden) ac.resume().catch(() => {});
    return X;
  }

  /* ── 소리 부품 ── */
  function env(g, t, a, d, peak) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(Math.max(0.0002, peak), t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
  }
  function route(x, node, pan) {
    if (pan && x.ac.createStereoPanner) { const p = x.ac.createStereoPanner(); p.pan.value = clamp(pan, -1, 1); node.connect(p); p.connect(x.dest); return; }
    node.connect(x.dest);
  }
  /** 톤: f(→f2) Hz, a 올림 s, d 사라짐 s, g 세기, type, vib[Hz, 깊이Hz], lp 저역통과, pan */
  function tone(x, t, o) {
    const ac = x.ac, osc = ac.createOscillator(), g = ac.createGain();
    const a = o.a ?? .004, d = o.d ?? .3;
    osc.type = o.type || 'sine';
    osc.frequency.setValueAtTime(o.f, t);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(o.f2, t + a + d);
    if (o.vib) {
      const l = ac.createOscillator(), lg = ac.createGain();
      l.frequency.value = o.vib[0]; lg.gain.value = o.vib[1]; l.connect(lg); lg.connect(osc.frequency); l.start(t); l.stop(t + a + d + .06);
    }
    env(g, t, a, d, o.g ?? .2);
    osc.connect(g);
    let last = g;
    if (o.lp) { const f = ac.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = o.lp; g.connect(f); last = f; }
    route(x, last, o.pan);
    osc.start(t); osc.stop(t + a + d + .07);
  }
  /** 잡음: type(bandpass|highpass|lowpass), f(→f2) Hz, q */
  function noise(x, t, o) {
    const ac = x.ac, s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
    const a = o.a ?? .003, d = o.d ?? .1;
    s.buffer = x.nz; s.loop = true;
    f.type = o.type || 'bandpass'; f.frequency.setValueAtTime(o.f || 2000, t);
    if (o.f2) f.frequency.exponentialRampToValueAtTime(o.f2, t + a + d);
    f.Q.value = o.q ?? 1;
    env(g, t, a, d, o.g ?? .15);
    s.connect(f); f.connect(g); route(x, g, o.pan);
    s.start(t, (t * 7.13) % 1.5); s.stop(t + a + d + .07);
  }
  const PART = [[1, 1, 1], [2.76, .3, .55], [5.4, .1, .3], [8.93, .04, .18]];
  function bell(x, t, f, g = .3, d = 1.1) { PART.forEach(([r, w, k]) => tone(x, t, { f: f * r, a: .002, d: d * k, g: g * w })); }
  function tickAt(x, t, f, g) {
    tone(x, t, { f, a: .001, d: .014, g });
    noise(x, t, { a: .001, d: .006, g: g * .9, type: 'bandpass', f: f * 1.6, q: 1.5 });
  }

  /* ═════════ 소리 목록: (x, t, a, b) ═════════ */
  const SCALE = [0, 2, 4, 7, 9, 12, 9, 7, 4, 2];       // 빈칸이 채워질 때마다 음계가 오르내린다
  const S = {
    /** 빈칸이 채워짐 — 마림바 같은 「띠링」. i = 몇 번째 빈칸(음 높이 순서) */
    blank(x, t, i) {
      const f = 659.25 * Math.pow(2, SCALE[(i | 0) % 10] / 12);
      tone(x, t, { f, a: .003, d: .34, g: .24 });
      tone(x, t, { f: f * 2, a: .002, d: .16, g: .07 });
      tone(x, t, { f: f * 4.02, a: .001, d: .05, g: .025 });
      noise(x, t, { a: .001, d: .012, g: .05, type: 'highpass', f: 3500 });
    },
    /** 무언가 톡 나타남 */
    pop(x, t) {
      tone(x, t, { f: 420, f2: 840, a: .002, d: .1, g: .2 });
      noise(x, t, { a: .001, d: .02, g: .05, type: 'highpass', f: 3000 });
    },
    /** 클릭으로 다음 단계 — 아주 작은 톡 */
    step(x, t) { tone(x, t, { f: 1500, f2: 900, type: 'triangle', a: .001, d: .045, g: .075 }); noise(x, t, { a: .001, d: .01, g: .03, f: 3000, q: 1.5 }); },
    /** 다음 장으로 — 부드러운 슥 */
    slide(x, t) {
      noise(x, t, { a: .12, d: .5, g: .2, f: 400, f2: 2600, q: .8 });
      tone(x, t, { f: 220, f2: 110, a: .005, d: .25, g: .09 });
    },
    /** 휙 — dur ms, gain */
    whoosh(x, t, dur = 700, g = 1) {
      const d = (dur || 700) / 1000;
      noise(x, t, { a: d * .4, d: d * .6, g: .2 * (g ?? 1), f: 350, f2: 2400, q: .7 });
    },
    /** 숫자 굴러감 — 오르는 째깍째깍 */
    counter(x, t, dur = 1200) {
      const n = clamp(Math.round((dur || 1200) / 70), 4, 22), sp = (dur || 1200) / 1000 / n;
      for (let i = 0; i < n; i++) tickAt(x, t + i * sp, 1500 + i * (900 / n), .07);
    },
    /** 세는 선을 조각이 지나감(가이거처럼) — p 음높이, g 세기 */
    tick(x, t, p = 1, g = 1) { tickAt(x, t, 2100 * (p || 1), .1 * (g ?? 1)); },
    /** 1초가 지남 — 나무 시계 */
    clock(x, t) {
      tone(x, t, { f: 1050, f2: 620, type: 'triangle', a: .001, d: .06, g: .17 });
      noise(x, t, { a: .001, d: .012, g: .08, f: 2600, q: 2 });
    },
    /** 쾅(도장) */
    thunk(x, t) {
      tone(x, t, { f: 150, f2: 44, a: .002, d: .24, g: .5 });
      noise(x, t, { a: .002, d: .1, g: .28, type: 'lowpass', f: 700, f2: 200 });
    },
    /** 땡 */
    ding(x, t, k = 1) { bell(x, t, 1318.5 * (k || 1), .32, 1.1); },
    /** 딩동딩동 ↑ (정답·완성) */
    chime(x, t) { [1046.5, 1318.5, 1568, 2093].forEach((f, i) => bell(x, t + i * .085, f, .3, .9)); },
    /** 명판 뒤집기 */
    flip(x, t) {
      noise(x, t, { a: .002, d: .03, g: .18, f: 3200, q: 1.5 });
      noise(x, t + .12, { a: .002, d: .03, g: .18, f: 2600, q: 1.5 });
      noise(x, t + .02, { a: .03, d: .16, g: .09, f: 900, f2: 2600 });
    },
    /** 토스터 레버 내림 — 철컥 */
    lever(x, t) {
      tone(x, t, { f: 260, f2: 75, type: 'triangle', a: .002, d: .14, g: .4 });
      noise(x, t, { a: .002, d: .06, g: .22, type: 'lowpass', f: 1200, f2: 400 });
      tone(x, t + .01, { f: 1900, f2: 1200, a: .001, d: .05, g: .04 });
    },
    /** 토스터 빵 튀어 오름 — 텅~ 팅! */
    toasterPop(x, t) {
      tone(x, t, { f: 150, f2: 55, a: .002, d: .12, g: .32 });
      tone(x, t + .02, { f: 210, f2: 640, type: 'triangle', a: .005, d: .32, g: .11, vib: [22, 26] });
      noise(x, t + .02, { a: .01, d: .2, g: .05, f: 2400, q: 1.2 });
      bell(x, t + .16, 2637, .22, .9);
    },
    /** 열선이 달아오르며 탁탁 — dur ms */
    sizzle(x, t, dur = 2000) {
      const d = (dur || 2000) / 1000, n = Math.round(d * 34);
      for (let i = 0; i < n; i++) noise(x, t + Math.random() * d, { a: .001, d: .009, g: .11 * (1 - i / n * .3), f: 2500 + Math.random() * 3500, q: 1.4, pan: (Math.random() - .5) * .6 });
    },
    /** 스피커 박 — strong 이면 큰 북, 아니면 작은 북 + 심벌 */
    kick(x, t, strong, lv) {
      const k = lv == null ? 1 : lv, g = (strong ? .5 : .3) * k;
      tone(x, t, { f: strong ? 150 : 130, f2: 44, a: .002, d: strong ? .2 : .14, g });
      noise(x, t, { a: .001, d: .05, g: g * .5, type: 'lowpass', f: 900, f2: 300 });
      if (!strong) noise(x, t + .02, { a: .001, d: .04, g: .045, type: 'highpass', f: 7000 });
    },
    /** 백열전구 켜짐 — 딸깍 · 웅 · 팅 */
    bulbOn(x, t) {
      noise(x, t, { a: .001, d: .006, g: .12, f: 3000, q: 1.5 });
      tone(x, t + .02, { f: 98, type: 'triangle', a: .05, d: .55, g: .08, lp: 500 });
      noise(x, t + .03, { a: .08, d: .5, g: .05, type: 'lowpass', f: 300, f2: 3000 });
      bell(x, t + .05, 1760, .12, .8);
    },
    /** LED 켜짐 — 딸깍 · 띠링 */
    ledOn(x, t) {
      noise(x, t, { a: .001, d: .006, g: .1, f: 3400, q: 1.5 });
      tone(x, t + .01, { f: 1568, f2: 2093, a: .003, d: .2, g: .1 });
      bell(x, t + .03, 2349, .1, .7);
    },
    /** 집 창문 켜짐 — 딸깍 · 띵띵띵 */
    lightsOn(x, t) {
      noise(x, t, { a: .001, d: .01, g: .08, f: 2600, q: 1.5 });
      [1568, 1760, 1976].forEach((f, i) => bell(x, t + .04 + i * .09, f, .15, .7));
    },
    /** 송전선을 타고 전달 — 웅~ + 쉬익 + 지직, 소리가 왼쪽에서 오른쪽으로 움직임 */
    zap(x, t, dur = 2400) {
      const ac = x.ac, d = (dur || 2400) / 1000;
      const o = ac.createOscillator(), lp = ac.createBiquadFilter(), g = ac.createGain();
      o.type = 'sawtooth'; o.frequency.setValueAtTime(55, t); o.frequency.exponentialRampToValueAtTime(230, t + d * .8);
      lp.type = 'lowpass'; lp.frequency.setValueAtTime(260, t); lp.frequency.exponentialRampToValueAtTime(1400, t + d);
      g.gain.setValueAtTime(.0001, t); g.gain.linearRampToValueAtTime(.15, t + d * .15); g.gain.setValueAtTime(.15, t + d * .7); g.gain.exponentialRampToValueAtTime(.0001, t + d + .5);
      o.connect(lp); lp.connect(g);
      if (ac.createStereoPanner) { const p = ac.createStereoPanner(); p.pan.setValueAtTime(-.85, t); p.pan.linearRampToValueAtTime(.85, t + d); g.connect(p); p.connect(x.dest); } else g.connect(x.dest);
      o.start(t); o.stop(t + d + .6);
      noise(x, t, { a: d * .3, d: d * .7, g: .07, f: 600, f2: 4200, q: .6 });
      for (let i = 0, n = Math.round(d * 22); i < n; i++) noise(x, t + Math.random() * d, { a: .001, d: .008, g: .045, type: 'highpass', f: 5000, pan: -1 + 2 * Math.random() });
    },
    /** 열 보기 훑기 — 스캐너 */
    scan(x, t, dur = 900) {
      const d = (dur || 900) / 1000;
      tone(x, t, { f: 280, f2: 1250, a: .04, d, g: .09, vib: [9, 14] });
      tone(x, t, { f: 283, f2: 1262, type: 'triangle', a: .04, d, g: .04, pan: .4 });
    },
    /** 온도계가 오름 — 조용한 상승음 */
    rise(x, t, dur = 2400) { tone(x, t, { f: 260, f2: 640, a: .15, d: (dur || 2400) / 1000, g: .07, vib: [5, 6] }); },
    /** 바늘이 내려옴 — 슬라이드 휘슬 + 톡 */
    sweepDown(x, t, dur = 1300) {
      const d = (dur || 1300) / 1000;
      tone(x, t, { f: 1100, f2: 380, a: .02, d, g: .09 });
      tickAt(x, t + d, 1800, .08);
    },
    /** 푸슉(연기) */
    puff(x, t) { noise(x, t, { a: .05, d: .5, g: .22, type: 'lowpass', f: 1000, f2: 300, q: .4 }); },
    /** 싹둑 싹둑 */
    snip(x, t) {
      [0, .07, .14].forEach(o => { noise(x, t + o, { a: .001, d: .012, g: .18, f: 5000, q: 2 }); tone(x, t + o, { f: 3000, a: .001, d: .02, g: .03 }); });
    },
    /** 슥(선 그리기) */
    zip(x, t, dur = 500) { noise(x, t, { a: .02, d: Math.min(.3, (dur || 500) / 1000 * .5), g: .12, f: 1500, f2: 4200, q: 1 }); },
    /** 반짝 */
    spark(x, t) { for (let i = 0; i < 4; i++) tone(x, t + i * .04 + Math.random() * .02, { f: 2200 + Math.random() * 2000, a: .001, d: .08, g: .04 }); },
  };

  /* ═════════ 이어지는 소리(선풍기·발전소·끓는 물) — level(0..1) 로 세기 조종 ═════════ */
  function buildFan(x) {
    const ac = x.ac, out = ac.createGain(); out.gain.value = 0; out.connect(x.dest);
    const ns = ac.createBufferSource(); ns.buffer = x.nz; ns.loop = true;
    const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 500; bp.Q.value = .7;
    const gw = ac.createGain(); gw.gain.value = 0;
    const lfo = ac.createOscillator(), lg = ac.createGain(); lfo.frequency.value = 3; lg.gain.value = 0; lfo.connect(lg); lg.connect(gw.gain);   // 날개가 바람을 자르는 울렁임
    ns.connect(bp); bp.connect(gw); gw.connect(out);
    const m1 = ac.createOscillator(), m2 = ac.createOscillator(), gm = ac.createGain(), lp = ac.createBiquadFilter();   // 모터 웅~
    m1.type = 'triangle'; m1.frequency.value = 50; m2.type = 'sine'; m2.frequency.value = 100; gm.gain.value = 0;
    lp.type = 'lowpass'; lp.frequency.value = 700; m1.connect(gm); m2.connect(gm); gm.connect(lp); lp.connect(out);
    ns.start(0, .3); lfo.start(); m1.start(); m2.start();
    let lv = 0, wh = 0;
    const apply = () => {
      const T = ac.currentTime, v = clamp(lv, 0, 1.1), tc = .07;
      gw.gain.setTargetAtTime(v * v * .095, T, tc); lg.gain.setTargetAtTime(v * v * .035, T, tc);
      lfo.frequency.setTargetAtTime(2 + 7 * v, T, tc);
      bp.frequency.setTargetAtTime(380 + 900 * v, T, tc);
      m1.frequency.setTargetAtTime(46 + 70 * v, T, tc); m2.frequency.setTargetAtTime(92 + 140 * v, T, tc);
      gm.gain.setTargetAtTime(v > .02 ? .01 + .034 * v + wh * .04 : 0, T, tc);
      out.gain.setTargetAtTime(v > .01 ? 1 : 0, T, .05);
    };
    return {
      level(v) { lv = v; apply(); }, whine(v) { wh = v; apply(); },
      stop() {
        const T = ac.currentTime; out.gain.cancelScheduledValues(T); out.gain.setTargetAtTime(0, T, .08);
        setTimeout(() => { try { ns.stop(); lfo.stop(); m1.stop(); m2.stop(); out.disconnect(); } catch (e) {} }, 500);
      },
    };
  }
  function buildHum(x) {   // 발전소 웅~
    const ac = x.ac, out = ac.createGain(); out.gain.value = 0; out.connect(x.dest);
    const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 220; lp.connect(out);
    const o1 = ac.createOscillator(), o2 = ac.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = 50; o2.type = 'sine'; o2.frequency.value = 100;
    const g2 = ac.createGain(); g2.gain.value = .5; o1.connect(lp); o2.connect(g2); g2.connect(lp);
    const ns = ac.createBufferSource(); ns.buffer = x.nz; ns.loop = true; const nl = ac.createBiquadFilter(); nl.type = 'lowpass'; nl.frequency.value = 380; const ng = ac.createGain(); ng.gain.value = .5;
    ns.connect(nl); nl.connect(ng); ng.connect(lp);
    o1.start(); o2.start(); ns.start(0, .7);
    return {
      level(v) { const T = ac.currentTime; out.gain.setTargetAtTime(clamp(v, 0, 1.1) * .06, T, .15); o1.frequency.setTargetAtTime(44 + 8 * v, T, .3); },
      stop() { const T = ac.currentTime; out.gain.setTargetAtTime(0, T, .1); setTimeout(() => { try { o1.stop(); o2.stop(); ns.stop(); out.disconnect(); } catch (e) {} }, 500); },
    };
  }
  function buildBoil(x) {   // 주전자 끓는 소리: 쉬이~ + 보글보글
    const ac = x.ac, out = ac.createGain(); out.gain.value = 0; out.connect(x.dest);
    const ns = ac.createBufferSource(); ns.buffer = x.nz; ns.loop = true; const hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 3200;
    const gh = ac.createGain(); gh.gain.value = 0; ns.connect(hp); hp.connect(gh); gh.connect(out); ns.start(0, .2);
    let lv = 0; const rnd = U_rng(7);
    const id = setInterval(() => {
      if (lv < .05 || !on) return;
      if (rnd() < .15 + lv * .5) { const T = ac.currentTime + .005, f0 = 260 + rnd() * 260; tone({ ac, dest: out, nz: x.nz }, T, { f: f0, f2: f0 * 1.9, a: .003, d: .07, g: .1 * lv, pan: (rnd() - .5) * .8 }); }
    }, 70);
    return {
      level(v) { lv = clamp(v, 0, 1); const T = ac.currentTime; gh.gain.setTargetAtTime(lv * .05, T, .4); out.gain.setTargetAtTime(lv > .01 ? 1 : 0, T, .1); },
      stop() { clearInterval(id); const T = ac.currentTime; out.gain.setTargetAtTime(0, T, .1); setTimeout(() => { try { ns.stop(); out.disconnect(); } catch (e) {} }, 500); },
    };
  }
  function U_rng(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
  const LOOPS = { fan: buildFan, hum: buildHum, boil: buildBoil };
  const NULL_LOOP = { level() {}, whine() {}, stop() {} };

  /* ═════════ 바깥 API ═════════ */
  let blankN = 0;
  const tickLog = [];
  function play(name, a, b) {
    if (OFF || !on) return;
    const x = ensure(); if (!x) return;
    const f = S[name]; if (!f) { console.warn('[SFX] 없는 소리:', name); return; }
    if (name === 'blank') a = blankN++;
    if (name === 'tick') {   // 빽빽할수록(100 W 레인) 톡톡이 작고 높은 지지직으로 — 촘촘한 정도에 따라 세기·음높이 자동 조절
      const now = performance.now(); tickLog.push(now); while (tickLog.length && now - tickLog[0] > 250) tickLog.shift();
      const n = tickLog.length;
      b = (b ?? 1) / (1 + n * .22); a = (a ?? 1) * (1 + Math.min(n, 30) * .012);
    }
    try { f(x, x.ac.currentTime + .008, a, b); } catch (e) { console.error('[SFX]', name, e); }
  }
  function loop(kind, o) {
    const build = LOOPS[kind];
    if (OFF || !build) return NULL_LOOP;
    const h = {
      built: null, lvl: 0, wh: 0, dead: false,
      level(v) { h.lvl = v; if (h.built) h.built.level(v); },
      whine(v) { h.wh = v; if (h.built && h.built.whine) h.built.whine(v); },
      stop() { h.dead = true; pending.delete(h); if (h.built) { h.built.stop(); h.built = null; } },
      tryBuild() {
        if (h.built || h.dead) return;
        const x = ensure(); if (!x) return;
        try { h.built = build(x, o || {}); h.built.level(h.lvl); if (h.wh && h.built.whine) h.built.whine(h.wh); }
        catch (e) { console.error('[SFX loop]', kind, e); h.dead = true; }
      },
    };
    pending.add(h); h.tryBuild();
    return h;
  }
  function unlock() {
    if (unlocked) return;
    unlocked = true;
    if (!OFF) { ensure(); pending.forEach(h => h.tryBuild()); }
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach(ev => document.addEventListener(ev, unlock, { capture: true, once: false, passive: true }));
  document.addEventListener('visibilitychange', () => {
    if (!ac) return;
    if (document.hidden) ac.suspend().catch(() => {}); else if (on) ac.resume().catch(() => {});
  });

  let toastEl = null, toastT = 0;
  function toast(v) {
    if (!document.body) return;
    if (!toastEl) { toastEl = document.createElement('div'); toastEl.id = 'sfxToast'; document.body.appendChild(toastEl); }
    toastEl.textContent = v ? '소리 켜짐' : '소리 꺼짐';
    toastEl.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), 1400);
  }
  function toggle(v) {
    on = v == null ? !on : !!v;
    try { localStorage.setItem(KEY, on ? '1' : '0'); } catch (e) {}
    unlock();
    const x = ensure();
    if (x && master) master.gain.setTargetAtTime(on ? volume : 0, ac.currentTime, .03);
    syncVolumeUI();
    toast(on);
    if (on) play('pop');
    return on;
  }

  function setVolume(value, persist = true) {
    if (typeof value !== 'number' || !Number.isFinite(value)) return volume;
    volume = clamp(value);
    if (persist) { try { localStorage.setItem(VOLUME_KEY, String(volume)); } catch (e) {} }
    if (master && ac) master.gain.setTargetAtTime(on ? volume : 0, ac.currentTime, .03);
    syncVolumeUI();
    return volume;
  }
  let volumeButton = null, volumePanel = null, volumeInput = null, volumeOutput = null, volumeStatus = null, volumeTry = null;
  function syncVolumeUI() {
    if (!volumeButton) return;
    const percent = Math.round(volume * 100);
    volumeButton.textContent = percent + '%';
    volumeButton.title = '효과음 볼륨 ' + percent + '% · 조절하기';
    volumeInput.value = String(percent);
    volumeInput.setAttribute('aria-valuetext', percent + '%');
    volumeOutput.textContent = percent + '%';
    volumeStatus.textContent = OFF ? '소리가 비활성화된 화면' : !on ? '음소거 중 · 아래 스피커 버튼으로 켜기' : percent === 0 ? '볼륨 0% · 소리 없음' : '효과음 전체에 적용';
    volumeInput.disabled = OFF;
    volumeTry.disabled = OFF || !on || volume === 0;
  }
  function mountVolumeUI() {
    const hud = document.getElementById('hud');
    if (!hud || document.getElementById('lecture-volume-toggle')) return;
    const sound = hud.querySelector('[data-a="sound"]');
    if (!sound) return;
    const style = document.createElement('style');
    style.textContent = `#hud #lecture-volume-toggle{width:58px;border-radius:22px;font:600 14px system-ui,sans-serif}
      #hud.volume-open{opacity:1;transform:none;pointer-events:auto}
      #lecture-volume-panel{position:absolute;right:0;bottom:calc(100% + 10px);width:280px;max-width:calc(100vw - 28px);box-sizing:border-box;padding:18px;background:#172238;color:#fff;border:1px solid #62718a;border-radius:14px;font:16px/1.5 system-ui,sans-serif;touch-action:auto}
      #lecture-volume-panel[hidden]{display:none!important}
      #lecture-volume-panel .volume-heading{display:flex;justify-content:space-between;align-items:center;font-weight:700;margin-bottom:12px}
      #lecture-volume-range{display:block;width:100%;height:36px;margin:0;accent-color:#8bceff;touch-action:auto;cursor:pointer}
      #lecture-volume-status{font-size:14px;color:#d5e4fa;margin:8px 0 12px}
      #hud #lecture-volume-panel button{width:auto;min-height:40px;height:auto;padding:8px 14px;border-radius:8px;font:600 14px system-ui,sans-serif;background:#e1edff;color:#172238}
      #lecture-volume-panel .volume-actions{display:flex;justify-content:space-between;gap:12px}
      #lecture-volume-panel button:disabled{opacity:.45;cursor:default}
      @media(max-width:600px){#hud{right:8px;gap:4px;max-width:calc(100vw - 16px);flex-wrap:wrap;justify-content:flex-end}#hud button{width:32px;height:38px}#hud .count{min-width:50px;height:38px;padding:0 8px}#hud #lecture-volume-toggle{width:44px;font-size:12px}}
      @media print{#lecture-volume-panel,#lecture-volume-toggle{display:none!important}}`;
    document.head.appendChild(style);
    volumeButton = document.createElement('button');
    volumeButton.id = 'lecture-volume-toggle'; volumeButton.type = 'button';
    volumeButton.setAttribute('aria-label','효과음 볼륨 조절');
    volumeButton.setAttribute('aria-expanded','false');
    volumeButton.setAttribute('aria-controls','lecture-volume-panel');
    hud.insertBefore(volumeButton,sound.nextSibling);
    volumePanel = document.createElement('div');
    volumePanel.id = 'lecture-volume-panel'; volumePanel.hidden = true;
    volumePanel.setAttribute('role','group'); volumePanel.setAttribute('aria-label','효과음 볼륨');
    volumePanel.innerHTML = '<div class="volume-heading"><label for="lecture-volume-range">효과음 볼륨</label><output id="lecture-volume-value" for="lecture-volume-range"></output></div><input id="lecture-volume-range" type="range" min="0" max="100" step="1" aria-label="효과음 볼륨"><div id="lecture-volume-status"></div><div class="volume-actions"><button type="button" id="lecture-volume-try">시험 듣기</button><button type="button" id="lecture-volume-close">닫기</button></div>';
    hud.appendChild(volumePanel);
    volumeInput = volumePanel.querySelector('input'); volumeOutput = volumePanel.querySelector('output');
    volumeStatus = volumePanel.querySelector('#lecture-volume-status'); volumeTry = volumePanel.querySelector('#lecture-volume-try');
    const setOpen = (open, restoreFocus = false) => {
      volumePanel.hidden = !open; volumeButton.setAttribute('aria-expanded',String(open));
      hud.classList.toggle('volume-open',open);
      if (open) volumeInput.focus(); else if (restoreFocus) volumeButton.focus();
    };
    volumeButton.addEventListener('click', e => { e.stopPropagation(); setOpen(volumePanel.hidden); });
    volumeButton.addEventListener('keydown', e => { if (e.key === ' ' || e.key === 'Enter') e.stopPropagation(); });
    volumePanel.addEventListener('click', e => e.stopPropagation());
    volumePanel.addEventListener('keydown', e => e.stopPropagation());
    volumeInput.addEventListener('input', () => setVolume(Number(volumeInput.value)/100));
    volumeTry.addEventListener('click', () => { unlock(); play('ding'); });
    volumePanel.querySelector('#lecture-volume-close').addEventListener('click', () => setOpen(false,true));
    document.addEventListener('keydown', e => {
      if (!volumePanel.hidden && e.key === 'Escape') { setOpen(false,true); e.preventDefault(); e.stopImmediatePropagation(); }
    },true);
    document.addEventListener('pointerdown', e => { if (!volumePanel.hidden && !volumePanel.contains(e.target) && e.target !== volumeButton) setOpen(false); },true);
    window.addEventListener('blur', () => setOpen(false));
    window.addEventListener('storage', e => {
      if (e.key === VOLUME_KEY && e.newValue !== null && e.newValue.trim() !== '' && Number.isFinite(Number(e.newValue))) setVolume(Number(e.newValue),false);
    });
    syncVolumeUI();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(mountVolumeUI,0));
  else setTimeout(mountVolumeUI,0);

  /* ═════════ 점검 도구 ═════════ */
  function measure(buf) {
    let peak = 0, sum = 0, n = 0, last = 0, first = -1, zc = 0, prev = 0;
    const ch = buf.getChannelData(0), ch2 = buf.numberOfChannels > 1 ? buf.getChannelData(1) : ch, sr = buf.sampleRate;
    for (let i = 0; i < ch.length; i++) {
      const v = Math.max(Math.abs(ch[i]), Math.abs(ch2[i]));
      if (v > peak) peak = v;
      sum += ch[i] * ch[i]; n++;
      if (v > .003) { last = i; if (first < 0) first = i; }
      if ((ch[i] >= 0) !== (prev >= 0)) zc++; prev = ch[i];
    }
    const active = Math.max(1, last - Math.max(0, first)) / sr;
    return { peak: +peak.toFixed(3), rms: +Math.sqrt(sum / n).toFixed(4), attack: first < 0 ? null : +(first / sr).toFixed(3), length: +(last / sr).toFixed(2), approxHz: Math.round(zc / 2 / active), clipped: peak >= .98, silent: peak < .01 };
  }
  async function analyze(name, a, b, secs = 3) {
    const OA = window.OfflineAudioContext || window.webkitOfflineAudioContext, sr = 44100;
    const oc = new OA(2, Math.floor(sr * secs), sr), g = oc.createGain(); g.gain.value = .9; g.connect(oc.destination);
    const x = { ac: oc, dest: g, nz: noiseBuf(oc) };
    S[name](x, .02, a, b);
    return measure(await oc.startRendering());
  }
  async function analyzeLoop(kind, level = 1, secs = 1.5) {
    const OA = window.OfflineAudioContext || window.webkitOfflineAudioContext, sr = 44100;
    const oc = new OA(2, Math.floor(sr * secs), sr), g = oc.createGain(); g.gain.value = .9; g.connect(oc.destination);
    const h = LOOPS[kind]({ ac: oc, dest: g, nz: noiseBuf(oc) }); h.level(level);
    const r = measure(await oc.startRendering()); try { h.stop(); } catch (e) {} return r;
  }

  /** ?sfx=demo — 모든 소리를 눌러 들어 보는 패널 */
  function demoPanel() {
    const box = document.createElement('div');
    box.style.cssText = 'position:fixed;left:12px;top:12px;z-index:200;max-width:340px;max-height:92vh;overflow:auto;background:rgba(29,29,31,.94);color:#f5f5f7;border-radius:14px;padding:14px;font:600 13px/1.3 system-ui,sans-serif';
    const btn = (t, fn) => { const b = document.createElement('button'); b.textContent = t; b.style.cssText = 'margin:3px;padding:6px 10px;border-radius:9999px;border:0;background:#0066cc;color:#fff;font:600 13px system-ui'; b.onclick = () => { unlock(); fn(); }; return b; };
    box.appendChild(Object.assign(document.createElement('div'), { textContent: '효과음 듣기 (F2 로 닫기)', style: 'margin-bottom:8px;font-size:14px' }));
    Object.keys(S).forEach(k => box.appendChild(btn(k, () => { if (!on) toggle(true); play(k, k === 'kick' ? true : undefined, 1); })));
    let fan = null;
    box.appendChild(btn('fan 0→1→0', () => { if (!on) toggle(true); if (fan) fan.stop(); fan = loop('fan'); let v = 0, dir = 1; const id = setInterval(() => { v += dir * .05; if (v >= 1) dir = -1; fan.level(clamp(v)); if (v <= 0 && dir < 0) { clearInterval(id); fan.stop(); fan = null; } }, 60); }));
    box.appendChild(btn('boil', () => { if (!on) toggle(true); const h = loop('boil'); h.level(1); setTimeout(() => h.stop(), 4000); }));
    box.appendChild(btn('hum', () => { if (!on) toggle(true); const h = loop('hum'); h.level(1); setTimeout(() => h.stop(), 3000); }));
    document.body.appendChild(box);
    document.addEventListener('keydown', e => { if (e.key === 'F2') box.remove(); });
  }
  if (Q.get('sfx') === 'demo') { const go = () => demoPanel(); if (document.body) go(); else document.addEventListener('DOMContentLoaded', go); }

  return { play, loop, toggle, unlock, setVolume, getVolume: () => volume, analyze, analyzeLoop, names: () => Object.keys(S), isOn: () => on, isOff: () => OFF, S, debug: () => ({ pendingLoops: pending.size, unlocked, state: ac ? ac.state : 'none', volume, effectiveVolume: on && !OFF ? volume : 0 }) };
})();
