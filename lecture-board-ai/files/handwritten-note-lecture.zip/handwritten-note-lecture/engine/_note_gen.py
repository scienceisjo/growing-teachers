"""손글씨 노트 정형 장면 생성기 — 목차 · 시험 포인트(O/X) · 확인 문제 · 한 장 정리
slides/nK/_gen.py 가 이 모듈을 불러 자기 폴더에 장면 조각(.html)을 쓴다. 그림이 주인공인 장면(표지·개념)은 손으로 쓴 .html 이다.

약속(objects/note/30_note.js · 2026-11-02 선생님 요청)
 · 한 단계 안에서는 «한 번에 하나씩» — 문서 순서대로 차례로 나온다. 동시에 여러 줄이 써지지 않는다.
 · 손으로 쓰기(data-w)는 제목·핵심 문장·정답에만. 이름표·보기·풀이 줄은 짧게 떠오르기(data-s rise).
"""
import html as _html
import re
import pathlib

W_PER_CHAR = .55   # 나눔바른히피: 글자당 대략 0.56~0.6em (공백 포함)


def plain(s):
    return re.sub(r'<[^>]+>', '', s).replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')


def tw(s, size):
    """대략의 글자 폭(px)"""
    return len(plain(s)) * W_PER_CHAR * size


def scene(sid, title, notes, say, body, steps, build_js='', cue_js='', extra_js='', wspeed=None, style=''):
    ws = f' data-wspeed="{wspeed}"' if wspeed else ''
    parts = [f'steps: {steps}']
    if build_js:
        parts.append('build(root) {\n' + build_js + '\n    }')
    if cue_js:
        parts.append('cue: {\n' + cue_js + '\n    }')
    if extra_js:
        parts.append(extra_js)
    js = ',\n    '.join(parts)
    st = f'<style>\n{style}\n</style>\n' if style else ''
    return (f'<section class="slide note" id="{sid}" data-tile="parchment" data-title="{_html.escape(title)}" data-notes="{notes}" data-say="{_html.escape(say)}"{ws}>\n'
            f'{body}\n</section>\n{st}<script>\n(function () {{\n  NT.scene(\'{sid}\', {{ {js} }});\n}})();\n</script>\n')


def svg(inner):
    return f'<svg class="full-svg" viewBox="0 0 1920 1080">{inner}</svg>'


def circ(n, cx, cy, step):
    return svg(f'<g data-s="{step}" data-fx="pop"><circle class="sk" cx="{cx}" cy="{cy}" r="46" fill="rgba(146,214,92,.45)" stroke="#2f7d4c" stroke-width="4"/>'
               f'<text x="{cx}" y="{cy + 18}" text-anchor="middle" font-size="52" fill="#2f7d4c">{n}</text></g>')


def star(s):
    """⭐ 를 글자 사이에 작게 끼운다(.st — objects/note/20_note.css)"""
    return s.replace('⭐', '<span class="st">⭐</span>')


# ───────── 목차 ─────────
def toc(sid, items, notes='P2', say='항목을 → 로 하나씩 꺼냅니다.', head='오늘 볼 것'):
    """head: 목차 제목. 편마다 말투를 다르게 둔다(2026-11-04 선생님: 「오늘 볼 것」은 AI 같음 → 「우리가 뽀⭐개⭐버릴 개⭐념」 꼴)"""
    n = len(items)
    gap = {1: 200, 2: 220, 3: 200, 4: 165, 5: 140, 6: 118}[n]
    y0 = 300 if n <= 3 else (280 if n <= 5 else 260)
    size = 64 if n <= 3 else (60 if n == 4 else (54 if n == 5 else 48))
    b = [f'  <div class="sec" style="left:120px;top:120px" data-w="0"><mark class="g">{star(head)}</mark></div>']
    for i, (t, hint) in enumerate(items):
        y = y0 + i * gap
        b.append('  ' + circ(i + 1, 250, y + 40, i + 1))
        b.append(f'  <div class="ln" style="left:330px;top:{y}px;font-size:{size}px" data-w="{i + 1}">{t}</div>')
        if hint:
            hx = max(1000, int(330 + tw(t, size) + 90))
            b.append(f'  <div class="ln blue" style="left:{hx}px;top:{y + 14}px;font-size:44px" data-s="{i + 1}" data-fx="rise">{hint}</div>')
    return scene(sid, '목차', notes, say, '\n'.join(b), n)


# ───────── 시험 포인트 ─────────
def trap(sid, notes, items, say='', title='핵심 OX퀴즈', head='핵심 OX퀴즈!', pause='⏸ 멈추고 O, X 먼저!'):
    """items: [dict(s=문장, ok=True/False, fix=고친 문장 html, size=50)] — 문장 → 다음 단계에 O/X + 고친 문장"""
    n = len(items)
    gap = 220 if n >= 3 else 300
    y0 = 270 if n >= 3 else 300
    b = [f'  <div class="star" data-w="0">{head}</div>', f'  <div class="pause" data-s="1" data-fx="pop">{pause}</div>']
    marks = []
    for i, it in enumerate(items):
        y = y0 + i * gap
        k1, k2 = 2 * i + 1, 2 * i + 2
        sz = it.get('size', 50)
        b.append(f'  <div class="ln" style="left:160px;top:{y}px;font-size:{sz}px" data-w="{k1}">{it["s"]}</div>')
        mk = '<g data-s="%d" data-fx="draw" id="%s-m%d"></g>' % (k2, sid, i)
        b.append('  ' + svg(mk))
        b.append(f'  <div class="ln blue" style="left:220px;top:{y + 80}px;font-size:{it.get("fsize", 44)}px" data-w="{k2}">{it["fix"]}</div>')
        marks.append(f"      root.querySelector('#{sid}-m{i}').innerHTML = NT.{'markO' if it['ok'] else 'markX'}(1710, {y + 44});")
    sfx = "async go(c, k) { if (k % 2 === 0) c.sfx(" + repr([ 'ding' if it['ok'] else 'thunk' for it in items]) + "[k / 2 - 1], 200); }"
    ox = ''.join('○' if it['ok'] else '✗' for it in items)
    return scene(sid, title, notes, (say + ' ' if say else '') + f'정답 {ox}. 문장마다 → 한 번에 문장, 한 번 더에 O/X와 고친 문장.', '\n'.join(b), 2 * n,
                 build_js='\n'.join(marks), extra_js=sfx)


# 확인 문제는 장면에 들어오면 문제(지문·그림·보기·선택지)가 한 번에 다 보인다 — 한 줄씩 띄우지 않는다(2026-11-04 선생님).
# 제목만 손으로 쓰이고 「멈추고 풀어 보세요」가 뜬다. → 한 번에 동그라미 · 풀이.
# ───────── 확인 문제(세로 보기 + 오른쪽 풀이) ─────────
def quiz_v(sid, notes, num, stem, options, ans, exp, fig='', fig_build='', opt_y=560, opt_size=42, opt_gap=72, exp_x=1330, exp_y=None, say='', stem_y=200, stem_size=42, label='확인 문제'):
    b = [f'  <div class="sec" style="left:120px;top:110px;font-size:56px" data-w="0"><mark class="g">{label} {num}</mark></div>',
         '  <div class="pause" data-s="0" data-fx="pop">⏸ 멈추고 풀어 보세요</div>']
    for i, line in enumerate(stem):
        b.append(f'  <div class="ln" style="left:140px;top:{stem_y + i * 56}px;font-size:{stem_size}px">{line}</div>')
    if fig:
        b.append('  ' + svg(f'<g id="{sid}-fig">{fig}</g>'))
    for i, o in enumerate(options):
        cls = 'ln q ok' if i == ans else 'ln q'
        b.append(f'  <div class="{cls}" style="left:160px;top:{opt_y + i * opt_gap}px;font-size:{opt_size}px">{"①②③④⑤"[i]} {o}</div>')
    yA = opt_y + ans * opt_gap
    w = tw('①  ' + options[ans], opt_size) + 60
    # 납작한 타원은 양 끝이 좁아 긴 보기에서 ①②… 를 긋는다 → 글자 상자 네 귀퉁이가 타원 안에 들도록 가로 12%·세로 5% 넓힌다(2026-11-08 겹침 검사 — 긴 보기의 ③ 모서리까지 3px 넘게 비게)
    b.append('  ' + svg(f'<g data-s="1" data-fx="draw"><ellipse class="sk" cx="{int(160 + w / 2 - 20)}" cy="{int(yA + opt_size * .68)}" rx="{int((w / 2 + 10) * 1.12)}" ry="{int(opt_size * 1.05)}" fill="none" stroke="#e0261b" stroke-width="6"/></g>'))
    b.append('  <i data-s="1" data-cue="dim"></i>')
    ey = exp_y if exp_y is not None else opt_y
    b.append(f'  <div class="ln red" style="left:{exp_x}px;top:{ey}px;font-size:50px" data-w="1">정답 {"①②③④⑤"[ans]}</div>')
    for i, e in enumerate(exp):
        b.append(f'  <div class="ln" style="left:{exp_x}px;top:{ey + 74 + i * 58}px;font-size:40px" data-s="1" data-fx="rise">{e}</div>')
    cue = "      dim(c, t0) { c.sfx('chime', t0); c.all(c.$$('.q:not(.ok)'), [{ opacity: 1 }, { opacity: .35 }], { dur: 450, delay: t0 }); return 300; },"
    return scene(sid, f'{label} {num}', notes, (say + ' ' if say else '') + f'정답 {"①②③④⑤"[ans]}. 멈추고 풀게 한 뒤 → 한 번에 동그라미와 풀이.', '\n'.join(b), 1,
                 build_js=fig_build, cue_js=cue)


# ───────── 확인 문제(<보기> 형) ─────────
def quiz_b(sid, notes, num, stem, items, judge, ans, exp, fig='', fig_build='', box_y=392, item_gap=70, opt_y=None, exp_y=None, say='', stem_y=200, stem_size=42,
           opts=('ㄱ', 'ㄴ', 'ㄷ', 'ㄱ, ㄴ', 'ㄴ, ㄷ', 'ㄱ, ㄷ', 'ㄱ, ㄴ, ㄷ'), choice=None, label='확인 문제'):
    """items: 보기 문장(ㄱ·ㄴ·ㄷ) · judge: [True/False…] · choice: 다섯 선택지(기본 ① ㄱ ② ㄷ ③ ㄱ, ㄴ ④ ㄴ, ㄷ ⑤ ㄱ, ㄴ, ㄷ) · ans: 0~4"""
    choice = choice or ['ㄱ', 'ㄷ', 'ㄱ, ㄴ', 'ㄴ, ㄷ', 'ㄱ, ㄴ, ㄷ']
    b = [f'  <div class="sec" style="left:120px;top:110px;font-size:56px" data-w="0"><mark class="g">{label} {num}</mark></div>',
         '  <div class="pause" data-s="0" data-fx="pop">⏸ 멈추고 풀어 보세요</div>']
    for i, line in enumerate(stem):
        b.append(f'  <div class="ln" style="left:140px;top:{stem_y + i * 58}px;font-size:{stem_size}px">{line}</div>')
    if fig:
        b.append('  ' + svg(f'<g id="{sid}-fig">{fig}</g>'))
    bh = 40 + len(items) * item_gap
    b.append('  ' + svg(f'<g><rect class="sk" x="160" y="{box_y}" width="1600" height="{bh}" rx="10" fill="rgba(255,255,255,.55)" stroke="#55626e" stroke-width="3"/>'
                        f'<g data-ok="1"><rect x="880" y="{box_y - 20}" width="160" height="40" fill="#fcfbf7"/><text x="960" y="{box_y + 12}" text-anchor="middle" font-size="34" fill="#55626e">보기</text></g></g>'))   # 〈보기〉 글자는 바탕색 띠로 테두리를 끊고 그 위에 놓는다(의도한 겹침)
    for i, it in enumerate(items):
        b.append(f'  <div class="ln" style="left:200px;top:{box_y + 32 + i * item_gap}px;font-size:42px">{"ㄱㄴㄷㄹ"[i]}. {it}</div>')
    oy = opt_y if opt_y is not None else box_y + bh + 30
    xs = [200, 480, 760, 1100, 1440]
    for i, o in enumerate(choice):
        cls = 'ln q ok' if i == ans else 'ln q'
        b.append(f'  <div class="{cls}" style="left:{xs[i]}px;top:{oy}px;font-size:44px">{"①②③④⑤"[i]} {o}</div>')
    marks = []
    for i, ok in enumerate(judge):
        cy = box_y + 32 + i * item_gap + 30
        m = f'<circle class="sk" cx="1680" cy="{cy}" r="30" fill="none" stroke="#2f7d4c" stroke-width="7"/>' if ok else \
            f'<path class="sk" d="M1652 {cy - 26}l56 52M1708 {cy - 26}l-56 52" fill="none" stroke="#d6332a" stroke-width="7" stroke-linecap="round"/>'
        marks.append(svg(f'<g data-s="1" data-fx="draw">{m}</g>'))
    b.extend('  ' + m for m in marks)
    w = tw('①  ' + choice[ans], 44) + 70
    b.append('  ' + svg(f'<g data-s="1" data-fx="draw"><ellipse class="sk" cx="{int(xs[ans] + w / 2 - 25)}" cy="{oy + 30}" rx="{int(w / 2 + 8)}" ry="44" fill="none" stroke="#e0261b" stroke-width="6"/></g>'))
    b.append('  <i data-s="1" data-cue="dim"></i>')
    ey = exp_y if exp_y is not None else oy + 96
    b.append(f'  <div class="ln red" style="left:160px;top:{ey - 4}px;font-size:48px" data-w="1">정답 {"①②③④⑤"[ans]}</div>')
    for i, e in enumerate(exp):
        b.append(f'  <div class="ln" style="left:400px;top:{ey + i * 60}px;font-size:40px" data-s="1" data-fx="rise">{e}</div>')
    cue = "      dim(c, t0) { c.sfx('chime', t0); c.all(c.$$('.q:not(.ok)'), [{ opacity: 1 }, { opacity: .35 }], { dur: 450, delay: t0 }); return 300; },"
    return scene(sid, f'{label} {num}', notes, (say + ' ' if say else '') + f'정답 {"①②③④⑤"[ans]}. → 한 번에 보기 판정 · 동그라미 · 풀이.', '\n'.join(b), 1,
                 build_js=fig_build, cue_js=cue)


# ───────── 한 장 정리 ─────────
def recap(sid, notes, cols, next_ep='', figs=('', '', ''), fig_build='', say='', date='', heads=None, credit=''):
    """cols: [(제목, [(html, cls, size), …]), …] 세 칸(또는 두 칸). figs: 칸마다 그림(svg 안쪽) — 그 칸 글줄 뒤에 나온다"""
    n = len(cols)
    X = {3: [120, 720, 1300], 2: [120, 1000]}[n]
    VR = {3: [690, 1270], 2: [960]}[n]
    b = []
    for j, (h, lines) in enumerate(cols):
        x = X[j]
        b.append(f'  <div class="ln" style="left:{x}px;top:112px;font-size:46px;color:var(--ng);font-weight:700" data-w="0"><mark class="g">{h}</mark></div>')
        y = 190
        used = False
        for (t, cls, size) in lines:
            if t == '@fig':   # 이 칸의 그림을 이 자리(차례)에 — size 만큼 아래로 띄운다
                b.append('  ' + svg(f'<g data-s="0" data-fx="fade" data-dur="500">{figs[j]}</g>')); used = True
                y += size; continue
            b.append(f'  <div class="ln {cls}" style="left:{x + 10}px;top:{y}px;font-size:{size}px" data-s="0" data-fx="rise" data-dur="380">{t}</div>')
            y += int(size * 1.45)
        if figs[j] and not used:
            b.append('  ' + svg(f'<g data-s="0" data-fx="fade" data-dur="500">{figs[j]}</g>'))
    for v in VR:
        b.append(f'  <div class="vr" style="left:{v}px;top:120px;height:{"640" if n == 3 else "640"}px"></div>')
    b.append('  <div class="pause" style="top:auto;bottom:150px;right:120px" data-s="0" data-fx="pop">⏸ 멈추고 캡처!</div>')
    if next_ep:
        b.append(f'  <div class="ln t2" style="left:120px;top:880px;font-size:40px" data-s="0" data-fx="fade">{next_ep}</div>')
    tail = ' · '.join(x for x in (credit, f'최종 업데이트: {date}' if date else '') if x)
    b.append(f'  <div id="app-credit" class="abs center" style="left:0;width:1920px;top:1016px;font-size:24px;color:var(--t3)">{tail}</div>')
    return scene(sid, '한 장 정리', notes, say or '칸마다 차례로 나옵니다. 멈추고 캡처하라고 안내합니다.', '\n'.join(b), 0, build_js=fig_build, wspeed='.5',
                 extra_js="async enter(c, t) { c.sfx('chime', t); }")


def write_all(folder, files):
    folder = pathlib.Path(folder)
    for name, text in files.items():
        (folder / name).write_text(text, encoding='utf-8', newline='\n')
        print('  →', name)
