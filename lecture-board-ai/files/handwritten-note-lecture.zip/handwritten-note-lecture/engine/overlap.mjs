// 손글씨 노트 글자-선 겹침 검사 — 장면 · 단계마다 정지 화면(?p=&k=&still=1)을 완성 HTML 의 글꼴 그대로 열고,
// 글자 상자(SVG 글자 + HTML 글줄)의 격자점이 다른 요소의 선 위(isPointInStroke)인지 잰다. 점선도 이어진 선으로 본다.
// 일부러 겹친 것(그림 앞을 가리는 손가락 뒤의 배경 글자, 〈보기〉 글자 띠 등)은 그 요소나 감싼 <g> 에 data-ok="1".
// 사용: node overlap.mjs g1 [all|last]   (decks.json 의 이름 · 완성/<덱 파일> · 먼저 python build.py <덱> 으로 manifest_<덱>.json 을 만든다)
import { spawn } from 'node:child_process'
import { mkdtempSync, readFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { pathToFileURL } from 'node:url'

const CH = 'C:/Program Files/Google/Chrome/Application/chrome.exe'
const deck = process.argv[2] || 'g1', mode = process.argv[3] || 'all'
const HERE = import.meta.dirname, DK = JSON.parse(readFileSync(join(HERE, 'decks.json'), 'utf8'))
if (!DK[deck]) { console.log('덱 없음', deck); process.exit(2) }
const html = resolve(HERE, '완성', DK[deck].out)
const STEPS = JSON.parse(readFileSync(join(HERE, `manifest_${deck}.json`), 'utf8')).map((s) => s.steps)
const WAIT = +(process.env.WAIT || 2500)
const port = 8600 + Math.floor(Math.random() * 300)   // cdptest(9300~9799) · note_seq(7160~) 와 겹치지 않게
const chrome = spawn(CH, ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--mute-audio', '--force-device-scale-factor=1', '--window-size=1920,1080',
  `--remote-debugging-port=${port}`, `--user-data-dir=${mkdtempSync(join(tmpdir(), 'ovd-'))}`, 'about:blank'], { stdio: 'ignore' })
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
let ws, opened
for (let i = 0; i < 80 && !ws; i++) {
  try { const l = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json(); const p = l.find((t) => t.type === 'page'); if (p) { ws = new WebSocket(p.webSocketDebuggerUrl); opened = new Promise((r) => ws.addEventListener('open', r, { once: true })); break } } catch {}
  await sleep(200)
}
await opened
let id = 0; const pend = new Map(), waiters = []
ws.addEventListener('message', (e) => {
  const m = JSON.parse(e.data)
  if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id) }
  if (m.method) for (const w of waiters.splice(0)) (w.name === m.method ? w.res : (x) => waiters.push(w))(m)
})
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })) })
const once = (name, ms) => new Promise((res) => { const w = { name, res }; waiters.push(w); setTimeout(() => res(null), ms) })
const evT = async (x, ms) => { const r = await Promise.race([ev(x), sleep(ms).then(() => null)]); if (r === null) { await send('Runtime.terminateExecution'); await sleep(300) } return r }
const ev = async (x) => { const r = await send('Runtime.evaluate', { expression: x, returnByValue: true, awaitPromise: true }); return r.result?.result?.value ?? ('ERR ' + (r.result?.exceptionDetails?.exception?.description || r.result?.exceptionDetails?.text)) }

const CHECK = `(()=>{
 const vis=el=>{let o=1;for(let e=el;e&&e.nodeType===1;e=e.parentElement){const cs=getComputedStyle(e);if(cs.display==='none'||cs.visibility==='hidden')return 0;o*=parseFloat(cs.opacity)}return o};
 const slide=document.querySelector('#stage > section.slide.is-on')||[...document.querySelectorAll('section.slide')].find(s=>{const r=s.getBoundingClientRect();return r.width>500&&vis(s)>.5&&r.right>0&&r.left<innerWidth});
 if(!slide)return JSON.stringify({err:'no slide'});
 slide.querySelectorAll('line,polyline,path,rect,circle,ellipse,polygon').forEach(el=>{el.style.strokeDasharray='none'});
 const geo=[...slide.querySelectorAll('svg line,svg polyline,svg path,svg rect,svg circle,svg ellipse,svg polygon')].filter(el=>{
   if(el.closest('[data-ok="1"],clipPath,defs,mask,marker,pattern'))return false;
   const cs=getComputedStyle(el);if(cs.stroke==='none'||!cs.stroke||parseFloat(cs.strokeWidth)<.8)return false;
   if(/rgba\\([^)]*,\\s*0\\)/.test(cs.stroke))return false;
   return vis(el)>=.15});
 const boxes=[];
 slide.querySelectorAll('svg text').forEach(t=>{if(t.closest('[data-ok="1"]')||vis(t)<.15)return;let bb;try{bb=t.getBBox()}catch(e){return}
   if(!bb.width||!t.textContent.trim())return;const m=t.getScreenCTM();
   const a=new DOMPoint(bb.x,bb.y).matrixTransform(m),b=new DOMPoint(bb.x+bb.width,bb.y+bb.height).matrixTransform(m);
   boxes.push({txt:t.textContent.trim(),x0:a.x,y0:a.y,x1:b.x,y1:b.y,svg:1})});
 const tw=document.createTreeWalker(slide,NodeFilter.SHOW_TEXT,{acceptNode:n=>n.parentElement&&!n.parentElement.closest('svg,script,style')&&n.textContent.trim()?1:2});
 for(let n;(n=tw.nextNode());){const el=n.parentElement;if(el.closest('[data-ok="1"]')||vis(el)<.15)continue;const r=document.createRange();r.selectNodeContents(n);
   for(const q of r.getClientRects()){if(q.width<2)continue;boxes.push({txt:n.textContent.trim().slice(0,30),x0:q.left,y0:q.top,x1:q.right,y1:q.bottom,svg:0})}}
 // 선마다 화면 상자(선 굵기만큼 넓힘)를 미리 재 두고, 글자 상자와 겹치는 선만 · 겹치는 구역 안의 점만 잰다(입자 그림처럼 선이 수백 개여도 빠르게)
 const G=geo.map(el=>{const r=el.getBoundingClientRect(),pad=(parseFloat(getComputedStyle(el).strokeWidth)||1)/2+2;return{el,x0:r.left-pad,y0:r.top-pad,x1:r.right+pad,y1:r.bottom+pad,inv:el.getScreenCTM().inverse()}});
 const out=[];
 for(const B of boxes){const h=B.y1-B.y0,sh=h*.14,y0=B.y0+sh,y1=B.y1-sh,x0=B.x0+1,x1=B.x1-1;const hits=[];
   for(const g of G){const ix0=Math.max(x0,g.x0),ix1=Math.min(x1,g.x1),iy0=Math.max(y0,g.y0),iy1=Math.min(y1,g.y1);if(ix0>ix1||iy0>iy1)continue;
     const nx=Math.max(1,Math.ceil((ix1-ix0)/1.5)),ny=Math.max(1,Math.ceil((iy1-iy0)/1.5));let hit=null;
     for(let i=0;i<=nx&&!hit;i++)for(let j=0;j<=ny;j++){const x=ix0+(ix1-ix0)*i/nx,y=iy0+(iy1-iy0)*j/ny;const q=new DOMPoint(x,y).matrixTransform(g.inv);
       if(g.el.isPointInStroke(new DOMPoint(q.x,q.y))){hit=[Math.round(x),Math.round(y)];break}}
     if(hit)hits.push(g.el.tagName+'('+(g.el.getAttribute('stroke')||getComputedStyle(g.el).stroke)+')@'+hit.join(','))}
   if(hits.length)out.push((B.svg?'svg ':'html ')+'「'+B.txt+'」 ↔ '+hits.join(' · '))}
 return JSON.stringify({id:slide.id,n:boxes.length,g:geo.length,out})})()`

await send('Page.enable'); await send('Runtime.enable')
await send('Emulation.setDeviceMetricsOverride', { width: 1920, height: 1080, deviceScaleFactor: 1, mobile: false })
const base = pathToFileURL(html).href
let total = 0, skipped = 0
for (let p = 1; p <= STEPS.length; p++) {
  const ks = mode === 'last' ? [STEPS[p - 1]] : [...Array(STEPS[p - 1] + 1).keys()]
  for (const k of ks) {
    const loaded = once('Page.loadEventFired', 20000)
    await send('Page.navigate', { url: `${base}?p=${p}&k=${k}&still=1` })
    await loaded
    await sleep(WAIT)
    await ev('document.fonts.ready.then(()=>1)')
    const raw = await evT(CHECK, 90000)
    if (raw === null || String(raw).startsWith('ERR')) { console.log(`p${p} k${k}: 검사 못 함(${raw === null ? '90초 넘음' : raw.slice(0, 80)}) — 건너뜀`); skipped++; continue }
    const r = JSON.parse(raw)
    if (r.err) { console.log(`p${p} k${k}: ${r.err}`); continue }
    total += r.out.length
    console.log(`p${p} k${k} ${r.id} · 글자 ${r.n} · 선 ${r.g} · 겹침 ${r.out.length}`)
    r.out.forEach((s) => console.log('   ' + s))
  }
}
console.log(`${deck}: 장면·단계 ${STEPS.reduce((a, b) => a + (mode === 'last' ? 1 : b + 1), 0)}개 · 글자-선 겹침 합계 ${total}${skipped ? ` · 검사 못 한 화면 ${skipped}` : ''}`)
ws.close(); chrome.kill()
process.exit(0)
