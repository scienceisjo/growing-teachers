---
name: handwritten-note-lecture
description: 모눈종이에 손글씨 글꼴로 한 줄씩 써지는 강의 화면(단일 HTML, 형광펜·움직이는 과학 그림·빨간 펜)을 만든다. "손글씨 노트 강의 만들어줘", "○○ 단원 총정리 손글씨로", "유튜브 개념 강의용 HTML" 같은 요청에 쓰고 engine/ 으로 빌드·검사한다.
---

# 손글씨 노트 강의 화면 만들기

결과물은 **HTML 파일 하나**예요. 전자칠판이나 녹화 화면에 띄우고 → 키로 한 단계씩 넘기면, 글이 손으로 쓰듯 한 줄씩 나타나요.
엔진은 `engine/` 에 있고, 예시 덱 `g1`(중1 기체의 성질 총정리 · 20장면)이 들어 있어요. 새 덱은 이 예시를 본떠 만들어요.

## 준비물(한 번만)

- Python 3 + `pip install fonttools brotli` (손글씨 글꼴을 잘라 넣을 때)
- Node.js(있으면 빌드 때 JS 문법 검사) · Chrome(검사 도구 `note_seq.mjs` · `overlap.mjs`)

## 만드는 순서

1. **내용 받기** — 선생님이 준 교과서 · 학습지 · 단원 정리 내용을 읽는다. 둘이 어긋나면 **교과서**를 따른다. 문장은 학습지와 글자까지 같게(학생이 학습지를 보며 따라오므로).
2. **장면 짜기** — 먼저 장면 목록을 선생님께 보여 주고 확인받는다. 기본 짜임:
   표지 → 목차 → 개념 장면들(그림이 주인공) → 헷갈리기 쉬운 것(O/X) → 스스로 확인하기(문제 2~3) → 한 장 정리(캡처용).
   목차 제목은 「오늘 볼 것」 같은 딱딱한 말 대신 선생님 말투로 — `toc(..., head='오늘 한 번에 정⭐리⭐할 개념')`(⭐ 는 작은 별로 바뀜). 편마다 다르게 해도 좋다.
   스스로 확인하기는 장면에 들어오면 지문 · 그림 · 보기 · 선택지가 한 번에 다 보인다(제목만 써짐) → 다음 단계에 정답 동그라미와 풀이.
   한 장면 = 한 생각. 장면마다 단계(→ 누르는 횟수) 2~6개.
3. **`engine/decks.json`에 덱 한 줄 더하기** — 예: `"m1": {"out": "물질의상태_총정리.html", "title": "개념 노트 · 물질의 상태 총정리", "unit": "IV. 물질의 상태 변화", "ep": "총정리", "by": "", "pre": "nosound", "use": ["note"]}`
   (`by` = 머리줄 오른쪽에 들어갈 만든 사람 · `use` 에 `"n4"` 를 더하면 그래프 도우미 N4.graph 를 쓸 수 있다)
4. **손으로 쓴 장면** — `engine/slides/<덱>/NN_이름.html` (표지 · 개념 장면). 아래 「장면 쓰는 법」.
5. **정형 장면** — `engine/slides/<덱>/_gen.py` 에서 `_note_gen.py` 의 `toc · trap · quiz_v · quiz_b · recap` 로 만든다(예시 `slides/g1/_gen.py` 복사해서 고치기). `python slides/<덱>/_gen.py`
6. **그림 도우미**(필요하면) — 주사기 · 비커 · 회로처럼 여러 장면에 나오는 그림은 `engine/objects/<덱>/20_<덱>.js` 에 함수로(예시 `objects/g1/20_g1.js`).
7. **글꼴 → 빌드**: `python objects/note/_make_font.py` → `python build.py <덱>` → `engine/완성/<out>` 이 생긴다.
8. **검사**: 빌드 경고 0 · `node note_seq.mjs <덱>` 에서 「동시에 움직이는 글줄 최대 1 · 콘솔 오류 0」 · `node overlap.mjs <덱>` 에서 「글자-선 겹침 합계 0」(장면 · 단계마다 정지 화면을 재요 · 일부러 겹친 것은 `data-ok="1"`) · 화면을 직접 열어 장면마다 글자와 그림이 겹치지 않는지 본다.

## 꼭 지킬 것

- **한 번에 하나씩** — 한 단계 안에서는 문서 순서대로 하나씩 나온다. 여러 줄이 동시에 써지면 학생이 어디를 볼지 모른다(엔진이 알아서 차례를 맞추니 순서만 문서 순서로).
- **손으로 쓰기는 적절히** — `data-w`(손으로 쓰기)는 제목 · 핵심 문장 · 정답에만. 이름표 · 예시 · 보기 · 풀이는 `data-s`(짧게 떠오르기).
  엔진도 이를 돕는다: `data-w` 줄 가운데 실제로 글자마다 써지는 것은 장면 제목(`.sec` · `.star`)과 줄 대부분이 형광펜(`<mark>`)인 핵심 문장뿐이고, 나머지는 한 줄 통째로 떠오른 뒤 형광펜만 칠해진다. 꼭 쓰게 하려면 `data-hand="1"`, 띄우려면 `data-hand="0"`.
- **과학 그림은 정확하게** — 입자 모형이면 입자 수 · 크기를 전후 같게, 골고루, 벽 밖으로 나가지 않게. 화살표 · 극 · 방향은 교과서 약속대로. 그럴듯한 장식보다 정확성이 먼저.
- **배운 말로만** — 그 학년 교과서에 없는 낱말 · 수식 · 단위는 넣지 않는다(교과서 지도상의 유의점 확인).
- 글자와 선이 겹치면 고친다 — 눈으로는 놓치니 `overlap.mjs` 로 잰다. 궤도 · 시선처럼 선이 많은 그림의 이름표는 점 바로 아래가 아니라 선이 없는 옆자리에 둔다. 1920×1080 무대 밖으로 나가지 않게.

## 장면 쓰는 법(엔진 window.NT)

```html
<section class="slide note" id="m1_03_melt" data-tile="parchment" data-title="녹는점" data-notes="P3" data-say="발표자 메모">
  <div class="sec" style="left:120px;top:110px" data-w="0"><mark class="g">1. 녹는점</mark></div>
  <div class="ln" style="left:140px;top:260px;font-size:50px" data-w="1">고체가 녹아 액체로 변하는 온도</div>
  <div class="ln t2" style="left:140px;top:335px;font-size:42px" data-s="1" data-fx="rise">물질마다 다르다 → 물질의 특성</div>
  <svg class="full-svg" viewBox="0 0 1920 1080"><g data-s="2" data-fx="draw" id="m1m-fig"></g></svg>
</section>
<script>
(function () {
  NT.scene('m1_03_melt', { steps: 2,
    build(root) { root.querySelector('#m1m-fig').innerHTML = '<path d="M1100 700 L1300 500" stroke="#2a67a8" stroke-width="6"/>'; },
  });
})();
</script>
```

- 무대는 1920×1080 px. 글줄은 `class="ln"`(위치를 style 로), 큰 제목 `sec`, 파란 소제목 `sub`, 글색 `t2`(회색) · `red` · `blue` · `green`.
- 형광펜: `<mark class="g">`(초록 · 제목) `<mark class="y">`(노랑 · 핵심) `<mark class="r">`(빨강).
- `data-w="k"` = k 단계에 손으로 쓰기 · `data-s="k" data-fx="rise|fade|pop|draw|left|right|up|scale|wipe"` = k 단계에 떠오르기(SVG 선은 `draw`).
- `data-with` 앞 항목과 함께 · `data-pause="ms"` 더 쉬고 · `data-dur="ms"` 길이.
- 그림 움직임: `<i data-s="k" data-cue="이름"></i>` 를 두고 장면 정의 `cue: { 이름(c, t0) { … return 걸린ms; } }` — 안에서는 `NT.tw(c, 시작ms, 길이ms, p => {…})` 로 움직인다(되돌리기 · 건너뛰기에도 안전).
- 계속 도는 움직임(입자 · 전류)은 `enter(c) { c.loop((t, dt) => {…}) }` — 장면을 떠나면 저절로 멈춘다.
- `NT.scene(id, { steps: N, build, enter, go, cue })` 의 **`steps: N` 글자를 꼭 이 꼴로**(빌드가 이 글자로 단계 수를 읽는다).
- 문서 순서 = 나오는 순서. HTML 글줄과 SVG 그림을 섞을 때는 `<svg class="full-svg">` 를 여러 겹으로 끼워 순서를 맞춘다.
- 그리기 도우미: `NT.ar`(화살표) · `NT.markO` / `NT.markX` · 회로 `NT.wire/res/bulb/batt/sw/meter` · 자석 `NT.magnet/compass` · 그래프 `N4.graph({ox, oy, w, h, xmax, ymax, xl, yl, xt, yt})` → `G.axes() · G.dot · G.line · G.curve`.
- 예시 덱의 그림 도우미 `G1`(`objects/g1/20_g1.js`): 주사기 `G1.syr` · 움직이는 입자 `G1.gas` · 입자 모형 그림 `G1.place` · 스포이트 실험 `G1.rig` · 생활 사례 그림 `G1.icon.*`.

## 화면 조작(완성된 HTML)

→ / ← 넘기기 · **오른쪽 아래 ✏️ 도구 상자**(레이저 · 펜 · 지우기 · 손가락 그리기 · 전체 화면 — 아이패드에서는 펜슬을 한 번 쓰면 그때부터 펜슬만 그리고 손가락은 화면 넘기기) · **P 빨간 펜**(C 지우기 · Z 되돌리기 · Esc 끄기) · **L 레이저** · F 전체 화면 · O 장면 모아 보기 · M 효과음 켜고 끄기(기본 꺼짐) · N 발표자 메모 · B / W 검은 · 흰 화면 · H 도움말 · 주소 끝 `?s=1` 학생 모드(발표자 메모 숨김).

## 글꼴

나눔바른히피(네이버 나눔 글꼴, `engine/objects/note/_src/`). 재배포 · 수정 허용 라이선스이며, 완성 HTML 에는 쓰인 글자만 잘라 넣는다. 출처 표기는 `_src/NanumBaReunHiPi_README.md` 참고.
