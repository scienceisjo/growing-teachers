# 가져다 쓸 재료 — 시뮬레이터·3D를 새로 만들지 않기

이미 있는 검증된 시뮬레이터와 3D 모형은 AI가 다시 그리지 않고 가져다 붙입니다. 토큰이 적게 들고, 연구진이 만든 시뮬이라 오개념 위험도 적습니다. 넣는 법은 `embed-media.md`를 따릅니다. 아래 주소는 2026-11-13에 열리는 것과 퍼가기가 막혀 있지 않은 것을 확인했습니다.

## 가상실험실 (iframe 으로 넣기)

| 과목 | 주제 | 주소 |
|---|---|---|
| 화학 | 기체의 성질 | https://phet.colorado.edu/sims/html/gas-properties/latest/gas-properties_ko.html |
| 화학 | 물질의 상태 | https://phet.colorado.edu/sims/html/states-of-matter/latest/states-of-matter_ko.html |
| 화학 | 밀도 | https://phet.colorado.edu/sims/html/density/latest/density_ko.html |
| 화학 | 원자 만들기 | https://phet.colorado.edu/sims/html/build-an-atom/latest/build-an-atom_ko.html |
| 화학 | 분자 모양 | https://phet.colorado.edu/sims/html/molecule-shapes/latest/molecule-shapes_ko.html |
| 물리 | 정전기(풍선) | https://phet.colorado.edu/sims/html/balloons-and-static-electricity/latest/balloons-and-static-electricity_ko.html |
| 물리 | 회로 만들기 | https://phet.colorado.edu/sims/html/circuit-construction-kit-dc/latest/circuit-construction-kit-dc_ko.html |
| 물리 | 옴의 법칙 | https://phet.colorado.edu/sims/html/ohms-law/latest/ohms-law_ko.html |
| 물리 | 전자기 | https://phet.colorado.edu/sims/html/faradays-electromagnetic-lab/latest/faradays-electromagnetic-lab_ko.html |
| 물리 | 힘과 운동 | https://phet.colorado.edu/sims/html/forces-and-motion-basics/latest/forces-and-motion-basics_ko.html |
| 물리 | 파동(줄) | https://phet.colorado.edu/sims/html/wave-on-a-string/latest/wave-on-a-string_ko.html |
| 물리 | 빛의 굴절 | https://phet.colorado.edu/sims/html/bending-light/latest/bending-light_ko.html |
| 물리 | 색 보기 | https://phet.colorado.edu/sims/html/color-vision/latest/color-vision_ko.html |
| 물리 | 회로(자유 설계) | https://www.falstad.com/circuit/circuitjs.html |
| 생물 | 자연 선택 | https://phet.colorado.edu/sims/html/natural-selection/latest/natural-selection_ko.html |
| 지구과학 | 중력과 궤도 | https://phet.colorado.edu/sims/html/gravity-and-orbits/latest/gravity-and-orbits_ko.html |
| 지구과학 | 온실 효과 | https://phet.colorado.edu/sims/html/greenhouse-effect/latest/greenhouse-effect_ko.html |
| 공통 | 그래프·작도 | GeoGebra(https://www.geogebra.org) · Desmos(https://www.desmos.com/calculator) 의 공유 → 퍼가기 주소 |
| 공통 | 승재쌤 실험실 모음 | https://scienceisjo.github.io/sim-lab/ (CLICK SCIENCE) |

- PhET 은 CC BY 4.0 — 장면 아래 「PhET Interactive Simulations, University of Colorado Boulder」 한 줄.
- 자바실험실처럼 퍼가기 여부를 모르는 곳은 「새 창에서 열기」 링크로만 둡니다.

## 3D 모형 (model-viewer 로 띄우기)

| 출처 | 쓰는 법 | 라이선스 |
|---|---|---|
| NASA 3D Resources(GLB 257개, 탐사선·로켓·위성) | `https://raw.githubusercontent.com/nasa/NASA-3D-Resources/master/3D%20Models/<폴더>/<파일>.glb` 를 src 로 | NASA 자료(로고 사용만 주의) |
| Sketchfab(과학 모형 많음) | 모형 화면의 「Embed」 iframe 코드를 그대로 | 모형마다 다름(CC BY 면 출처 표기) |
| Smithsonian 3D | 내려받아 내 저장소에 올린 뒤 주소로 | 많은 수가 CC0 |

- 확인한 예: `https://raw.githubusercontent.com/nasa/NASA-3D-Resources/master/3D%20Models/Mars%202020%20Perseverance%20Rover/Mars%202020%20Perseverance%20Rover.glb`(5MB).

## 배포가 필요한가요?
- **필요 없음**: 내 컴퓨터에서 HTML 을 더블클릭해 열 때, 인터넷 주소의 시뮬(iframe)·3D 모형(GLB 주소), 효과음·같은 폴더의 소리 파일·글꼴·그림은 그대로 됩니다(2026-11-13·14 확인).
- **유튜브는 예외**: 파일로 열면 칸 안에 「오류 153」이 뜨고 재생되지 않습니다(배포한 주소에서는 재생됨, 2026-11-14 확인). 「새 창에서 열기」 단추로 유튜브에서 엽니다.
- **필요함**: ① 유튜브를 화면 칸 안에서 바로 틀고 싶을 때. ② 내 컴퓨터에 있는 GLB 파일을 쓸 때 — 파일로 열면 브라우저가 막아서 안 뜹니다. GitHub 에 올리거나(배포) Sketchfab 에 올려 퍼가기 코드를 씁니다. ③ 학생에게 링크로 나눠 줄 때.
- AI 채팅의 미리보기 창(캔버스·아티팩트)은 바깥 주소를 막을 수 있습니다. 그때는 HTML 을 내려받아 더블클릭해서 엽니다.
