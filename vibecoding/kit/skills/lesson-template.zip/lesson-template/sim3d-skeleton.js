/* 3D 실험판 뼈대 (three.js r128). AI 는 ①조작 값, ②setup(), ③update() 안쪽만 바꾼다.
   아래 "고치지 않는다" 구역은 화면 크기 맞춤·돌려 보기·일시 정지·슬라이더 연결을 맡는다.
   index.html 에는 다음이 있어야 한다.
     <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>   ← 이 파일보다 먼저
     <div class="sim3d"><div class="hud"></div></div>
     슬라이더: <input type="range" data-p="speed" min="0" max="3" step="0.1" value="1"> <output data-for="speed"></output>
     처음으로: <button type="button" data-sim-reset>처음으로</button>
   <script src="sim3d.js"></script> 로 연결한다(이 파일을 sim3d.js 로 복사). */
(function(){
  'use strict';
  const host=document.querySelector('.sim3d');
  if(!host)return;
  const hud=host.querySelector('.hud')||host.appendChild(Object.assign(document.createElement('div'),{className:'hud'}));
  if(!window.THREE){hud.textContent='3D 를 불러오지 못했어요. 인터넷 연결을 확인해 주세요.';return;}

  /* ① 조작 값 — 이름과 처음 값. 슬라이더 data-p 이름과 같아야 한다 */
  const P={speed:1};

  /* ② 장면 만들기 — 물체와 조명을 scene 에 넣고, update() 에서 쓸 것들을 객체로 돌려준다.
        길이 m, 시간 s 처럼 단위를 정해 주석으로 적어 둔다. 바깥 이미지·모델 파일은 쓰지 않는다. */
  function setup(scene){
    const box=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial({color:0x2563eb}));
    scene.add(box);
    return {box};
  }

  /* ③ 매 프레임 계산 — dt(초)만큼 상태를 진행해 물체 위치를 바꾼다. 화면 글자는 hud.textContent 로 */
  function update(dt,objs,P,hud){
    objs.box.rotation.y+=dt*P.speed;
    hud.textContent='속도 '+P.speed.toFixed(1);
  }

  /* ───────────── 여기부터는 고치지 않는다 ───────────── */
  const scene=new THREE.Scene(); scene.background=new THREE.Color(0x0f172a);
  scene.add(new THREE.AmbientLight(0xffffff,.65));
  const sun=new THREE.DirectionalLight(0xffffff,.8); sun.position.set(3,5,4); scene.add(sun);
  const camera=new THREE.PerspectiveCamera(50,1,.1,200);
  const renderer=new THREE.WebGLRenderer({antialias:true});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
  host.insertBefore(renderer.domElement,host.firstChild);

  let objs=setup(scene), theta=.7, phi=1.15, radius=5;       // 돌려 보기: 가로각·세로각·거리
  const placeCamera=()=>{camera.position.set(radius*Math.sin(phi)*Math.sin(theta),radius*Math.cos(phi),radius*Math.sin(phi)*Math.cos(theta));camera.lookAt(0,0,0);};
  placeCamera();

  new ResizeObserver(()=>{const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;
    renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}).observe(host);

  const ptr=new Map(); let pinch=0;
  const cv=renderer.domElement;
  cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);ptr.set(e.pointerId,[e.clientX,e.clientY]);});
  cv.addEventListener('pointerup',e=>{ptr.delete(e.pointerId);pinch=0;});
  cv.addEventListener('pointercancel',e=>{ptr.delete(e.pointerId);pinch=0;});
  cv.addEventListener('pointermove',e=>{
    if(!ptr.has(e.pointerId))return;
    const [px,py]=ptr.get(e.pointerId); ptr.set(e.pointerId,[e.clientX,e.clientY]);
    if(ptr.size===1){theta-=(e.clientX-px)*.008;phi=Math.min(3.0,Math.max(.2,phi-(e.clientY-py)*.008));}
    else if(ptr.size===2){const [a,b]=[...ptr.values()];const d=Math.hypot(a[0]-b[0],a[1]-b[1]);
      if(pinch)radius=Math.min(14,Math.max(2,radius*pinch/d)); pinch=d;}
    placeCamera();
  });
  cv.addEventListener('wheel',e=>{e.preventDefault();radius=Math.min(14,Math.max(2,radius*(1+Math.sign(e.deltaY)*.08)));placeCamera();},{passive:false});

  document.querySelectorAll('[data-p]').forEach(inp=>{
    const k=inp.dataset.p, out=document.querySelector('[data-for="'+k+'"]');
    const read=()=>{P[k]=parseFloat(inp.value);if(out)out.textContent=inp.value;};
    inp.addEventListener('input',read); read();
  });
  document.querySelector('[data-sim-reset]')?.addEventListener('click',()=>{
    for(const o of [...scene.children])if(o.isMesh||o.isGroup||o.isLine||o.isPoints){scene.remove(o);
      o.traverse&&o.traverse(m=>{m.geometry&&m.geometry.dispose();m.material&&(Array.isArray(m.material)?m.material:[m.material]).forEach(x=>x.dispose());});}
    objs=setup(scene);
  });

  let last=performance.now();
  (function loop(now){
    requestAnimationFrame(loop);
    const dt=Math.min(.05,(now-last)/1000); last=now;
    if(!host.offsetParent)return;                       // 다른 탭이 열려 있으면 계산을 멈춘다
    update(dt,objs,P,hud); renderer.render(scene,camera);
  })(last);
})();
