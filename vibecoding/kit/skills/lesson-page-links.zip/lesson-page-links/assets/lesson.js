(function(){
'use strict';
/* ── 저장 이름은 index.html 의 window.LESSON.save (페이지마다 다르게) ── */
const SAVE=(window.LESSON&&window.LESSON.save)||('lesson_'+location.pathname);

const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
let S={tab:'t1',started:0,teacher:0,seen:{},cloze:{},quiz:{},poe:{},ref:{},obs:{}};
try{Object.assign(S,JSON.parse(localStorage.getItem(SAVE))||{});}catch(e){}
const save=()=>{try{localStorage.setItem(SAVE,JSON.stringify(S));}catch(e){}};
let toastT; const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('show'),1600);};
const id=(el,pre,i)=>el.dataset.id||pre+i;

/* ── 활동 부품 ─────────────────────────────────────────────── */
// 빈칸
$$('.cloze-set').forEach((set,si)=>{
  const sid=id(set,'z',si), cs=$$('.cloze',set);
  cs.forEach((b,i)=>{
    const key=sid+'-'+i;
    b.style.setProperty('--n',(b.dataset.ans||'').length||3);
    if(b.dataset.c)b.style.setProperty('--cc','var(--'+b.dataset.c+')');
    b.setAttribute('aria-label','빈칸 '+(b.dataset.no||i+1)+' 누르면 정답이 보여요');
    const open=quiet=>{
      if(b.classList.contains('on'))return;
      b.textContent=b.dataset.ans; b.classList.add('on'); b.setAttribute('aria-label','정답 '+b.dataset.ans);
      S.cloze[key]=1; save();
      set.classList.toggle('complete',cs.every(x=>x.classList.contains('on')));
      if(!quiet)refresh();
    };
    b.addEventListener('click',()=>open(false));
    if(S.cloze[key])open(true);
  });
});
// 예측
$$('.poe').forEach((p,pi)=>{
  const pid=id(p,'p',pi), cs=$$('.choice',p);
  const pick=(c,quiet)=>{
    cs.forEach(x=>x.classList.remove('picked')); c.classList.add('picked');
    const hit=$('[data-hit]',p); if(hit)hit.classList.add('hit');
    p.classList.add('done'); S.poe[pid]=c.dataset.v; save(); if(!quiet)refresh();
  };
  cs.forEach(c=>c.addEventListener('click',()=>pick(c,false)));
  if(S.poe[pid]){const c=cs.find(x=>x.dataset.v===S.poe[pid]); if(c)pick(c,true);}
});
// 확인 문제
$$('.quiz').forEach((q,qi)=>{
  const qid=id(q,'q',qi), opts=$$('.opt',q), fb=$('.fb',q), ans=+q.dataset.ans;
  opts.forEach((o,i)=>{ o.insertAdjacentHTML('afterbegin','<span class="k">'+'①②③④⑤'[i]+'</span>'); });
  const solve=quiet=>{q.classList.add('done');opts[ans-1].classList.add('right');if(fb){fb.textContent='정답이에요';fb.className='fb yes';}
    S.quiz[qid]=1;save();if(!quiet)refresh();};
  opts.forEach((o,i)=>o.addEventListener('click',()=>{
    if(q.classList.contains('done'))return;
    if(i+1===ans){solve(false);}
    else{o.classList.add('wrong');if(fb){fb.textContent='다시 생각해 볼까요?';fb.className='fb no';}}
  }));
  if(S.quiz[qid])solve(true);
});
// 내 생각 쓰기
$$('textarea.reflect').forEach((t,ti)=>{
  const rid=id(t,'r',ti); t.value=S.ref[rid]||'';
  t.addEventListener('input',()=>{S.ref[rid]=t.value;save();refresh();});
});
// 기록표
$$('table.obs').forEach((tb,oi)=>{
  const oid=id(tb,'o',oi), body=$('tbody',tb), cols=$$('thead th',tb).length;
  const data=S.obs[oid]||Array.from({length:+tb.dataset.rows||4},()=>Array(cols).fill(''));
  const addRow=v=>{
    const tr=document.createElement('tr');
    for(let c=0;c<cols;c++){const td=document.createElement('td');td.contentEditable='true';td.textContent=v?v[c]||'':'';
      td.setAttribute('role','textbox');td.setAttribute('aria-label',$$('thead th',tb)[c].textContent+' 칸');
      td.addEventListener('input',collect);tr.appendChild(td);}
    body.appendChild(tr);
  };
  function collect(){S.obs[oid]=$$('tr',body).map(tr=>$$('td',tr).map(td=>td.textContent.trim()));save();refresh();}
  data.forEach(addRow);
  $('[data-obs-add="'+oid+'"]')?.addEventListener('click',()=>{addRow(null);collect();});
  $('[data-obs-copy="'+oid+'"]')?.addEventListener('click',()=>{
    const head=$$('thead th',tb).map(h=>h.textContent).join('\t');
    const rows=$$('tr',body).map(tr=>$$('td',tr).map(td=>td.textContent.trim()).join('\t')).join('\n');
    const text=head+'\n'+rows;
    (navigator.clipboard?navigator.clipboard.writeText(text):Promise.reject()).then(()=>toast('표를 복사했어요'),()=>{
      const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();
      try{document.execCommand('copy');toast('표를 복사했어요');}catch(e){toast('복사가 막혀 있어요');} ta.remove();});
  });
});
// 같은 단계 안의 갈래(.seg 단추와 .seg-pane 은 같은 부모 안에 둔다)
$$('.seg').forEach(seg=>{
  const scope=seg.parentElement;
  $$('button',seg).forEach(b=>b.addEventListener('click',()=>{
    $$('button',seg).forEach(x=>x.classList.toggle('on',x===b));
    $$('.seg-pane',scope).forEach(p=>p.hidden=p.dataset.seg!==b.dataset.seg);
  }));
});
// 외부 시뮬레이션: 그 탭을 처음 열 때 불러온다
function buildEmbeds(panel){
  $$('.embed:not([data-built])',panel).forEach(e=>{
    const src=e.dataset.src||''; if(!/^https:\/\//.test(src)||src.includes('【'))return;
    e.dataset.built='1'; const t=e.dataset.title||'시뮬레이션';
    e.innerHTML='<div class="embed-bar"><b></b><a class="btn sm ghost" target="_blank" rel="noopener noreferrer">새 창에서 열기 ↗</a></div>'+
      '<iframe loading="lazy" allow="fullscreen" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin allow-popups allow-forms"></iframe>'+
      '<p class="embed-note">화면이 비어 있거나 막혀 있으면 위의 「새 창에서 열기」를 눌러 주세요.</p>';
    $('b',e).textContent=t; $('a',e).href=src; const f=$('iframe',e); f.title=t; f.src=src;
    if(e.dataset.h)e.style.setProperty('--h',e.dataset.h+'px');
  });
}

/* ── 진행도: 활동(빈칸 묶음·예측·확인 문제·생각 쓰기·기록표) 하나가 한 칸 ───────── */
function tasks(panel){
  const out=[];
  $$('.cloze-set',panel).forEach(s=>out.push(()=>$$('.cloze',s).every(c=>c.classList.contains('on'))));
  $$('.poe',panel).forEach(p=>out.push(()=>p.classList.contains('done')));
  $$('.quiz',panel).forEach(q=>out.push(()=>q.classList.contains('done')));
  $$('textarea.reflect',panel).forEach(t=>out.push(()=>t.value.trim().length>=(+t.dataset.min||5)));
  $$('table.obs',panel).forEach(tb=>out.push(()=>$$('tbody tr',tb).filter(tr=>$$('td',tr).some(td=>td.textContent.trim())).length>=(+tb.dataset.min||3)));
  return out;
}
function refresh(){
  let done=0,total=0;
  $$('.panel').forEach(p=>{
    const ts=tasks(p), n=ts.filter(f=>f()).length, btn=$('nav.tabs [data-tab="'+p.id+'"]');
    const all=ts.length?n===ts.length:!!S.seen[p.id];
    if(btn)btn.classList.toggle('done',all);
    if(p.id!=='t6'){done+=n;total+=ts.length;}
  });
  const pct=total?Math.round(done/total*100):0;
  $('#progBar').style.width=pct+'%'; $('#progPct').textContent=pct+'%';
}

/* ── 탭 · 표지 · 교사 모드 ─────────────────────────────────── */
function showTab(tid,quiet){
  if(!$('#'+tid))tid='t1';
  $$('.panel').forEach(p=>p.classList.toggle('show',p.id===tid));
  $$('nav.tabs button').forEach(b=>{const on=b.dataset.tab===tid;b.classList.toggle('active',on);b.setAttribute('aria-selected',on);});
  S.tab=tid; S.seen[tid]=1; save(); buildEmbeds($('#'+tid)); refresh();
  if(!quiet)window.scrollTo({top:0,behavior:'smooth'});
}
$('#tabs').addEventListener('click',e=>{const b=e.target.closest('button[data-tab]');if(b)showTab(b.dataset.tab);});
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]');if(g)showTab(g.dataset.go);});
function closeCover(){document.body.classList.remove('cover-on');$('#cover').classList.add('hide');}
function openCover(){document.body.classList.add('cover-on');$('#cover').classList.remove('hide');window.scrollTo(0,0);}
$('#enterBtn').addEventListener('click',()=>{S.started=1;closeCover();showTab('t1');});
$('#resumeBtn').addEventListener('click',()=>{closeCover();showTab(S.tab,true);});
$('#brandBtn').addEventListener('click',openCover);
function setTeacher(on){S.teacher=on?1:0;document.body.classList.toggle('teacher',!!on);$('#tmodeBtn').setAttribute('aria-pressed',!!on);save();}
$('#tmodeBtn').addEventListener('click',()=>{setTeacher(!S.teacher);toast(S.teacher?'교사 모드를 켰어요':'교사 모드를 껐어요');});
setTeacher(S.teacher);
if(S.started)$('#resumeBtn').hidden=false;
if(/^#t[1-6]$/.test(location.hash)){S.started=1;closeCover();showTab(location.hash.slice(1),true);}   // 주소 끝 #t3 처럼 쓰면 그 탭을 바로 연다
refresh();
})();
